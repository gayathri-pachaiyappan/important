# %%
"""
This module defines the Glue classes and functios used for deploying glue jobs on AWS.
"""

# %%
import time

# %%
import boto3

# %%
# Load main modules of our team library
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, the main config
from abt_epd_gpmo_aa import logger, s3_utils


# %%
def find_script_file(python_script_name: str) -> str:
    """Find the full path to a (python) file, skipping '.../templates/...' subdirectory"""
    # Use the location of the project config file as startpoint for all our searches
    path_to_constants = misc_utils.config["USED_CONFIG_FILE"]

    path_to_python_script = [
        p
        for p in misc_utils.find_path_name_to_files(
            misc_utils.find_root_of_subtree([python_script_name], path_to_constants),
            python_script_name,
        )
        if not "/templates/" in p
    ]
    if len(path_to_python_script) > 1:
        logger.warning(
            f"""WARNING: find_script_file(): {python_script_name} found multiple times!"""
            + f"""The first one will be used of: {path_to_python_script}"""
        )
    elif len(path_to_python_script) == 0:
        logger.error(f"""ERROR:  find_script_file: {python_script_name} not found!""")
        raise FileNotFoundError(
            f"""File not found on local storage: {python_script_name}"""
        )
    path_to_python_script = path_to_python_script[0]
    return path_to_python_script


# %%
class Glue:
    def __init__(self, config):
        # AWS constants
        self.role = config["PROJECT_ROLE"]
        self.project_name = config["PROJECT_NAME"]
        self.stage = config["ENVIRONMENT"]
        self.bucket_name = config["BUCKET_NAME"]
        self.s3_glue_prefix = (
            config["S3_BASE_PREFIX"]
            + config["GLUE_GLOBALS"]["S3_GLUE_FOLDER_NAME"]
            + "/"
        )
        # Local constants
        self.line = config["LINE"]
        self.local_project_name = config["LOCAL_PROJECT_NAME"]
        self.local_project_short_name = config["LOCAL_PROJECT_SHORT"]
        # Other attributes
        self.name_prefix = f"{self.project_name}"
        self.base_name = ""
        self.glue_client = boto3.client("glue")

    def __str__(self):
        s = """
        Glue object with the following atrributes
        role: {},
        bucket_name: {},
        project_name (used for tagging glue objects): {},
        stage: {})
        """.format(
            self.role, self.bucket_name, self.project_name, self.stage
        )
        return s

    def get_base_name(self) -> str:
        return self.base_name

    def get_base_workflow_name(self) -> str:
        return f"""{self.line}-{self.local_project_short_name}"""

    def get_name_with_pre_suffix(self, name: str) -> str:
        if len(name):
            return "-".join(
                [
                    self.name_prefix,
                    "WORKFLOW",
                    self.get_base_workflow_name(),
                    name,
                    self.stage,
                ]
            )
        else:
            # Same minus 'name'
            return "-".join(
                [
                    self.name_prefix,
                    "WORKFLOW",
                    self.get_base_workflow_name(),
                    self.stage,
                ]
            )

    def get_full_workflow_name(self) -> str:
        return self.get_name_with_pre_suffix("")

    def get_job_list(self):
        return self.glue_client.list_jobs()["JobNames"]

    def get_trigger_list(self):
        return self.glue_client.list_triggers()["TriggerNames"]

    def get_workflow_list(self):
        return self.glue_client.list_workflows()["Workflows"]

    def job_exists(self, job_name):
        try:
            self.glue_client.get_job(JobName=job_name)
            return True
        except:
            return False

    def trigger_exists(self, trigger_name):
        try:
            self.glue_client.get_trigger(Name=trigger_name)
            return True
        except:
            return False

    def workflow_exists(self, workflow_name):
        try:
            self.glue_client.get_workflow(Name=workflow_name)
            return True
        except:
            return False

    def get_tags(self) -> dict:
        return {"ProjectName": self.project_name, "Stage": self.stage}

    def delete_job(self, job_name):
        if self.job_exists(job_name):
            logger.info(f"Deleting job {job_name}, this might take some time...")
            self.glue_client.delete_job(JobName=job_name)
            counter = 0
            while (job_name in self.get_job_list()) and (
                counter < 900 / 0.5
            ):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if job_name in self.get_job_list():
                logger.error(f"TIMEOUT ERROR deleting Job {job_name}.")
            else:
                logger.info(f"Success deleting job {job_name}")
        else:
            logger.warning(f"Job {job_name} does not exist.")

    def delete_trigger(self, trigger_name):
        if self.trigger_exists(trigger_name):
            logger.info(
                f"Deleting trigger {trigger_name}, this might take some time..."
            )
            self.glue_client.delete_trigger(Name=trigger_name)
            counter = 0
            while (trigger_name in self.get_trigger_list()) and (
                counter < 900 / 0.5
            ):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if trigger_name in self.get_trigger_list():
                logger.error(f"TIMEOUT ERROR deleting Trigger {trigger_name}.")
            else:
                logger.info(f"Succes deleting trigger {trigger_name}")
        else:
            logger.warning(f"Trigger {trigger_name} does not exist.")

    def delete_workflow(self, workflow_name):
        if self.workflow_exists(workflow_name):
            logger.info(
                f"Deleting workflow {workflow_name}, this might take some time..."
            )
            self.glue_client.delete_workflow(Name=workflow_name)
            counter = 0
            while (workflow_name in self.get_workflow_list()) and (
                counter < 900 / 0.5
            ):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if workflow_name in self.get_workflow_list():
                logger.error(f"TIMEOUT ERROR deleting Workflow {workflow_name}.")
            else:
                logger.info(f"Success deleting workflow {workflow_name}")
        else:
            logger.warning(f"Workflow {workflow_name} does not exist.")

    def get_job_info(self, job_name):
        if self.job_exists(job_name):
            return self.glue_client.get_job(JobName=job_name)
        else:
            logger.warning(
                f"Job {job_name} does not exist or you do not have access rights to it."
            )

    def get_trigger_info(self, trigger_name):
        if self.trigger_exists(trigger_name):
            return self.glue_client.get_trigger(Name=trigger_name)
        else:
            logger.warning(
                f"Trigger {trigger_name} does not exist or you do not have access rights to it."
            )

    def get_workflow_info(self, workflow_name):
        if self.workflow_exists(workflow_name):
            return self.glue_client.get_workflow(workflow_name)
        else:
            logger.warning(
                f"Workflow {workflow_name} does not exist or you do not have access rights to it."
            )


# %%
class GlueWorkflow(Glue):
    def __init__(self, config):
        super().__init__(config)
        self.config = config

        self.workflow_name = (
            f"{self.project_name}-WORKFLOW-{self.local_project_short_name}-{self.stage}"
        )
        self.jobs = {}
        self.triggers = {}
        self.description = (
            self.config["GLUE"]["description"]
            if "description" in self.config["GLUE"]
            else ""
        )

    def __str__(self):
        s = f"""
        GlueWorkflow object with the following atrributes
        name: {self.get_full_name()}
        """
        return s

    def get_full_name(self) -> str:
        return self.get_name_with_pre_suffix("")

    def exists(self):
        return self.workflow_exists(self.get_full_name())

    def add_job(self, job_index: str, job_config: dict) -> None:
        logger.info(
            f"Adding job with index '{job_index}' to workflow {self.get_base_workflow_name()}"
        )
        self.jobs[job_index] = GlueJob(self.config, job_config)

    def add_trigger(self, trigger_index: str, trigger_config: dict) -> None:
        self.triggers[trigger_index] = GlueTrigger(
            self.config, trigger_config, self.jobs
        )

    def create_workflow(self, overwrite=True):
        if self.exists() and not overwrite:
            logger.info(
                f"Workflow {self.get_full_name()} already exists (no overwrite; ignoring)"
            )
        else:
            if self.exists():
                self.delete()
            self.glue_client.create_workflow(
                Name=self.get_full_name(),
                Description=self.description,
                Tags=self.get_tags(),
            )
            counter = 0
            while (not self.exists()) and (counter < 900 / 0.5):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if not self.exists():
                logger.error(f"TIMEOUT ERROR creating Workflow {self.get_full_name()}.")
            else:
                logger.info(f"Success creating workflow {self.get_full_name()}")

    def create(self, overwrite=True):
        logger.info("Creating workflow...")
        self.create_workflow(overwrite)
        logger.info("Creating jobs...")
        for index, job in self.jobs.items():
            job.create(overwrite)
        logger.info("Creating triggers...")
        for index, trigger in self.triggers.items():
            trigger.create(overwrite)
        logger.info("Created workflow, jobs and triggers.")

    def delete(self):
        self.delete_workflow(self.get_full_name())


# %%
class GlueJob(Glue):
    """
    Class having methods to interact with AWS Glue
    """

    def __init__(self, config, job_config):
        super().__init__(config)
        # self.py_path = job_config["py_path"]
        self.py_path_name = job_config["py_path"].split("/")[-1]
        self.base_name = self.py_path_name.replace(".py", "")
        self.script_full_s3_path = (
            f"{self.s3_glue_prefix}{self.local_project_name}/{self.py_path_name}"
        )
        self.script_location = s3_utils.path_to_url([self.script_full_s3_path])[0]
        self.connections = (
            job_config["connections"] if "connections" in job_config else []
        )
        self.description = (
            job_config["description"] if "description" in job_config else ""
        )

    def __str__(self):
        s = f"""
        GlueJob object with the following atrributes
        name: {self.get_full_name()},
        script url: {s3_utils.path_to_url([self.script_full_s3_path])[0]},
        """
        return s

    def get_full_name(self) -> str:
        return self.get_name_with_pre_suffix(f"JOB-{self.get_base_name()}")

    def exists(self):
        return self.job_exists(self.get_full_name())

    def copy_script_to_s3(self):
        """
        1. Concatinates boiler plate code to glue job script
        2. Moves the concatenated glue job .py script to S3.
        """

        path_to_boilerplate_script = find_script_file("glue_boilerplate_configs.py")
        path_to_python_script = find_script_file(self.py_path_name)

        with open(path_to_boilerplate_script, mode="rb") as f:
            boilerplate_content = f.read()
        with open(path_to_python_script, mode="rb") as f:
            python_script_content = f.read()
        python_script_content = (
            boilerplate_content + bytes("\n", "utf-8") + python_script_content
        )

        logger.info(f"Writing {path_to_python_script} to {self.script_full_s3_path}")
        s3_utils.write_bytes(python_script_content, self.script_full_s3_path)

    def create(self, overwrite=True):
        if self.exists() and not overwrite:
            logger.warning(
                f"Job {self.get_full_name()} already exists (no overwrite; ignoring)"
            )
        else:
            if self.exists():
                logger.warning(f"Overwriting job {self.get_full_name()}")
                self.delete()

            self.copy_script_to_s3()

            glue_globals = misc_utils.config["GLUE_GLOBALS"]
            base_glue_s3_url = s3_utils.path_to_url([self.s3_glue_prefix])[0]
            s3_lib_url_prefix = (
                base_glue_s3_url + glue_globals["S3_LIBRARY_FOLDER_NAME"] + "/"
            )

            extra_py_files = ",".join(
                [
                    s3_lib_url_prefix + l if not l.startswith("s3:") else l
                    for l in glue_globals["EXTRA_WHEEL_FILES"]
                ]
            )

            command = {
                "Name": "pythonshell",
                "ScriptLocation": s3_utils.path_to_url([self.script_full_s3_path])[0],
                "PythonVersion": "3.9",
            }
            default_arguments = {
                "--JOB_NAME": self.get_full_name(),
                "--extra-py-files": extra_py_files,
                "--bucket_name": self.bucket_name,
                "--s3_glue_prefix": self.s3_glue_prefix,
                "--project_name": self.local_project_name,
            }
            if len(self.connections) > 0:
                self.glue_client.create_job(
                    Name=self.get_full_name(),
                    Description=self.description,
                    Role=self.role,
                    Command=command,
                    DefaultArguments=default_arguments,
                    Connections={"Connections": self.connections},
                    MaxRetries=1,
                    MaxCapacity=1,
                    GlueVersion="3.0",
                    Tags=self.get_tags(),
                )
            else:
                # Same, except no 'Connections=' parameter; found no way to specify empty list
                self.glue_client.create_job(
                    Name=self.get_full_name(),
                    Description=self.description,
                    Role=self.role,
                    Command=command,
                    DefaultArguments=default_arguments,
                    MaxRetries=1,
                    MaxCapacity=1,
                    GlueVersion="3.0",
                    Tags=self.get_tags(),
                )

            counter = 0
            while (not self.exists()) and (counter < 900 / 0.5):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if not self.exists():
                logger.error(f"TIMEOUT ERROR creating Job {self.get_full_name()}.")
            else:
                logger.info(f"Success creating job {self.get_full_name()}")

    def delete(self):
        self.delete_job(self.get_full_name())


# %%
class GlueTrigger(Glue):
    def __init__(self, config, trigger_config, workflow_jobs: dict):
        super().__init__(config)

        self.trigger_type = trigger_config["trigger_type"]
        self.trigger_schedule = trigger_config["trigger_schedule"]
        self.trigger_logical = (
            trigger_config["trigger_logical"]
            if "trigger_logical" in trigger_config
            else "AND"
        )

        if "triggered_by_jobs" in trigger_config:
            cfg_triggered_by_jobs = trigger_config["triggered_by_jobs"]
            triggered_by_jobs_indices = [
                self.find_job_object(j, workflow_jobs) for j in cfg_triggered_by_jobs
            ]
            self.triggered_by_jobs_full_names = [
                workflow_jobs[i].get_full_name() for i in triggered_by_jobs_indices
            ]
        else:
            self.triggered_by_jobs_full_names = []

        cfg_jobs_to_trigger = trigger_config["trigger_jobs"]
        jobs_to_trigger_indices = [
            self.find_job_object(j, workflow_jobs) for j in cfg_jobs_to_trigger
        ]
        jobs_to_trigger_base_names = [
            workflow_jobs[i].get_base_name() for i in jobs_to_trigger_indices
        ]
        self.base_name = "-AND-".join(jobs_to_trigger_base_names)
        self.jobs_to_trigger_full_names = [
            workflow_jobs[i].get_full_name() for i in jobs_to_trigger_indices
        ]
        self.description = (
            trigger_config["description"] if "description" in trigger_config else ""
        )

    def __str__(self):
        s = f"""
        GlueTrigger object with the following atrributes
        trigger_name: {self.get_full_name()}
        trigger_type: {self.trigger_type}
        trigger_schedule: {self.trigger_schedule}
        triggered_by: {self.triggered_by_jobs_full_names}
        triggering: {self.jobs_to_trigger_full_names}
        """
        return s

    def get_full_name(self) -> str:
        return self.get_name_with_pre_suffix(f"TRIGGER-{self.get_base_name()}")

    def exists(self):
        return self.trigger_exists(self.get_full_name())

    def find_job_object(self, search_item: str, glue_jobs: dict) -> str:
        "Find key in glue_jobs dict, referred to by search_item"

        logger.debug(f"""find_job_object(): resolving {search_item}""")
        result = ""
        name = "___._NoSuchName_.___"
        if search_item.startswith("job_name:"):
            name = search_item.replace("job_name:", "").strip()
        search_index = search_item.split(".")[-1]
        for idx, job in glue_jobs.items():
            logger.debug(f"""find_job_object(): testing against {idx}, {job}""")
            if (
                (name == job.get_base_name())
                or (name == job.get_full_name())
                or (search_index == idx)
            ):
                result = idx
        if result == "":
            logger.error(
                f"""ERROR: job name '{search_item}' not found in list of jobs."""
            )
            logger.info(
                f"""GlueTrigger.find_job_object(): normally, job with name {search_item} should be configured."""
            )
            raise ValueError(
                f"""GlueTrigger.find_job_object(): job name '{search_item}' not found in list of GlueJob."""
            )

        logger.debug(f"""find_job_object(): found {result}""")
        return result

    def get_actions_list(self) -> list:
        """Returns a list of actions"""

        actions = [{"JobName": name} for name in self.jobs_to_trigger_full_names]
        return actions

    def get_conditions_list(self) -> list:
        """
        Returns a list of conditions (i.e. conditions that fire the trigger) from the list "triggered_by_jobs" in the config after converting them to full glue job names
        and attaching the trigger_schedule as State for which trigger looks for in the job.
        """

        conditions = []
        for job_name in self.triggered_by_jobs_full_names:
            condition = {
                "LogicalOperator": "EQUALS",
                "JobName": job_name,
                "State": self.trigger_schedule,
            }
            conditions.append(condition)
        return conditions

    def create(self, overwrite=True):
        if self.exists() and not overwrite:
            logger.warning(
                f"Trigger {self.get_full_name()} already exists (no overwrite; ignoring)"
            )
        else:
            if self.exists():
                self.delete()
            if self.trigger_type == "SCHEDULED":
                logger.info(f"Creating scheduled trigger: {self.get_full_name()}")
                # call needs 'Schedule' parameter
                self.glue_client.create_trigger(
                    Name=self.get_full_name(),
                    Description=self.description,
                    WorkflowName=self.get_full_workflow_name(),
                    Type=self.trigger_type,
                    Schedule=self.trigger_schedule,
                    Actions=self.get_actions_list(),
                    Tags=self.get_tags(),
                    StartOnCreation=True,
                )
            if self.trigger_type == "CONDITIONAL":
                logger.info(f"Creating conditional trigger: {self.get_full_name()}")
                # call needs 'Predicate' parameter
                self.glue_client.create_trigger(
                    Name=self.get_full_name(),
                    Description=self.description,
                    WorkflowName=self.get_full_workflow_name(),
                    Type=self.trigger_type,
                    Predicate={
                        "Logical": self.trigger_logical,
                        "Conditions": self.get_conditions_list(),
                    },
                    Actions=self.get_actions_list(),
                    Tags=self.get_tags(),
                    StartOnCreation=True,
                )
            counter = 0
            while (not self.exists()) and (counter < 900 / 0.5):  # 900 seconds
                time.sleep(0.5)
                counter += 1
            if not self.exists():
                logger.error(f"TIMEOUT ERROR creating Trigger {self.get_full_name()}.")
            else:
                logger.info(f"Success creating trigger {self.get_full_name()}")

    def delete(self):
        self.delete_trigger(self.get_full_name())


# %% [markdown]
# ######## FOR CREATION OF COMBINED JOBS


# %%
def create_combined_glue_job_py(project_config: dict) -> str:
    """
    Creates a combined glue job .py file. It contains all the scripts specified (in the same order) in the Glue.job.py_path config. It places the file in the local project folder
    and names it {project_config['LOCAL_PROJECT_NAME']}_combined_glue_jobs.py.
    """
    output_file = f"""{misc_utils.get_full_dir_name_of_constants_file()}/{project_config['LOCAL_PROJECT_NAME']}/{project_config['LOCAL_PROJECT_NAME']}_combined_glue_jobs.py"""
    logger.info(f"Combining glue job .py files into {output_file}...")
    with open(output_file, "w") as outfile:
        outfile.write("\n\n")
        outfile.write("""from abt_epd_gpmo_aa import logger""")
        outfile.write("\n\n")
        for python_script_name in project_config["GLUE"]["job"]["py_path"]:
            path_to_python_script = find_script_file(python_script_name)
            with open(path_to_python_script, "r") as infile:
                outfile.write(
                    f"""logger.info("####---- START OF {python_script_name}----####")"""
                )
                outfile.write("\n\n")
                outfile.write(infile.read())
                outfile.write("\n\n")
                outfile.write(
                    f"""logger.info("####---- END OF {python_script_name}----####")"""
                )
                outfile.write("\n\n")
    logger.info(f"Combining glue job .py files into {output_file} DONE.")
    return output_file


# %%
def update_glue_config_for_combined_jobs(project_config: dict) -> None:
    """This updates inplace the 'project_config' parameter

    Creates a "fake" combined glue job config so that we can use the same process of creating multiple glue jobs for the combined glue job.
    """
    combined_py_path = (
        f"""{project_config['LOCAL_PROJECT_NAME']}_combined_glue_jobs.py"""
    )
    trigger_schedule = project_config["GLUE"]["trigger"]["trigger_schedule"]
    if "connections" in project_config["GLUE"]["job"]:
        connections = project_config["GLUE"]["job"]["connections"]
    else:
        connections = []
    job_description = (
        f"""This job contains {' '.join(project_config["GLUE"]["job"]["py_path"])}"""
    )
    workflow_description = f"""This workflow runs {' '.join(project_config["GLUE"]["job"]["py_path"])} in one script."""

    # update configs

    ## add workflow description
    project_config["GLUE"]["description"] = workflow_description

    project_config["GLUE"]["trigger"] = {
        "0": {
            "trigger_type": "SCHEDULED",
            "trigger_schedule": trigger_schedule,
            "trigger_jobs": ["job.0"],
        }
    }
    project_config["GLUE"]["job"] = {
        "0": {
            "description": job_description,
            "py_path": combined_py_path,
            "connections": connections,
        }
    }
    logger.info("Project config adapted to combined glue job requirements.")
