# %%
"""
Generate pseudo Batch ID tag data in the format of PCS / DCS / DeltaV / OSI-Pi data, based on sensor tag data

TODO: in the future, replace 'batch_id' by 'value_string'
"""

# %%
import pandas as pd

# %%
# Load main modules of our team library
# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, the main config
from abt_epd_gpmo_aa import logger, preprocess_pcs_utils, preprocess_utils, tag_utils

# %%
"""
Create all pseudo tags for all batches (Generic functions)
"""


# %%
def generate_batch_id(epochs: pd.Series, prefix: str, period: int) -> pd.Series:
    """Generate batch IDs based on prefix and epochs

    Arguments:
    - epochs: Start times of all batches in epoch
    - prefix: prefix to put in front of numeric part of the ID
    - period: in seconds (epoch integer div period -> batch ID)
    Returns:
        Series of strings containing the pseudo batch IDs

    Remarks
    This is intended as a convenient helper for project specific code that often
    needs this kind of functionality.
    """

    batch_id = (epochs.astype(int) // period).astype(str)
    batch_id = prefix + batch_id
    return batch_id


# %%
def transform_df(df: pd.DataFrame) -> pd.DataFrame:
    """convert from "batch_id", "batch_start", "batch_end" to "epoch", "value_string"(="batch_id")

    Note: this function is intended to be used by create_one_tag_data() only.
    """

    # First convert to two column format "epoch", "value_string"(="batch_id")
    # End times that are not equal to next start times get an empty value
    df_start = (
        df[["batch_id", "batch_start"]]
        .sort_values(by="batch_start")
        .reset_index(drop=True)
        .copy()
    )
    df_start = df_start.rename(
        columns={"batch_start": "epoch", "batch_id": "value_string"}
    )

    # Add "empty" values at the end of a period, unless a new batch starts at the same time
    df_empty = (
        df[["batch_start", "batch_end"]]
        .sort_values(by="batch_end")
        .reset_index(drop=True)
        .copy()
    )
    df_empty = df_empty.rename(columns={"batch_end": "epoch"})
    # get next start and fill last position with larger value than we will encounter in 200 years
    df_empty["end_of_empty_time"] = df_empty["batch_start"].shift(
        periods=-1, fill_value=2e10
    )
    df_empty["duration"] = (df_empty["end_of_empty_time"] - df_empty["epoch"]).abs()
    # only keep end (empty value) events with some duration (> 1.0 s),
    # otherwise next non-empty marks end of previous non-empty period
    df_empty = (
        df_empty.loc[df_empty["duration"] > 1.0, ["epoch"]]
        .reset_index(drop=True)
        .copy()
    )
    df_empty["value_string"] = ""

    # Now combine the "epoch", "value" table and extend with "tag"
    df_ret = (
        pd.concat((df_start, df_empty), axis=0, join="outer", ignore_index=True)
        .sort_values(by="epoch")
        .reset_index(drop=True)
        .copy()
    )
    return df_ret


# %%
def create_one_tag_data(df_batch_start_end: pd.DataFrame, tag: str) -> pd.DataFrame:
    """Convert 'start/stop' DataFrame and add all required columns

    Arguments:
    - df_batch_start_end : DataFrame with the following columns: ["batch_id", "batch_start", "batch_end"]
    - tag : name of the tag to generate
    Returns:
        DataFrame with columns: ["row_id", "tag", "prev_row_id", "epoch", "value", "partition_id"]
    Description:
    These columns are filled with the folowing
    - 'tag' is filled with the same argument;
    - 'epoch' is taken from the batch_start and batch_end columns from argument df_start;
    - 'value' is filled with 'batch_id' if epoch is taken from batch_start and "" otherwise;
    - 'row_id' is generated in the normal way based on tag and epoch
    - 'prev_row_id' is copied from 'row_id' of a previous row
    - 'partition_id' is generated in the normal way based on epoch.
    """

    # convert from "batch_id", "batch_start", "batch_end" to "epoch", "value_string"(="batch_id")
    df = transform_df(df_batch_start_end)

    # add "tag" and "row_id"
    df["tag"] = tag_utils.convert_tag_name(tag)
    df["row_id"] = preprocess_utils.generate_rowid(df, ["tag", "epoch"])

    # Prepare for generic preprocessing step
    # df_lookup will be "None" in case it is not there
    df_lookup = preprocess_pcs_utils.read_tags_lookup_table()
    df_last = pd.DataFrame(columns=["tag", "epoch", "row_id"])
    return preprocess_pcs_utils.process_generic_step_2(df, df_last, df_lookup)


# %%
"""Project specific functions"""

# %% [raw]
# def get_all_tags_for_cache() -> list:
#     """Get list of existing tag names (strings) used for calculating the pseudo tags"""
#

# %% [raw]
# def get_list_of_items() -> list:
#     """Get items to iterate over, each item results in a tag"""
#

# %% [raw]
# def get_batch_id_plus_times(item: str) -> pd.DataFrame:
#     """For each item (becoms a pseudo tag), determine start and end time and batch_id.
#
#     The resulting DataFrame must contain the columns:
#     - batch_id : string with unique ID (within the pseudo tag) identifying the batch
#     - batch_start : float batch start time in epoch
#     - batch_end : float batch end time in epoch
#     """
#

# %%
"""Generic part"""


# %%
def write_pcs_pseudo_data(df: pd.DataFrame, extra_table_name: str = "") -> None:
    """
    Write all data to one or more (different type) tables

    Argument:
    - df:   pd.DataFrame containing columns
        * "row_id" : unique ID foreach record (to connect to next row using 'prev_row_id'),
        * "tag" : name of the new pseudo-tag, or the tag ID in case of lookup table
        * "prev_row_id" : to connect to previous row via 'row_id',
        * "epoch" : time in Unix epoch (seconds since 1-1-1970 00:00:00UTC),
        * "value_string" : value in string form; will be converted upon split over tables,
        * "partition_id" : not used; consistent with other PCS processing.
    """
    if not df.empty:
        logger.info(f"Writing pcs pseudo batch ID data ({df.shape[0]} data lines)...")
        unique_tags = df["tag"].unique().tolist()
        df_lookup = preprocess_pcs_utils.read_tags_lookup_table()
        if df_lookup is not None:
            df_lookup = df_lookup.loc[
                df_lookup["tag_id"].isin(unique_tags), ["tag_id", "type"]
            ].copy()

            element_types = {
                row["tag_id"]: row["type"] for idx, row in df_lookup.iterrows()
            }
        else:
            # default type "s" for "pre lookup table" pseudo tags
            element_types = {k: "s" for k in df["tag"].unique().tolist()}

        type_conversion_def = preprocess_pcs_utils.get_base_tag_type_definitions()

        name = f"""{misc_utils.config['PCS_TABLE']}_{misc_utils.config['LOCAL_PROJECT_SHORT']}"""
        s3_path = f"""{misc_utils.config['PCS_S3_PATH']}{misc_utils.config['LOCAL_PROJECT_SHORT']}"""
        if len(extra_table_name):
            name += "_" + extra_table_name
            s3_path += "_" + extra_table_name
        name += "_pseudo"
        s3_path += "_pseudo"
        base_table_info = {
            "name": name,
            "s3_path": s3_path,
            "overwrite": True,
        }
        str_val_col = "value_string"
        val_col = "value"

        preprocess_utils.write_preprocessed_data_per_type(
            df,
            split_column="tag",
            element_types=element_types,
            type_conversion_def=type_conversion_def,
            base_table_info=base_table_info,
            str_val_col=str_val_col,
            val_col=val_col,
        )
    else:
        logger.warning("No PCS preprocessed pseudo data.")


# %% [raw]
#
