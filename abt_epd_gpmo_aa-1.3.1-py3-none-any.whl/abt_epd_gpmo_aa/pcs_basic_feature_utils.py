# %%
"""
Derive features from PCS / DCS / DeltaV / OSI-Pi data

See the OneNote file GLB-EPD-AIDA 02 Kedro2AWS, section 'New Architecture', page 'PCS Preprocessed -> feature'

This module provides the following functions:
fucntions to get info about the work to do:
- def get_feature_definitions() -> dict:  # get the definitions from the config files
- def get_feature_names(feature_definitions: dict) -> list:  # get all feature names that are defined in the definition
- def get_tags_in_use(feature_definitions: dict) -> list:  # get all tags needed according to the definition
fucntions regarding existing results
- def erase_last_features(nr_partitions: int) -> None:  # erase last features that are possibly affected by additional data
- def get_last_features() -> pd.DataFrame:  # Get existing features (overlapping with defined) and the time of the most recent
- def update_last_datapoints(df_last: pd.DataFrame, df_new: pd.DataFrame) -> pd.DataFrame:  # update cached values in 'df_last'
fucntions to determine the relevant time period to process next
- def get_pcs_data_time_range() -> tuple:  # get full time range of available (floating point) tag data
- def get_time_of_last_existing_feature()  # get info from cache 'df_last' -> needed in pcs_batch_time module
- def get_cache_period_start()  # determine new start time for tag data cache (internal, used by get_cache_period)
- def get_cache_dynamic_period()  # first go on determining end time for tag data cache (internal, used by get_cache_period)
- def get_cache_period()  # get start-end time for caching of tag data
fucntions to do the work and store results
- def create_features_for_group()  # (internal, used by create_features_with_same_timing_def)
- def create_features_with_same_timing_def()  # (internal, used by create_pcs_features_since_last)
- def create_pcs_features_since_last()  # main function to call to calculate new features according to definition
- def write_pcs_features(df: pd.DataFrame) -> None:  # write calculated features to database


"""

# %%
import logging

# %%
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import (
    athena_utils,
    logger,
    misc_utils,
    pcs_batch_time,
    tag_functions,
    tag_utils,
)

# %%
PCS_FEATURE_DEFINITION_FILES = r"pcs_feature_definition_*"
PCS_FEATURE_TABLE = misc_utils.config["FEATURES_TABLE_PREFIX"] + "pcs"


# %%
"""
Helper functions to get info about the work to do
"""


# %%
def get_feature_definitions(type_str: str = "float") -> dict:
    """Determine if feature definitions are in json or TOML, read accordingly

    Return:
    - dict with two keys: "batch_time_refinements" and "feature_groups"
    """

    definition_filename_pattern = PCS_FEATURE_DEFINITION_FILES
    if type_str != "float":
        definition_filename_pattern = type_str + "_" + definition_filename_pattern
    full_pcs_feature_definitions = misc_utils.find_read_multi_file_definition(
        def_name=definition_filename_pattern,
        append_keys=["batch_time_refinements", "feature_groups"],
    )
    return full_pcs_feature_definitions


# %%
def get_feature_names(feature_definitions: dict) -> list:
    """Find all feature names defined in all features in all feature groups

    Description:
    Return list of tags with their standard (tag_utils.convert'ed names). Only return
    names that actually occur in the preprocessed PCS data tables. So ignoring
    tags that are in the 'undefined' table and the ones starting with 'const_' and
    the ones that start with 'pseudo_'.
    Note that the feature name is a concatenation of the feature_group_name, '_' and
    the functions defined for that feature_group_name.
    """

    feature_names = []
    for feature_group in feature_definitions["feature_groups"]:
        feature_group_name = feature_group["feature_group_name"]
        for function in feature_group["functions"]:
            feature_names.append(feature_group_name + "_" + function)

    return feature_names


# %%
def get_tags_in_use(feature_definitions: dict) -> list:
    "Find all tags defined in batch_time_refinements and feature_groups"

    tag_names = []
    batch_time_refinements = feature_definitions["batch_time_refinements"]
    for refinement_def in batch_time_refinements:
        tag_names.append(refinement_def["batch_tag"])
        for refine in refinement_def["start_refinements"]:
            if "tag" in refine:
                tag_names.append(refine["tag"])
        for refine in refinement_def["end_refinements"]:
            if "tag" in refine:
                tag_names.append(refine["tag"])

    feature_groups = feature_definitions["feature_groups"]
    for feature_group in feature_groups:
        tag_names.extend(feature_group["data_tags"])

    # Get all tags available from PCS data
    pcs_tag_list = tag_utils.get_tag_list(include_undefined=False)

    # Filter out pseudo-tags, like 'CONST_F_...' and the ones in '..._undefined'
    # first convert to 'standard names'
    tag_names = [tag_utils.convert_tag_name(t) for t in tag_names]
    tag_names = [t for t in tag_names if t in pcs_tag_list]

    # Get list of unique tag names
    tag_names = list(dict.fromkeys(tag_names))

    return tag_names


# %%
"""
Helper functions regarding existing results
"""


# %%
def erase_last_features(nr_partitions: int, type_str: str = "float") -> None:
    "Erase last features"

    # Some features may be incorrect due to unavailable data, so erase the last ones
    try:
        athena_utils.delete_last_table_partition(
            table=PCS_FEATURE_TABLE + "_" + type_str, nr_partitions=nr_partitions
        )
    except Exception as err:
        logger.warning(f"WARNING: Remove last two partitions FAILED: {err}")
        # Possibly they did not exist yet, so no problem


# %%
def get_last_features(type_str: str = "float") -> pd.DataFrame:
    "Get batch-ID and timestamp of most recent features"

    df_last = pd.DataFrame(columns=["feature_name", "batch_id", "epoch"])
    try:
        df_last = athena_utils.get_last_datapoints(
            table=PCS_FEATURE_TABLE + "_" + type_str,
            by_field="feature_name",
            time_field="epoch",
            extra_fields=["batch_id"],
        )
    except Exception as err:
        logger.warning(f"WARNING: get_last_datapoints FAILED: {err}")

    return df_last


# %%
def update_last_datapoints(df_last: pd.DataFrame, df_new: pd.DataFrame) -> pd.DataFrame:
    """Update the data frame with most recent features

    Arguments:
    - df_last : the previous data frame that has to be updated
    - df_new : the data frame containing all newly calculaterd features
    Return:
    Data frame with new latest 'epoch' & 'batch_id' for each 'feature_name'
    """
    if df_new.shape[0] == 0:
        return df_last

    df_new_last = pd.concat(
        (df_last, df_new[["feature_name", "epoch", "batch_id"]]),
        axis=0,
        join="outer",
        ignore_index=True,
    )
    df_new_last = df_new_last.sort_values(
        by=["feature_name", "epoch"], ignore_index=True
    )
    return df_new_last.drop_duplicates(
        subset=["feature_name"], keep="last", ignore_index=True
    )


# %%
"""
Helper functions to determine the relevant time periods within the start and end times of the batches to process
"""


# %%
def get_pcs_data_time_range() -> tuple:
    "Get time extremes of preprocessed PCS data"

    return (
        tag_utils.get_maxmin_timestamp(most_recent=False),
        tag_utils.get_maxmin_timestamp(most_recent=True),
    )


# %%
def get_time_of_last_existing_feature(
    df_last: pd.DataFrame, new_features: list
) -> float:
    "Get time of last calculated existing features (take the oldest)"

    if len(df_last["feature_name"]) < len(new_features):
        last_feature_list = df_last["feature_name"].to_list()
        logger.info(
            f"Adding new features: {[f for f in new_features if not f in last_feature_list]}"
        )
        # indicate "don't use" (because of adding new features)
        return -1.0
    else:
        # Most relaxed is from start time of oldest of the most recent features
        # if it is later in time then maximum overlap (cache_from found above)
        # This should only be done if all feature names are present in df_last
        return df_last["epoch"].min()


# %%
def get_cache_period_start(
    available_pcs_data: tuple,
    previous_cache_time_range: tuple,
    time_of_last_existing_feature: float,
) -> float:
    "Determine the start of the next period to cache - used in get_cache_period()"

    # Most conservative is from the start of available data (i.e. process all)
    cache_from = available_pcs_data[0]

    # Next conservative is max overlap with previous loop (if not in first loop)
    previous_cache_end_time = previous_cache_time_range[1]
    if previous_cache_end_time > 0.0:
        cache_from = (
            previous_cache_end_time
            - misc_utils.config["PCS_FEATURE_PROC_CACHE_PERIOD_MAX_OVERLAP"]
        )

    # Most relaxed is based on existing features.
    # Only if
    # - time of existing features is usable ( > 0)
    # - it will result in skipping the processing of data ( > cache_from (> 0))
    if time_of_last_existing_feature > cache_from:
        logger.info(
            f"Using time_of_last_existing_feature ({time_of_last_existing_feature})"
            + f" as it is greater than cache_from ({cache_from})"
        )
        cache_from = time_of_last_existing_feature - 1000.0

    return cache_from


# %%
def get_cache_dynamic_period(
    previous_cache_time_range: tuple,
    min_cache_size: float,
    mem_available: float,
    mem_used: float,
) -> float:
    "Determine dynamic, memory based, part of cache size - used in get_cache_period()"

    if previous_cache_time_range[1] <= 0.0:
        # First loop
        return 0.0
    prev_total_period = previous_cache_time_range[1] - previous_cache_time_range[0]
    prev_dynamic_period = prev_total_period - min_cache_size
    # Determine conversion factor from memory to period
    period_p_gb = prev_total_period / (mem_used + 1.0)
    logger.debug(
        "DEBUG: conversion factor mem to period:"
        + f" {period_p_gb} s/GB = previous total period ({prev_total_period})/mem_used ({mem_used})"
    )
    # Aim for 70% of available memory, convert from mem to period, subtract fixed period
    optimal_dynamic_period = (0.7 * mem_available * period_p_gb) - min_cache_size
    # Dampen the change
    dynamic_period = 0.15 * prev_dynamic_period + 0.85 * optimal_dynamic_period
    logger.debug(
        f"DEBUG: new dynamic_period: {dynamic_period}, prev_dynamic_period: {prev_dynamic_period}"
    )
    return dynamic_period


# %%
def get_cache_period(
    available_pcs_data: tuple,
    previous_cache_time_range: tuple,
    time_of_last_existing_feature: float,
    mem_available: float,
    mem_used: float,
) -> tuple:
    """Determine the next period to cache, maximizing usage of available memory

    Arguments:
    - available_pcs_data : (from, to) epoch pair
    - previous_cache_time_range : previous '(cache_from, cache_to)'; both <= 0 for first loop
    - time_of_last_existing_feature : cache startpoint based on existing features; <= 0: don't use
    - mem_available : memory available at start of processing
    - mem_used : memory used during processing of the previous cache period
    Returns:
    - tuple with time period to cache next: ('from', 'to') in epoch
    """

    cache_from = get_cache_period_start(
        available_pcs_data,
        previous_cache_time_range,
        time_of_last_existing_feature,
    )

    min_cache_size = (
        misc_utils.config["PCS_FEATURE_PROC_CACHE_PERIOD_MAX_OVERLAP"]
        + misc_utils.config["PCS_FEATURE_PROC_CACHE_PERIOD_MIN_NEW"]
    )
    # Determine dynamic period based on memory usage
    dynamic_period = get_cache_dynamic_period(
        previous_cache_time_range,
        min_cache_size,
        mem_available,
        mem_used,
    )

    # Set initial value for cache_to
    cache_to = cache_from + min_cache_size + dynamic_period
    # Correct cache_from and cache_to if we try to cache more than we have available
    if cache_to > available_pcs_data[1]:
        logger.info(
            f"Limiting cache_to to available PCS data: {available_pcs_data[1]}."
        )
        cache_to = available_pcs_data[1]
        if cache_from > cache_to - min_cache_size:
            cache_from = cache_to - min_cache_size

    return (cache_from, cache_to)


# %%
"""
Helper functions to do the actual work and write the results
"""


# %%
def create_features_for_group(
    feature_group: dict,
    df_batch_timings: pd.DataFrame,
) -> pd.DataFrame:
    "Calculate all features that use the same _data and_ time definition"

    # Retrieve all sensor data needed for one feature group for all batches
    # Loop over all batches
    #     Create all features for the feature group
    logger.info(f"Processing feature group: {feature_group['feature_group_name']}")
    # Prepare data frame to return
    ret_dfs = [pd.DataFrame(columns=["feature_name", "batch_id", "epoch", "value"])]
    # All features in one feature group use the same sensor data
    # Get all sensor data for a specific feature group
    raw_tag_data = tag_utils.get_tag_ndarray_list(
        tags=feature_group["data_tags"],
        time_range=(
            df_batch_timings["start_time"].min(),
            df_batch_timings["end_time"].max(),
        ),
    )
    # Remove NaNs from data if requested (and if possible)
    if "ignore_nan" in feature_group and feature_group["ignore_nan"]:
        raw_tag_data = tag_utils.remove_nan_list(raw_tag_data)

    # Raw data contains different epochs. Align the epochs and values using interpolation.
    tag_data = tag_utils.align_epoch_for_ndarray_list(raw_tag_data)

    # Now calculate all features in the group for each batch
    # Loop over all new batches since our last run
    for index, batch in df_batch_timings.iterrows():
        logger.info(
            f"batch: {batch.batch_id}, start: {batch.start_time}, end: {batch.end_time}"
        )
        # Select sensor data of the relevant time period for the current batch only
        batch_data = tag_utils.select_ndarray_list(
            tag_data_list=tag_data,
            time_range=(batch["start_time"], batch["end_time"]),
        )

        function_parameters = {}
        if "function_parms" in feature_group:
            function_parameters = feature_group["function_parms"]
        # Loop over all individual features/functions in the feature group
        for function in feature_group["functions"]:
            logger.debug(f"DEBUG: function loop - function: {function}")
            value = tag_functions.tag_functions[function](
                batch_data, function_parameters
            )
            logger.debug(f"DEBUG: function: {function}, value: {value}")
            ret_dfs.append(
                pd.DataFrame(
                    {
                        "feature_name": [
                            f"{feature_group['feature_group_name']}_{function}"
                        ],
                        "batch_id": [batch["batch_id"]],
                        "epoch": [batch["start_time"]],
                        "value": [value],
                    }
                )
            )

    df_ret = pd.concat(ret_dfs, axis=0, join="outer", ignore_index=True)
    logger.debug(f"DEBUG: create_features_for_group() df_ret.shape: {df_ret.shape}")
    return df_ret


# %%
def create_features_with_same_timing_def(
    refinement: dict, df_last: pd.DataFrame, feature_groups: list
) -> pd.DataFrame:
    "Calculate all features that use the same time definition"

    # Determine timings for new batches according to time refinement def.
    # Loop over all feature groups sharing the same time refinement def.
    #     Create all features for the feature group

    logger.info(f"Batch time refinement definition: {refinement['refinement_name']}")
    # Prepare data frame to return
    ret_dfs = [pd.DataFrame(columns=["feature_name", "batch_id", "epoch", "value"])]
    # Select all feature groups that use the current timing definition
    feature_groups_with_same_timing = [
        g for g in feature_groups if g["refinement"] == refinement["refinement_name"]
    ]
    # Determine timings for new batches according to time refinement def.
    df_batch_timings = pcs_batch_time.get_new_batch_timings(
        refinement, df_last, feature_groups_with_same_timing
    )

    # Nothing to do if there is no data of new batches for this refinement definition
    if df_batch_timings.empty:
        logger.debug("DEBUG: Nothing to do: df_batch_timings is empty.")
        return ret_dfs[0]

    # Loop over all feature groups sharing the same time refinement def.
    for feature_group in feature_groups_with_same_timing:
        ret_dfs.append(create_features_for_group(feature_group, df_batch_timings))

    df_ret = pd.concat(ret_dfs, axis=0, join="outer", ignore_index=True)
    logger.debug(
        f"DEBUG: create_features_with_same_timing_def() df_ret.shape: {df_ret.shape}"
    )
    return df_ret


# %%
def create_pcs_features_since_last(
    df_last: pd.DataFrame, feature_definitions: dict
) -> pd.DataFrame:
    "Determine all features for new batches since the last batch"

    # Loop over all time refinement definitions
    #     Create all features with the specific time refinement definition
    #
    # Note: take a look at the OneNote description mentioned in the docstring at the top of this file.

    def set_log_level(refinement: dict, debug: bool) -> None:
        "En-/disable debug loglevel for current time refinement"
        if "debug" in refinement and len(refinement["debug"]) > 1:
            if debug:
                logger.setLevel(logging.DEBUG)
                logger.debug("Debugging enabled.")
            else:
                logger.debug("Setting LOG level to INFO.")
                logger.setLevel(logging.INFO)

    # Prepare data frame to return
    ret_dfs = [pd.DataFrame(columns=["feature_name", "batch_id", "epoch", "value"])]

    batch_time_refinements = feature_definitions["batch_time_refinements"]
    feature_groups = feature_definitions["feature_groups"]
    # Loop over all time refinement definitions
    for refinement in batch_time_refinements:
        set_log_level(refinement, debug=True)

        ret_dfs.append(
            create_features_with_same_timing_def(refinement, df_last, feature_groups)
        )

        set_log_level(refinement, debug=False)

    df_ret = pd.concat(ret_dfs, axis=0, join="outer", ignore_index=True)
    logger.debug(
        f"DEBUG: create_pcs_features_since_last() df_ret.shape: {df_ret.shape}"
    )
    return df_ret


# %%
def write_pcs_features(df: pd.DataFrame, type_str: str = "float") -> None:
    """
    Write one table
    """

    if not df.empty:
        logger.info(f"Writing pcs feature data ({df.shape[0]} new features)...")

        df["partition_id"] = (
            df.epoch.astype("int64")
            // misc_utils.config["PCS_FEATURES_PARTITION_PERIOD"]
        ).astype("int64")
        athena_utils.append_table(
            df,
            table=PCS_FEATURE_TABLE + "_" + type_str,
            s3_folder=misc_utils.config["FEATURES_S3_PATH"] + "pcs/" + type_str + "/",
            partition_cols=["partition_id"],
        )
    else:
        logger.warning("No new PCS features.")
