# %%
"""
Derived feature utilities for previously generated features or feature-like data' used mostly for derive_features.py job.

Configuration items in misc_utils.config
- FEATURES_TABLE_PREFIX

This module provides:
 - def calculate_derived_features(df_features: pd.DataFrame, derived_definitions: list) -> pd.DataFrame:
 - split_derived_features(df_derived_features: pd.DataFrame) -> dict


"""

# %%
import numpy as np
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import (
    basic_feature_utils,
    derived_feature_functions,
    logger,
    misc_utils,
)


# %%
def calculate_derived_features(
    df_features: pd.DataFrame, derived_definitions: list
) -> pd.DataFrame:
    """
    Append derived aggregated features from smart feature data to dataframe

    Argument:
    - df_features : contains dataframe with feature data: one row per batch, one column per feature
    - derived_definitions : list with definition of derived features
    Returns:
    DataFrame : similar DataFrame as df_feature including new features
    """

    df_result = df_features.copy()
    logger.debug(
        f"calculate_derived_features - df_result initial set to:\n{str(df_result)}"
    )

    for item in derived_definitions:
        logger.info(f'Processing derived feature {item["feature_name_new"]}...')

        # Prepare dataframe with columns from feature_source or feature_regexp
        if "feature_source" in item:
            feature_columns = item["feature_source"]
            if "feature_regexp" in item:
                raise ValueError(
                    f"Both 'feature_source' and 'feature_regexp' are defined for {item}."
                )
        else:
            feature_columns = df_result.columns[
                df_result.columns.str.contains(item["feature_regexp"])
            ].to_list()
            if len(feature_columns) == 0:
                logger.info(
                    f'ERROR: No features found matching {item["feature_regexp"]}'
                )
                continue

        logger.debug(f"Columns selected: {feature_columns}.")

        # Calculate column with derived feature
        feature_function = derived_feature_functions.feature_functions[
            item["calculation"]
        ]
        new_feature = feature_function(
            df=df_result.copy(),
            feature_source=feature_columns,
        )
        if "dtype" in item and item["dtype"] == "float":
            new_feature[new_feature.isna()] = np.nan
            new_feature = new_feature.astype(float)
        elif "dtype" in item:
            new_feature = new_feature.astype(
                item["dtype"]
            )  # to allow pandas nullable string/Int64 type

        if not new_feature.isna().all():
            df_result[item["feature_name_new"]] = new_feature
        else:
            logger.warning(
                f'Derived feature {item["feature_name_new"]} is all NA, so not added.'
            )

    logger.debug(f"calculate_derived_features - full df_result:\n{str(df_result)}")

    new_columns = [
        c
        for c in df_result.columns.to_list()
        if (
            c not in df_features.columns.to_list()
            and not c.startswith("__tmp")
            and c != "batch_id"
        )
    ]
    new_columns.append("batch_id")
    logger.info(f"calculate_derived_features - Columns returned: {new_columns}.")
    logger.debug(
        f"calculate_derived_features - df_result.shape: {df_result[new_columns].shape}"
    )
    logger.debug(
        f"calculate_derived_features - df_result[new_columns]:\n{str(df_result[new_columns])}"
    )

    return df_result[new_columns]


# %%
def split_derived_features(df_derived_features: pd.DataFrame) -> dict:
    """
    Not all features exist for all batches, resulting in many NA values
    Split df_derived_features into value types (float, int, string)
    Unpivot (melt) splitted derived feature tables
    """

    # split derived features in float, int and string -> unpivot -> remove rows with value = NaN -> add to dict
    derived_feat_dict = {}
    type_list = ["float", "int", "string"]
    for item_type in type_list:
        col_type = df_derived_features.select_dtypes(
            include=[item_type]
        ).columns.to_list()
        logger.info(
            f"""split_derived_features - Columns returned for type "{item_type}": {col_type}."""
        )
        if not "batch_id" in col_type:
            col_type.append("batch_id")
        if len(col_type) > 1:  # more items than just "batch_id"
            df_unpivot = basic_feature_utils.melt_dataframe(
                df_derived_features[col_type]
            )
            df_unpivot = df_unpivot.dropna(subset=["value"]).reset_index(drop=True)

            # add dataframe to dict
            table_name = (
                f"{misc_utils.config['FEATURES_TABLE_PREFIX']}derived_{item_type}"
            )
            derived_feat_dict[table_name] = df_unpivot
            logger.info(
                f"Dataframe of type {item_type} unpivoted (rows,cols): {df_unpivot.shape}"
            )

    return derived_feat_dict
