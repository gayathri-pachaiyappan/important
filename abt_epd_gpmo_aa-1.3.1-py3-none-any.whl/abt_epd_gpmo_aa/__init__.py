# %%
import importlib.metadata
import logging
import sys

# %%
__version__ = importlib.metadata.version("abt_epd_gpmo_aa")

# %%
logger = logging.getLogger()

# %%
# Remove existing handlers
if logger.handlers:
    for handler in logger.handlers:
        logger.removeHandler(handler)

# %%
logger = logging.getLogger()
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter(
    "%(asctime)s %(levelname)-8s [%(filename)30s:%(lineno)d] %(message)s"
)
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)
