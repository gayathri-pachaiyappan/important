# %%
"""
Module for basic features

This script contains the functions to write data to Glue Catalog tables (on S3) with the following fields
- feature_name
- batch_id
- value (one table file per type: string, float, int)

Other functions
- mapping
- load data
- pivot dataframe
- unpivot dataframe (melt)

"""

# %%
import pandas as pd

# %%
# Load main modules of our team library
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import athena_utils, logger

# %%
# import numpy as np


# %%
def load_data(table_name: str, complex_select_query: str) -> pd.DataFrame:
    # Load preprocessed smart and sap data
    # Load string data
    """
    Load preprocessed smart and sap data from string, int and float tables

    table_name  contains table name to load
    complex_select_query  contains query of columns to load

    Return:
    df         contains smart data of requested data type
    """

    logger.info(f"Load data from table {table_name}...")

    """
    Column 'result_attribute' in float and int data contains < or > characters. This column is not used
    because QB did not use it either. In the future it may be necessary to reconsider this if the relevant features
    have a large effect in the models. Hence column 'result_attribute' is not retrieved from table.
    """
    query_string = ""

    df = athena_utils.get_table_free_query(
        table_name, complex_select_query, query_string
    )
    logger.info(f"Loaded from {table_name} (rows,cols): {df.shape}")

    if df.empty:
        logger.warning(f"Dataframe {table_name} is empty")
        raise ValueError("The dataframe is empty")

    return df


# %%
def map_feature_name(s: pd.Series, feature_map_dict: dict) -> pd.Series:
    """
    Replace values in s that match a key in the dict with the corresponding value in the dict
    """
    # map feature_map_dict to pd.Series and change key by value
    s = s.map(feature_map_dict)
    logger.info("Mapped feature_map_dict to pd.Series")

    return s


# %%
def pivot_dataframe(df: pd.DataFrame, keep_cols: list = ["batch_id"]) -> pd.DataFrame:
    """
    Pivot dataframe
    Function is defined for features with similar parameters (to simplify code)
    """
    df = df.pivot_table(
        index=keep_cols,
        columns="feature_name",
        values="value",
        aggfunc="first",
    ).reset_index(drop=False)
    return df


# %%
def melt_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Melt dataframe
    Function is defined for features with similar parameters (to simplify code)
    """
    df = df.melt(
        id_vars="batch_id",
        var_name="feature_name",
        value_name="value",
    )
    return df


# %%
def write_table(df: pd.DataFrame, table_name: str, s3_folder_name: str) -> None:
    """
    Write one table
    Table_name: name of table e.g. f"{features_table}_{value_type}"
    s3_folder_name: name folder on S3 e.g. f".../{value_type}/"
    """

    if not df.empty:
        logger.info(f"Write features to {table_name}...")
        athena_utils.overwrite_table(
            df,
            table=table_name,
            s3_folder=s3_folder_name,
        )
        logger.info(f"Written to S3 of {table_name} (rows,cols): {df.shape}")
    else:
        logger.warning(f"No new features of type {table_name}.")


# %%
def write_features(data_dict: dict, table_name: str, s3_folder_name: str) -> None:
    """
    Write features to separate Glue catalog tables for float, int and string
    data_dict: dict with dataframes, one for each data type; keys should end with float|int|string
    Table_name: base name of table excluding the final "_{data type}"
    s3_folder_name: base name folder excluding the final "{data type}/"
    """
    type_list = ["float", "int", "string"]
    for item_type in type_list:
        # Using dictionary comprehension + endswith()
        # Keys with specific suffix in Dictionary
        res = {key: val for key, val in data_dict.items() if key.endswith(item_type)}
        # concat dataframes if more than 1 dataframe
        if len(res) > 0:
            if len(res) == 1:
                df = list(res.items())[0][1]
            else:
                logger.info(
                    f"write_features(): merging {len(res)} DataFrames of type {item_type}."
                )
                df = pd.concat(res, axis=0, join="outer", ignore_index=True)
            write_table(
                df=df,
                table_name=f"{table_name}_{item_type}",
                s3_folder_name=f"{s3_folder_name}{item_type}/",
            )
        else:
            logger.warning(f"No new features tables of type {item_type}.")
