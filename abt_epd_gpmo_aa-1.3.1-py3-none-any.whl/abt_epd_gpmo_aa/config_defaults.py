# %%
"""
This module provides the defaults for the configuration functions in misc_utils
"""

# %%
config_defaults = {
    "constants_name": "line_constants",
    "line_constants_simple_defaults": {
        "PROJECT_CONFIG_FILE_NAME": "project_config",
        "DATA_FOLDER": "data",
        "FILES_FOLDER": "files",
        "FEATURES": "feat",
        "JOIN": "join",
        # "LINE": no default, should always be set in line_constants.toml
        "MASTER_TABLE": "master",
        "LONG_TABLE": "long",
        "LOOKUP": "lookup",
        "ATTRIBUTES": "attr",
        "MODEL_OUTPUT": "model",
        "ORIGINAL": "original",
        "NEW": "new",
        "PROCESSED": "processed",
        "PREPROCESSED": "prep",
        "S3_ROOT": "gpmo",
    },
    "line_constants_composed_defaults": {
        # S3
        "BUCKET_NAME": "{PROJECT_NAME}-{ENVIRONMENT}",
        # Redshift
        "REDSHIFT_CONNECTION_NAME": "{PROJECT_NAME}-{ENVIRONMENT}",
        "REDSHIFT_DBNAME": "{ENVIRONMENT}",
        "REDSHIFT_SCHEMA": "{PROJECT_NAME_UNDERSCORED}",
        # Project conventions
        # S3 folder structure
        "S3_BASE_PREFIX": "{S3_ROOT}/{LINE}/",
        "S3_DATA_PREFIX": "{S3_BASE_PREFIX}{DATA_FOLDER}/",
        "S3_FILES_PREFIX": "{S3_BASE_PREFIX}{FILES_FOLDER}/",
        "S3_LOOKUP_PREFIX": "{S3_FILES_PREFIX}{LOOKUP}/",
        "S3_ATTRIBUTES_PREFIX": "{S3_FILES_PREFIX}{ATTRIBUTES}/",
        "ORIGINAL_DATA_S3_PATH": "{S3_DATA_PREFIX}{ORIGINAL}/",
        # Table name prefix for Glue_catalog/Athena tables and Redshift tables
        "PREPROCESSED_TABLE_PREFIX": "{LINE}_{PREPROCESSED}_",
        "PREPROCESSED_S3_PATH": "{S3_DATA_PREFIX}{PREPROCESSED}/",
        "LOOKUP_TABLE_PREFIX": "{LINE}_{LOOKUP}_",
        "LOOKUP_S3_PATH": "{S3_DATA_PREFIX}{LOOKUP}/",
        "ATTRIBUTES_TABLE_PREFIX": "{LINE}_{ATTRIBUTES}_",
        "ATTRIBUTES_S3_PATH": "{S3_DATA_PREFIX}{ATTRIBUTES}/",
    },
    "project_config_composed_defaults": {
        # Project conventions
        # Table name prefix for Glue_catalog/Athena tables and Redshift tables
        "FEATURES_TABLE_PREFIX": "{LINE}_{FEATURES}_{LOCAL_PROJECT_SHORT}_",
        "FEATURES_S3_PATH": "{S3_DATA_PREFIX}{FEATURES}/{LOCAL_PROJECT_SHORT}/",
        # TODO: Join tables might be replaced by preproc tables
        "JOIN_TABLE_PREFIX": "{LINE}_{JOIN}_{LOCAL_PROJECT_SHORT}_",
        "JOIN_S3_PATH": "{S3_DATA_PREFIX}{JOIN}/{LOCAL_PROJECT_SHORT}/",
        "MASTER_TABLE_PREFIX": "{LINE}_{MASTER_TABLE}_{LOCAL_PROJECT_SHORT}_",
        "MASTER_S3_PATH": "{S3_DATA_PREFIX}{MASTER_TABLE}/{LOCAL_PROJECT_SHORT}/",
        "LONG_TABLE_PREFIX": "{LINE}_{LONG_TABLE}_{LOCAL_PROJECT_SHORT}_",
        "LONG_S3_PATH": "{S3_DATA_PREFIX}{LONG_TABLE}/{LOCAL_PROJECT_SHORT}/",
        "MODEL_TABLE_PREFIX": "{LINE}_{MODEL_OUTPUT}_{LOCAL_PROJECT_SHORT}_",
        # Constants for specific use
        ############################
        # LEGACY names
        "REDSHIFT_PREDICTIONS_TABLE": "{MODEL_TABLE_PREFIX}predictions",
        "REDSHIFT_FEATURE_IMPORTANCE_TABLE": "{MODEL_TABLE_PREFIX}feature_importances",
    },
}
