# %%
import os
import re
from pathlib import Path

# %%
import boto3
import botocore.exceptions
import pandas as pd

# %%
# Load main modules of our team library
# %%
# Copy some variables of our team library
from abt_epd_gpmo_aa import logger, misc_utils

# %% [raw]
#

# %%
s3 = boto3.resource("s3")


# %%
# Note: there are 3 ways to specify a file or folder:
# - object: S3 API objects -> should be used within this module only
# - url: structure in the form "s3://<bucket>/<path>"
# - path: the <path> part of an url, using the default bucket

# %% [raw]
#


# %%
def path_to_url(paths: list) -> list:
    """prepend s3 + bucket to each path"""

    return [f's3://{misc_utils.config["BUCKET_NAME"]}/{p}' for p in paths]


# %%
def url_to_path(urls: list) -> list:
    """strip s3 + bucket from each URL"""

    pat = re.compile(r"^[Ss]3://[^/]*/")
    return [pat.sub(r"", u) for u in urls]


# %%
def url_to_bucket(url: str) -> str:
    """strip s3 + path from URL"""

    pat = re.compile(r"^[Ss]3://([^/]*)/.*$")
    return pat.sub(r"\1", url)


# %% [raw]
#


# %%
def get_sorted_file_objects(bucket_name: str, prefix: str) -> list:
    logger.info(f"Finding files in s3://{bucket_name}/{prefix}...")
    bucket = s3.Bucket(bucket_name)
    objects = bucket.objects.filter(Prefix=prefix)

    # Remove the directory itself, we just want the files.
    objects = [obj for obj in objects if not obj.key.endswith("/")]
    objects = sorted(objects, key=lambda obj: obj.last_modified)
    logger.info(f"Found {len(objects)} files in s3://{bucket_name}/{prefix}.")
    return objects


# %%
def get_sorted_file_paths(prefix: str) -> list:
    obj_list = get_sorted_file_objects(misc_utils.config["BUCKET_NAME"], prefix)
    name_list = [o.key for o in obj_list]
    return name_list


# %%
def file_exists(full_path: str) -> bool:
    return full_path in get_sorted_file_paths(full_path)


# %% [raw]
#


# %%
def s3_object_exists(obj):
    try:
        obj.load()  # Fails if object doesn't exist on S3
        return True
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "404":  # 404 means file not found
            return False
    return True  # This is a failsafe to enforce expecting 404.


# %%
def get_file_stem(obj) -> str:
    filename = get_filename(obj)
    stem = filename.split(".")[0]
    return stem


# %%
def get_filename(obj) -> str:
    return obj.key.split("/")[-1]


# %%
def get_file_data(path: str) -> bytes:
    s3_object = s3.Object(bucket_name=misc_utils.config["BUCKET_NAME"], key=path)
    body = s3_object.get()["Body"]
    return body.read()


# %% [raw]
#


# %%
def delete_url(prefix_url: str) -> None:
    """Delete all files starting with <prefix_url>

    Note: prefix_url does not have to end with a '/' and can contain Unix shell wildcards
    """

    logger.warning(f"Deleting S3 files: {prefix_url}...")
    # wr.s3.delete_objects(prefix_url)
    for o in get_sorted_file_objects(
        url_to_bucket(prefix_url), url_to_path([prefix_url])[0]
    ):
        o.delete()


# %%
def delete_path(prefix_path: str) -> None:
    """Delete all files starting with s3://<config["BUCKET_NAME"]>/<prefix_path>

    Note: prefix_path does not have to end with a '/' and can contain Unix shell wildcards
    """

    full_prefix = f"""s3://{misc_utils.config["BUCKET_NAME"]}/{prefix_path}"""
    delete_url(full_prefix)


# %% [raw]
#


# %%
def df_to_s3_as_parquet(
    df: pd.DataFrame, bucket: str, prefix: str, filename: str
) -> None:
    path = f"s3://{bucket}/{prefix}{filename}"  # The slash is already in the prefix.
    logger.info(f"Writing to {path}...")
    df.to_parquet(path, index=False)


# %%
def move_original_object_to_processed(
    original_obj, target_bucket: str, target_prefix: str
) -> None:

    filename = get_filename(original_obj)
    target_key = target_prefix
    if not target_key.endswith(filename):
        target_key = f"{target_prefix}{filename}"  # The slash is already in the prefix.
    logger.info(
        f"Copying file from "
        f"s3://{original_obj.bucket_name}/{original_obj.key} "
        f"to s3://{target_bucket}/{target_key}..."
    )
    s3.meta.client.copy(
        CopySource={"Bucket": original_obj.bucket_name, "Key": original_obj.key},
        Bucket=target_bucket,
        Key=target_key,
    )
    logger.info(
        f"Removing original object s3://{original_obj.bucket_name}/{original_obj.key}..."
    )
    original_obj.delete()


# %%
def move_original_file_to_processed(original_file: str) -> None:

    original_objects = get_sorted_file_objects(
        bucket_name=misc_utils.config["BUCKET_NAME"], prefix=original_file
    )
    if len(original_objects) != 1:
        raise ValueError(
            f"No or multiple original files found for {original_file} ({original_objects.size()})."
        )
    original_obj = original_objects[0]

    target_key = re.sub(
        f'({misc_utils.config["ORIGINAL_DATA_S3_PATH"]}.*/)new(/.*)$',
        r"\1processed\2",
        original_obj.key,
    )

    move_original_object_to_processed(
        original_obj, misc_utils.config["BUCKET_NAME"], target_key
    )


# %% [raw]
#


# %%
def write_bytes(data: bytes, full_path: str):
    """Upload data to a file in an S3 bucket

    :param data: Data to write
    :param full_path: filename including the complete prefix
    """

    s3_object = s3.Object(misc_utils.config["BUCKET_NAME"], full_path)
    # return the result status
    return s3_object.put(Body=data)


# %%
def upload_file(file_name: str, prefix: str):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param prefix:  must end with /
    """

    object_name = os.path.basename(file_name)
    logger.info(
        f"Copying file "
        f"{file_name}"
        f" to s3://{misc_utils.config['BUCKET_NAME']}/{prefix}..."
    )
    s3.meta.client.upload_file(
        file_name, misc_utils.config["BUCKET_NAME"], prefix + object_name
    )


# %%
def upload_directory(directory_path: str, prefix: str, condition: str = None):
    """Upload all files matching condition in directory_path to the S3 at the given prefix

    :param directory_path: directory to upload to s3 bucket
    :param prefix: must end with /
    :param condition: condition to check if string is in the file name to be uploaded
    """
    for file in [str(f) for f in Path(directory_path).iterdir() if f.is_file()]:
        if condition:
            if condition in file:
                upload_file(file, prefix=prefix)
        else:
            upload_file(file, prefix=prefix)


# %%
def download_file(s3_object_key):
    """Download a file from an S3 bucket into the current directory

    :param s3_object_key: s3 object key (e.g. 'glue_jobs/glue_job_demo.py')
    """
    file_name = s3_object_key.split("/")[-1]
    s3.meta.client.download_file(
        misc_utils.config["BUCKET_NAME"], s3_object_key, file_name
    )


# %%
def download_directory(prefix: str, condition: str = None):
    """Download a directory from an S3 bucket into the current directory

    :param prefix: must end with /
    :param condition: condition to check if string is in the file name to be downloaded
    """
    s3_object_list = get_sorted_file_objects(
        misc_utils.config["BUCKET_NAME"], prefix=prefix
    )
    for s3_object in s3_object_list:
        if condition:
            if condition in s3_object.key:
                logger.info(f"Downloading file {s3_object.key}")
                download_file(s3_object.key)
        else:
            logger.info(f"Downloading file {s3_object.key}")
            download_file(s3_object.key)
