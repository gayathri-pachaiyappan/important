# %%
"""
This notebook provides generic functions
- regarding memory
- reading files from local filesystem
- reading configuration
- for display in Jupyter notebooks

The following functions are provided
- regarding memory
   - def get_available_memory() -> int:
- set configuration parameters
   - def set_simple_defaults(settings: dict, defaults: dict) -> dict:
   - def set_composed_defaults(settings: dict, defaults: dict) -> dict:
- find configuration files:
   - def get_options(default_project: str = None, default_line: str = None, default_debug: bool = None) -> dict:
   - def find_path_name_to_files(directory: str, file_name: str) -> list:
   - def find_root_of_subtree(file_list: list, start_dir: str = ".") -> str:
- read configurations:
   - def get_full_path_name_to_project_root(root_name: str) -> str:  # LEGACY
   - def get_full_path_to_package(package: str = r"abt_[^/]*") -> Path:  # LEGACY
   - def find_path_to_file(directory: str, file_name: str) -> list:  # LEGACY
   - def get_full_dir_name_of_constants_file() -> str:  ** Depends on global config being set **
   - def find_directory(dir_name: str) -> str:  # in tree under get_full_dir_name_of_constants_file()
   - def find_project_files(file_name: str) -> list:  # in tree under find_directory(config["LOCAL_PROJECT_NAME"])
   - def find_common_path_name_of_files(file_list: list) -> str:  # ?Used anywhere?
   - def read_single_file_toml_json(full_path_name: str) -> dict:
   - def read_multi_file_toml_json(path_names: list, append_keys: list) -> dict:
   - def find_read_single_file_definition(def_name: str) -> dict:  ** Depends on global config being set **
   - def find_read_multi_file_definition(def_name: str, append_keys: list) -> dict:  ** Depends global config being set **
   - def read_json_definition(def_name: str) -> dict:  # LEGACY
   - def read_multi_json_definitions(def_name: str, append_keys: list) -> dict:  # LEGACY
   - def read_local_toml_file(full_path: str) -> dict:  # LEGACY
   - def read_multi_local_toml_files(path_list: list, append_keys: list) -> dict:  # LEGACY
   - def read_toml_definition(def_name="project_config", project_folder=None, path=None, project_root_name=None)  # LEGACY
   - def read_multi_toml_definition(def_name: str, append_keys: list, project_folder=None) -> dict:  # LEGACY
   - def dict_to_pandas_df(toml_dict: dict, section_col_name) -> pd.DataFrame:
   - def toml_dict_to_pandas_df(toml_dict: dict, section_col_name) -> pd.DataFrame:  # LEGACY
   - def get_base_config(line: str = None) -> dict:
     (uses find_root_of_subtree, find_path_name_to_files, read_single_file_toml_json)
   - def get_config(config_path: str = None, line: str = None, project: str = None,) -> dict:
     (uses get_base_config, find_root_of_subtree, find_path_name_to_files, read_single_file_toml_json)
   - def set_global_config(project: str, line: str = None) -> None:
     (uses get_config)
- for basic statistics and standard outlier detection
   - def get_single_statistics(df: pd.DataFrame, group_col, stat_col: str) -> pd.DataFrame:
   - def get_multi_statistics(df: pd.DataFrame, group_col: str, stat_cols: list) -> pd.DataFrame:
   - def detect_outliers_one_column(df_data, df_stats:pd.DataFrame, group_col, data_col:str, scale:float=1.5) -> pd.Series:
   - def detect_outliers(df_data, df_stats: pd.DataFrame, group_col: str, cols: list, scale: float = 1.5) -> pd.Series:
- for display in Jupyter notebooks
   - def show_df(df: pd.DataFrame) -> None:
- for id and name lookup:
   - def lookup_id_from_name(df: pd.DataFrame, id_column:str, name_column:str, name_to_lookup: str) -> int:
   - def lookup_name_from_id(df: pd.DataFrame, id_column:str, name_column:str, id_to_lookup: int) -> str:


The following config keys are used:
- LOCAL_PROJECT_SHORT


To create the config dictionary, the following keys are expected to be in
* line_constants.toml
  - DATA_FOLDER     # constant used in all our projects
  - FILES_FOLDER    # constant used in all our projects
  - ENVIRONMENT     # Environment for AWS resources assigned by AA-EPD
  - FEATURES        # constant used in all our projects
  - JOIN            # constant used in all our projects
  - LINE            # 3+3 character ID for the production line (like ivmapi)
  - MASTER_TABLE    # constant used in all our projects
  - LONG_TABLE    # constant used in all our projects
  - MODEL_OUTPUT    # constant used in all our projects
  - ORIGINAL        # constant used in all our projects
  - PREPROCESSED    # constant used in all our projects
  - LOOKUP    # constant used in all our projects
  - PROJECT_NAME    # Project_Name tag for AWS resources assigned by AA-EPD
  - S3_ROOT         # constant used in all our projects

* project_config.toml
  - LOCAL_PROJECT_SHORT  # Short id for the specific project

The following keys are generated, but can be overridden in files
* Purely based on keys provided in 'line_constants.toml
  - BUCKET_NAME
  - DATABASES
  - DATABASE
  - ORIGINAL_DATA_S3_PATH
  - PREPROCESSED_TABLE_PREFIX
  - PREPROCESSED_S3_PATH
  - LOOKUP_TABLE_PREFIX
  - LOOKUP_S3_PATH
  - REDSHIFT_CONNECTION_NAME
  - REDSHIFT_DBNAME
  - REDSHIFT_SCHEMA
  - S3_BASE_PREFIX
  - S3_DATA_PREFIX
  - S3_FILES_PREFIX
  - S3_LOOKUP_PREFIX
  - WORKGROUP

* Based on keys provided in line_constants.toml + project_config.toml
  - FEATURES_TABLE_PREFIX
  - FEATURES_S3_PATH
  - JOIN_TABLE_PREFIX
  - JOIN_S3_PATH
  - MASTER_TABLE_PREFIX
  - MASTER_S3_PATH
  - LONG_TABLE_PREFIX
  - LONG_S3_PATH
  - MODEL_TABLE_PREFIX
  - REDSHIFT_PREDICTIONS_TABLE
  - REDSHIFT_FEATURE_IMPORTANCE_TABLE

* Additionally set in configure (can also be overridden)
  - USED_CONSTANTS_FILE
  - USED_CONFIG_FILE
  - LOCAL_PROJECT_NAME  # The local dir where 'project_config.toml' should be found

"""

# %%
import getopt
import json
import logging
import os
import re
import sys
from pathlib import Path

# %%
import IPython
import pandas as pd
import psutil
import toml

# %%
# Copy some variables of our team library
from abt_epd_gpmo_aa import config_defaults, logger

# %% [raw]
#


# %%
# Define a module variable for others to read
config = {
    "CONFIGURED": False
}  # It is set in 'set_config(project:str)' defined in this module


# %% [raw]
#


# %%
def get_available_memory() -> int:
    """Get available system memory (~ /proc/meminfo - MemAvailable)"""

    return psutil.virtual_memory().available / 2**30  # in GiB


# %% [raw]
#


# %%
def set_simple_defaults(settings: dict, defaults: dict) -> dict:
    """Set missing keys in 'settings' with default from 'defaults' (NOTE: modifies 'settings')"""

    ret_dict = (
        settings.copy()
    )  # shallow copy; good enough as we add new keys at top level at most
    for name, default in defaults.items():
        ret_dict[name] = ret_dict[name] if name in ret_dict else default
    return ret_dict


# %%
def set_composed_defaults(settings: dict, defaults: dict) -> dict:
    """Set missing keys in 'settings' with default from 'defaults' (NOTE: modifies 'settings')"""

    ret_dict = (
        settings.copy()
    )  # shallow copy; good enough as we add new keys at top level at most
    for name, default in defaults.items():
        if name not in ret_dict:
            default_expanded = re.sub(r"\{([^}]+)\}", """{ret_dict["\\1"]}""", default)
            ret_dict[name] = eval(f"f{repr(default_expanded)}")
    return ret_dict


# %%
def get_options(
    default_project: str = None,
    default_line: str = None,
    default_debug: bool = None,
) -> dict:
    """Returns args if it is not None, or retrieves option arguments of system call"""
    args = {}
    if default_project != None:
        args["project_name"] = default_project
    if default_line != None:
        args["line_name"] = default_line
    if default_debug != None:
        if default_debug == True:
            args["debug"] = True
    # logger.info(f"DEBUG: get_options - sys.argv:\n{sys.argv}")
    opts, remaining = getopt.gnu_getopt(
        sys.argv[1:],
        shortopts="hp:l:df",  # Include 'f' as it is provided when running iPython notebooks
        longopts=[
            "help",
            "project_name=",
            "line_name=",
            "debug",
            "ip=",
            "stdin=",
            "control=",
            "hb=",
            "Session.signature_scheme=",
            "Session.key=",
            "shell=",
            "transport=",
            "iopub=",
            "f=",
        ],
    )
    # logger.info(f"DEBUG: get_options - options:\n{opts}\nremaining arguments:\n{remaining}")
    for name, val in opts:
        name = "--help" if name == "-h" else name
        name = "--project_name" if name == "-p" else name
        name = "--line_name" if name == "-l" else name
        name = "--debug" if name == "-d" else name
        if name.startswith("--"):
            name = name[2:]
        args[name] = val
    if "debug" in list(args.keys()):
        logger.setLevel(logging.DEBUG)
    if "help" in list(args.keys()) or not "project_name" in list(args.keys()):
        logger.info("Provide the '--project_name' (or -p) when running this script.")
        logger.debug(f"DEBUG: args: {args}")
        sys.exit(1)

    return args


# %% [raw]
#


# %%
def find_path_name_to_files(directory: str, file_name: str) -> list:
    """
    Returns a sorted list of full path names (str) to all file_name files in directory and childs

    Arguments:
    - directory : root directory where the search to file_name will begin
    - file_name : name of the file to look for ( glob pattern )
    """

    p = Path(directory)
    files = [str(f) for f in p.glob(f"**/{file_name}") if not f.is_dir()]
    if len(files):
        return sorted(files)
    else:
        return []


# %%
def find_root_of_subtree(file_list: list, start_dir: str = ".") -> str:
    """From the <start_dir> directory, find the parent that is root of all files

    arguments:
    - file_list: list of str with valid glob pattern (wildcards *, ? and **)
    - start_dir: valid path, may be a file instead of directory
    """

    start_dir = str(Path(".").resolve()) if start_dir == "." else start_dir
    start_dir = (
        start_dir if Path(start_dir).is_dir() else str(Path(start_dir).resolve().parent)
    )
    current_root = start_dir
    for file_name in file_list:
        logger.debug(f"DEBUG: find_root_of_subtree - Looking for: {file_name}")
        file_found = False
        # Only continue if current_root contains more than "/", the root of the file system
        while (not file_found) and len(current_root) > 1:
            # logger.info(f"find_root_of_subtree - current: {current_root}")
            files = find_path_name_to_files(current_root, file_name)
            if len(files):
                file_found = True
            else:
                # remove last directory of current_root and try again
                current_root = re.sub(r"^(.*)/[^/]*$", r"\1", current_root)
        if not file_found:
            logger.error(
                f"find_root_of_subtree - File not found on local storage: {file_name}"
            )
            raise FileNotFoundError(f"File not found on local storage: {file_name}")

    logger.debug(
        f"find_root_of_subtree - starting at {start_dir} looking for: {file_name}, found: {current_root}"
    )
    return current_root


# %% [raw]
#

# %% [raw]
# # Functions below may depend on global config to be set

# %%
# Legacy
def get_full_path_name_to_project_root(root_name: str) -> str:
    """Returns full path to package"""

    logger.error(
        "ERROR: Legacy function misc_utils.get_full_path_name_to_project_root(str) should not be used."
    )
    raise NotImplementedError(
        "ERROR: Legacy function misc_utils.get_full_path_name_to_project_root(str) should not be used."
    )
    return re.sub(f"^(.*/{root_name}/).*$", r"\1", str(Path(".").resolve()))


# %%
# Legacy
def get_full_path_to_package(package: str = r"abt_[^/]*") -> Path:
    """Returns full path to parent directory of OS current, with name <package>"""

    logger.error(
        "ERROR: Legacy function misc_utils.get_full_path_to_package(str) should not be used."
    )
    raise NotImplementedError(
        "ERROR: Legacy function misc_utils.get_full_path_to_package(str) should not be used."
    )
    return Path(get_full_path_name_to_project_root(package))


# %%
# Legacy
def find_path_to_file(directory: str, file_name: str) -> list:
    """
    Returns a list of Path objects to all file_name files in the directory and child directories

    Arguments:
    - directory : root directory where the search to file_name will begin
    - file_name : name of the file to look for ( endswith() )
    """

    logger.warning(
        "WARNING: Use find_path_name_to_files instead of Legacy function find_path_to_file()."
    )
    toml_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(file_name):
                toml_files.append(Path(os.path.join(root, file)))
    return toml_files


# %%
def get_full_dir_name_of_constants_file() -> str:
    """Requires global config to be set and constants file to be found and read"""

    return re.sub(r"^(.*)/[^/]*$", r"\1", config["USED_CONSTANTS_FILE"])


# %%
def find_directory(dir_name: str) -> str:
    """find specific dir in childs of dir with constants file on local file system

    If not found, returns full path to directory with constants file; ends with '/'
    """

    base_path = get_full_dir_name_of_constants_file()
    if base_path.endswith(f"/{dir_name}"):
        logger.info(f"Searching for {dir_name}, found {base_path}.")
        return base_path

    p = Path(base_path)
    dirs = [str(f) + "/" for f in p.glob(f"**/{dir_name}") if f.is_dir()]
    dirs.append(base_path)

    if len(dirs) == 1:
        logger.warning(
            f"No directory found matching {dir_name}; returning {base_path}."
        )
    if len(dirs) == 2:
        logger.info(f"Searching for {dir_name}, found {dirs[0]}.")
    if len(dirs) > 2:
        logger.info(
            f"Found directories matching {dir_name}: {dirs[:-1]}; returning first."
        )
    return dirs[0] if len(dirs) else base_path


# %%
def find_project_files(file_name: str) -> list:
    """Find sorted files on local file system in (global config) project directory"""

    # find full path spec to project directory
    proj_dir = find_directory(config["LOCAL_PROJECT_NAME"])
    p = Path(proj_dir)
    proj_files = [
        str(f)
        for f in p.glob(f"**/{file_name}")
        if not f.is_dir() and ".ipynb_checkpoints" not in str(f)
    ]

    if not len(proj_files):
        logger.error(
            f"""{file_name} not found in project directory ({config["LOCAL_PROJECT_NAME"]} -> {proj_dir})"""
        )
        FileNotFoundError("Requested file_name not found in project directory")
    else:
        logger.info(f"Found project files  matching {file_name}: {proj_files}")
        return sorted(proj_files)


# %%
def find_common_path_name_of_files(file_list: list) -> str:
    """Find common part in found file names"""

    full_path_list = []
    # First find the tree root that finds all files (from OS current directory)
    root = find_root_of_subtree(
        file_list, start_dir=get_full_dir_name_of_constants_file()
    )
    for file_glob in file_list:
        full_path_list += find_path_name_to_files(root, file_glob)

    common_path = os.path.commonpath(full_path_list)
    return str(common_path)


# %% [raw]
#


# %%
def read_single_file_toml_json(full_path_name: str) -> dict:
    """Read TOML/JSON file from project directory on local file system

    Arguments:
    - full_path_name: full directory/ies-filename-extension combination without wildcards
                      the extension must be one of '.toml' or '.json'

    Returns:
    -  dict containing the file content

    Note: in case multiple files are found, the first will be used
    Note: in case both .toml and .json are found, .toml has priority
    """

    if full_path_name.endswith(".toml"):
        return toml.load(full_path_name)
    elif full_path_name.endswith(".json"):
        json_file = Path(full_path_name)
        return json.loads(json_file.read_text())
    else:
        logger.error(
            "ERROR: read_local_toml_json() - "
            + f"File '{full_path_name}' is not '.toml' or '.json'"
        )
        raise ValueError("full_path_name ends not in '.toml' or '.json'")


# %%
def read_multi_file_toml_json(path_names: list, append_keys: list) -> dict:
    """Read and combine multiple TOML _OR_ JSON files; preference for TOML if found

    Arguments:
    - path_names: list of full file names to be read (if mix, only .toml is used)
    - append_keys: list of keys of arrays that will be appended

    Returns:
        TOML definitions in a dictionary

    NOTE: keys appearing in multiple files are overwritten if not in append_keys
    """

    # Check for all extensions being equal
    path_names_same_ext = [p for p in path_names if p.endswith(".toml")]
    if len(path_names_same_ext) == 0:
        path_names_same_ext = [p for p in path_names if p.endswith(".json")]
    if len(path_names_same_ext) == 0:
        logger.error(
            "ERROR: read_local_multi_file_definition() - "
            + f"No file in {path_names}' is '.toml' or '.json'"
        )
        raise ValueError("No '.toml' or '.json' definition files.")

    res = {}
    for k in append_keys:
        res[k] = []

    for one_file in path_names_same_ext:
        logger.info(f"Reading definitions from:\n{one_file}")
        new_def = read_single_file_toml_json(one_file)
        for k in append_keys:
            if k in new_def:
                res[k] += new_def[k]
    return res


# %%
def find_read_single_file_definition(def_name: str) -> dict:
    """Read TOML/JSON file from project directory on local file system

    Arguments:
    - def_name: filename ('*' gets added, so can be with or without .json/.toml extension)
        Accepts wild cards '*', '**' and '?' too.

    Returns:
    -  dict containing the file content

    Note: in case multiple files are found, the first will be used
    Note: in case both .toml and .json are found, .toml has priority
    """

    # Avoid "**"
    find_name = def_name if def_name.endswith("*") else def_name + "*"
    definition_files = find_project_files(find_name)
    # in case no files are found, an exception is raised by find_project_files
    # So, we can safely access element [0]
    return read_single_file_toml_json(definition_files[0])


# %%
def find_read_multi_file_definition(def_name: str, append_keys: list) -> dict:
    """Read and combine multiple TOML _OR_ JSON files from local file system

    Note: def name might be something like:
    "{PROJECT_DIR}/these_*_files"
        Accepts wild cards '*', '**' and '?' too.
    '*' is added, so 'toml' or 'json' does not have to be added
    """

    # Avoid "**"
    find_name = def_name if def_name.endswith("*") else def_name + "*"
    def_files = find_project_files(find_name)
    # in case no files are found, an exception is raised by find_project_files
    # So, we can safely assume the list is not empty
    return read_multi_file_toml_json(def_files, append_keys)


# %% [markdown]
# ##################################################################


# %%
def read_json_definition(def_name: str) -> dict:
    """Read JSON from current / project directory on local file system"""

    logger.warning(
        "WARNING: LEGACY: Use find_read_single_file_definition instead of read_json_definition()."
    )
    return find_read_single_file_definition(def_name + ".json")


# %%
def read_multi_json_definitions(def_name: str, append_keys: list) -> dict:
    """Read multiple JSON from current / project directory on local file system"""

    logger.warning(
        "WARNING: LEGACY: Use find_read_multi_file_definition instead of read_multi_json_definitions()."
    )
    return find_read_multi_file_definition(def_name + ".json", append_keys)


# %% [raw]
#


# %%
def read_local_toml_file(full_path: str) -> dict:
    """Reads TOML file from local file system"""

    logger.warning(
        "WARNING: LEGACY: Use read_single_file_toml_json instead of read_local_toml_file()."
    )
    return read_single_file_toml_json(full_path)


# %%
def read_multi_local_toml_files(path_list: list, append_keys: list) -> dict:
    """Read and combine multiple TOML files"""

    logger.warning(
        "WARNING: LEGACY: Use read_multi_file_toml_json instead of read_multi_local_toml_file()."
    )
    return read_multi_file_toml_json(path_list, append_keys)


# %%
def read_toml_definition(
    def_name, project_folder=None, path=None, project_root_name=None
) -> dict:
    """Reads TOML from local file system"""

    logger.warning(
        "WARNING: LEGACY: Use find_read_single_file_definition instead of read_toml_definition()."
    )
    if not project_folder == None:
        logger.warning(
            f"read_toml_definition - deprecated project_folder ({project_folder}) specified but not used."
        )
    if not path == None:
        logger.warning(
            f"read_toml_definition - deprecated path ({path}) specified but not used."
        )
    if not project_root_name == None:
        logger.warning(
            f"read_toml_definition - deprecated project_root_name ({project_root_name}) specified but not used."
        )
    return find_read_single_file_definition(def_name + ".toml")


# %%
def read_multi_toml_definition(
    def_name: str, append_keys: list, project_folder=None
) -> dict:
    """Read multiple TOML from local file system"""

    logger.warning(
        "WARNING: LEGACY: Use find_read_multi_file_definition instead of read_multi_toml_definition()."
    )
    if not project_folder == None:
        logger.warning(
            f"read_toml_definition - deprecated project_folder ({project_folder}) specified but not used."
        )
    return find_read_multi_file_definition(def_name + ".toml", append_keys)


# %% [raw]
#


# %%
def dict_to_pandas_df(content: dict, section_col_name: str) -> pd.DataFrame:
    """
    Function that takes a dict obtained from a config file and converts it into a pandas DataFrame.

    Parameters:
        content: dictionary, likely obtained by reading in a config file
        section_col_name: name given to the new column created from the dict

    Returns:
       Pandas dataframe.

    """
    df = pd.DataFrame(content).T.reset_index()
    df.rename(columns={"index": section_col_name}, inplace=True)
    return df


# %%
def toml_dict_to_pandas_df(toml_dict: dict, section_col_name) -> pd.DataFrame:
    """LEgacy function; has nothing to do with TOML"""
    logger.warning(
        "WARNING: LEGACY: Use dict_to_pandas_df() instead of toml_dict_to_pandas_df()."
    )
    return dict_to_pandas_df(toml_dict, section_col_name)


# %%
def get_base_config(line: str = None) -> dict:

    """
    Search and get configurations as a dictionary.

    Parameters:
        line: name of the (child) directory in which 'constants_name' has to be, to be found
        # constants_name: toml file name that holds configuration without the ".toml" extension

    Returns:
        config variables in a dictionarary.
    """
    # Only define this as argument when it will be really used.
    # constants_name: str = "line_constants"

    constants_name = config_defaults.config_defaults["constants_name"]

    # Find {constants_name}.toml in a directory as close as possible to the current OS directory
    # Find the most nested common subdirectory in the current OS directory and the file searched for
    search_name = constants_name if line == None else line + "/" + constants_name
    search_name += ".toml"
    logger.info(f"get_base_config - searching for: {search_name}")
    constants_path = find_root_of_subtree([search_name], start_dir=".")
    # logger.info(f"get_base_config - found root of path to {constants_name}: {constants_path}")
    # Search from the found root in subdirectories for the constants file
    constants_path = find_path_name_to_files(constants_path, search_name)
    if len(constants_path):
        constants_path = str(constants_path[0])
        logger.info(
            f"get_base_config - found path to file {constants_name}: {constants_path}"
        )
    else:
        logger.error(
            f"get_base_config - File not found on local storage: {constants_name}.toml"
        )
        raise FileNotFoundError(
            f"File not found on local storage: {constants_name}.toml"
        )

    constants = read_single_file_toml_json(constants_path)
    constants["USED_CONSTANTS_FILE"] = constants_path
    constants["PROJECT_NAME_UNDERSCORED"] = constants["PROJECT_NAME"].replace("-", "_")

    # Set defaults for undefined required constants that are usually the same
    constants = set_simple_defaults(
        constants, config_defaults.config_defaults["line_constants_simple_defaults"]
    )

    constants = set_composed_defaults(
        constants, config_defaults.config_defaults["line_constants_composed_defaults"]
    )

    # Athena database info
    # If needed catalog name is part of DATABASE name e.g. "AwsDataCatalogProd.abt_ea_stagingdb_prod"
    # In DATABASES dict the index "default" is mandatory

    name = "DATABASES"
    default = {
        "default": {  # default names are derived from PROJECT_NAME and ENVIRONMENT
            "WORKGROUP": constants["PROJECT_NAME"],
            "DATABASE": constants["PROJECT_NAME_UNDERSCORED"]
            + f"_{constants['ENVIRONMENT']}",  # DB=database
            "CTAS_APPROACH": True,
        },
        "osipi": {
            "WORKGROUP": constants["PROJECT_NAME"],
            "DATABASE": "AwsDataCatalogProd.abt_ea_stagingdb_prod",  # DB=catalog.database
            "CTAS_APPROACH": False,
        },
    }
    constants[name] = constants[name] if name in constants else default

    # Intermediate solution for Athena database connector
    name = "WORKGROUP"
    default = constants["DATABASES"]["default"]["WORKGROUP"]
    constants[name] = constants[name] if name in constants else default
    name = "DATABASE"
    default = constants["DATABASES"]["default"]["DATABASE"]
    constants[name] = constants[name] if name in constants else default

    return constants


# %%
def get_config(
    config_path: str = None,
    line: str = None,
    project: str = None,
) -> dict:

    """
    Get configurations as a dictionary.

    Parameters:
        config_path: full Path object to project_config.toml file, used by glue management functions
        line: name of directory in which the constants file is expected to be found
        project: name of project / subdirectory where all project specific files are found

    Returns:
        config variables in a dictionarary.
    """

    # Only define these as argument in case they will be really used.
    #    config_name: str = "project_config",
    #    constants_name: str = "line_constants",

    constants = get_base_config(line)

    config_name = constants["PROJECT_CONFIG_FILE_NAME"]

    if (config_path == None) and (project == None):
        return constants

    if config_path == None:
        # Find {config_name}.toml in a directory as close as possible to dir where constants were found
        config_path = re.sub(r"^(.*)/[^/]*$", r"\1", constants["USED_CONSTANTS_FILE"])
        # logger.info(f"DEBUG: get_config - Starting point for search for {config_name}: {config_path}")

        # Find the most nested common subdirectory in the start_dir and the file(s) searched for
        config_path = find_root_of_subtree(
            [f"{project}/{config_name}.toml"], start_dir=config_path
        )
        # logger.info(f"DEBUG: get_config - found root of path to {config_name}: {config_path}")
        config_path = find_path_name_to_files(
            config_path, f"{project}/{config_name}.toml"
        )
        if len(config_path):
            config_path = config_path[0]
            logger.info(f"get_config - found path to file {config_name}: {config_path}")
        else:
            logger.error(
                f"get_config - File not found on local storage: {project}/{config_name}.toml"
            )
            raise FileNotFoundError(
                f"File not found on local storage: {project}/{config_name}.toml"
            )
    else:
        project = str(config_path).split("/")[-2]

    config_init = read_single_file_toml_json(config_path)

    config_init["USED_CONFIG_FILE"] = config_path
    config_init["LOCAL_PROJECT_NAME"] = project

    # Combine all definitions, allowing for override of constants
    # In case of double definitions, last defined is used -> project specific config after constants
    config_dict = {
        **constants,
        **config_init,
    }

    config_dict = set_composed_defaults(
        config_dict, config_defaults.config_defaults["project_config_composed_defaults"]
    )

    return config_dict


# %%
def set_global_config(project: str, line: str = None) -> None:
    """Read config and share the contents as a program globally accessible variable"""

    global config
    config = get_config(line=line, project=project)

    config["CONFIGURED"] = True


# %% [raw]
#


# %%
def get_single_statistics(df: pd.DataFrame, group_col, stat_col: str) -> pd.DataFrame:
    """For each unique value in group_col, add all statistics over stat_col

    The parameter df must be a wide (feature)table
    """

    df_res = pd.DataFrame(df[group_col].unique()).apply(
        lambda x: pd.Series({group_col: x[0]}).append(
            df[df[group_col] == x[0]][stat_col].describe()
        ),
        axis=1,
    )
    df_res["statistics_for"] = stat_col
    return df_res


# %%
def get_multi_statistics(
    df: pd.DataFrame, group_col: str, stat_cols: list
) -> pd.DataFrame:
    """For each unique value in group_col, add all statistics over each element in stat_cols

    The parameter df must be a wide (feature)table
    """
    groups = df[group_col].unique()
    df_statistics = pd.concat(
        (
            df[df[group_col] == c][stat_cols].describe().transpose().assign(group_col=c)
            for c in groups
        ),
        axis=0,
        join="outer",
        ignore_index=False,
    )
    df_statistics = df_statistics.reset_index(drop=False).rename(
        columns={"index": "statistics_for", "group_col": group_col}
    )
    df_statistics["stat_group"] = (
        df_statistics[group_col] + "_" + df_statistics["statistics_for"]
    )
    return df_statistics


# %%
def detect_outliers_one_column(
    df_data, df_stats: pd.DataFrame, group_col, data_col: str, scale: float = 1.5
) -> pd.Series:
    """Determine outliers based on statistics found in get_..._statistics

    The parameter df must be a wide (feature)table
    An outlier has a value: < Q25-scale*(Q75-Q25) | > Q75+scale(Q75-Q25)
    """
    df_range = (
        df_stats[[group_col]]
        .assign(
            upper=df_stats["75%"] + scale * (df_stats["75%"] - df_stats["25%"]),
            lower=df_stats["25%"] - scale * (df_stats["75%"] - df_stats["25%"]),
        )[df_stats.statistics_for == data_col]
        .copy()
        .reset_index(drop=True)
    )

    df_tmp = df_data[[group_col, data_col]].copy()
    df_tmp.index.name = None
    df_tmp = df_tmp.reset_index(drop=False)  # Keep index!!!
    df_tmp = df_tmp.merge(df_range, how="inner", on=group_col)
    df_tmp = df_tmp.set_index(keys="index")  # Set index back!!!
    df_tmp.index.name = None

    df_tmp["outliers"] = df_tmp[data_col] < df_tmp.lower
    df_tmp["outliers"] |= df_tmp[data_col] > df_tmp.upper

    return df_tmp.outliers


# %%
def detect_outliers(
    df_data, df_stats: pd.DataFrame, group_col: str, cols: list, scale: float = 1.5
) -> pd.Series:
    """Detect outliers based on multiple different columns in a wide (feature)table"""

    df_tmp = df_data[[group_col]].copy()
    df_tmp["outliers"] = detect_outliers_one_column(
        df_data, df_stats, group_col, cols[0]
    )
    for c in cols[1:]:
        df_tmp["outliers"] |= detect_outliers_one_column(
            df_data, df_stats, group_col, c, scale
        )

    return df_tmp.outliers


# %% [raw]
#


# %%
def show_df(df: pd.DataFrame) -> None:
    with pd.option_context(
        "display.max_rows", None, "display.max_columns", None
    ):  # more options can be specified also
        IPython.display.display(df)
