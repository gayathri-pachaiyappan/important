# -*- coding: utf-8 -*-
# %% jupyter={"source_hidden": true}
"""
Gather relevant features in a single table for further processing.

This helper module provides three related functions, that use a dict for their parameters:
- read_one_table(table_def: dict)
Mandatory keys in table_def:
 - table: name of the table in the Athena database / Glue catalog
 - columns: columns to read from table, might be ["*"]
Optional keys in table_def:
 - feature_column: the name of the column that contains the feature name
 - features: list of feature names to include in the output
 - row_filter: valid SQL WHERE filter to limit rows included in the output

- pivot_dataframe(df: pd.DataFrame, table_def: dict)
Mandatory keys in table_def:
 - feature_column: The values in this column are used as output columns in the pivoted table
 - merge_column: list of 1 or 2 columns to merge multiple tables on; last one is used as Pivot index
 - pivot_value_column: column name containing the feature values

- merge_table_to_master_table(df_master, df_table: pd.DataFrame, table_def: dict)
df_master may be empty, but then will be replaced by df_table. Otherwise they are merged.
Mandatory keys in table_def:
 - merge_column: list of 1 or 2 to merge on: c[0] in df_master and c[-1] in df_table
Optional keys in table_def:
 - merge_method: defaults to "left" (df_master); all pd.DataFrame.merge(how=...) are possible.
"""

# %%
import numpy as np
import pandas as pd

# Load main modules of our team library
# Copy some variables of our team library
from abt_epd_gpmo_aa import athena_utils, logger

# %% [raw]
#


# %%
def replace_large_negative_values_by_na(table: pd.DataFrame) -> pd.DataFrame:
    # clean int values of -9223372036854775808

    return table.replace(
        to_replace=np.iinfo(np.int64).min,
        value=pd.NA,
    )


# %% [raw]
#


# %%
def read_one_table(table_def: dict) -> pd.DataFrame:
    """
    table_def - mandatory keys
    - table
    - columns
    table_def - optional keys
    - feature_column + features
    - row_filter
    """

    row_filter = "(1=1)"
    if "features" in table_def and "feature_column" in table_def:
        # convert list to format the SQL IN operator expects
        feature_set_sql = "'" + "','".join(table_def["features"]) + "'"
        row_filter += f" AND {table_def['feature_column']} IN ({feature_set_sql})"
    if "row_filter" in table_def:
        row_filter += f' AND {table_def["row_filter"]}'
    df = athena_utils.get_table_query(
        table=table_def["table"],
        columns=table_def["columns"],
        where=row_filter,
        db_config_index="default",
    )
    logger.info(f"Read table: {table_def['table']}, shape: {df.shape}")

    return df


# %%
def pivot_dataframe(df: pd.DataFrame, table_def: dict) -> pd.DataFrame:
    """
    Pivot dataframe
    Function is defined for features with similar parameters (to simplify code)
    """
    df = df.pivot_table(
        index=table_def["merge_column"][-1],
        columns=table_def["feature_column"],
        values=table_def["pivot_value_column"],
        aggfunc="first",
        dropna=False,
    )
    df = df.dropna(
        axis="index",
        how="all",
        subset=[c for c in df.columns if c != table_def["merge_column"][-1]],
    ).reset_index(drop=False)
    logger.info(f"Pivoted shape: {df.shape}")
    return df


# %%
def merge_table_to_master_table(
    df_master, df_table: pd.DataFrame, table_def: dict
) -> pd.DataFrame:
    "Merge table into master, based on columns and method specified in table_def"

    if "merge_method" in table_def:
        method = table_def["merge_method"]
    else:
        method = "left"

    if df_master.shape[0] > 0:
        if len(table_def["merge_column"]) == 1:
            df_master = df_master.merge(
                df_table,
                how=method,
                on=table_def["merge_column"][0],
            )
        elif len(table_def["merge_column"]) == 2:
            df_master = df_master.merge(
                df_table,
                how=method,
                left_on=table_def["merge_column"][0],
                right_on=table_def["merge_column"][1],
            )
        else:
            logger.error(
                'merge_table_to_master_table: In a table definition "merge_column" '
                + f'should be an array of size 1 or 2. It is now: "{table_def["merge_column"]}"'
            )
            raise Exception(
                'merge_table_to_master_table: Invalid array size for element "merge_column"'
                + f' in table_def: "{table_def["merge_column"]}"'
            )
    else:
        logger.debug("merge_table_to_master_table: df_master is (still) empty")
        df_master = df_table
    return df_master


# %%
def read_combined_table(multi_table_def: dict) -> pd.DataFrame:
    df_master = pd.DataFrame()
    for table_def in multi_table_def:
        logger.info(f"table_def: {table_def['table']}")
        df = read_one_table(table_def)
        if "pivot_value_column" in table_def:
            df = pivot_dataframe(df, table_def)
        df_master = merge_table_to_master_table(df_master, df, table_def)

    return df_master


# %% [raw]
#


# %%
def melt_per_type(
    df: pd.DataFrame, id_cols: list, melted_col_name: str, value_name: str = "value"
) -> dict:
    """Melt one DataFrame and return melted sub-dataframes according to dtype

      Arguments:
     - df: the dataframe to process
     - id_cols: array of column names that will be stay the final table
     - melted_col_name: all collumn names not in 'keep_cols' will be melted into a new column with this name
     - value_name: all values of the melted columns will be stored in a new column with this name

    Returns:
     - dict with dataframes, one for each of the value types int, float, string {'int': df_i, 'float': df_f, 'string': df_s}
    """

    # Gather column names we need for different situations
    id_cols_present = [c for c in df.columns if c in id_cols]

    melt_cols = [c for c in df.columns if not c in id_cols_present]
    melt_cols_typed = {}
    seen_cols = set()
    for t in ["float", "int"]:
        melt_cols_typed[t] = list(
            set(melt_cols).intersection(df.select_dtypes(include=[t]).columns)
        )
        seen_cols = seen_cols.union(melt_cols_typed[t])

    melt_cols_typed["string"] = list(set(melt_cols).difference(seen_cols))

    res = {}
    for t, cols in melt_cols_typed.items():
        if len(cols):
            logger.debug(
                "DEBUG: melt_per_type - input to pd.melt:\n"
                + f"df[{cols + id_cols_present}],\nid_vars={id_cols_present},\nvalue_vars={cols}"
            )
            res[t] = pd.melt(
                df[cols + id_cols_present],
                id_vars=id_cols_present,
                value_vars=cols,
                var_name=melted_col_name,
                value_name=value_name,
                ignore_index=True,
            )
    return res


# %%
def concat_table_list(dfs: list) -> pd.DataFrame:
    """Concatenate a list of tables with similar columns, ignoring the index"""

    return pd.concat(
        dfs,
        axis=0,
        join="outer",
        ignore_index=True,
    )


# %%
def melt_concat_dfs(
    raw_dfs: list, keep_cols: list, melted_col_name: str, value_name: str = "value"
) -> dict:
    """Melt multiple DataFrames into sub-dataframes according to dtype and concatenate

     Arguments:
     - raw_dfs: list of dataframes. Note: dataframes get 'consumed', so the list passed to raw_dfs will be empty
     - keep_cols: array of column names that will be stay the final table
     - melted_col_name: all collumn names not in 'keep_cols' will be melted into a new column with this name
     - value_name: all values of the melted columns will be stored in a new column with this name

    Returns:
     - dict with dataframes, one for each of the value types int, float, string {'int': df_i, 'float': df_f, 'string': df_s}
    """

    typed_dfs = {}
    while raw_dfs:
        df = raw_dfs.pop()
        logger.debug(f"DEBUG: melt_concat_dfs - source df.columns\n{df.columns}")
        d = melt_per_type(df, keep_cols, melted_col_name, value_name)
        del df
        for t in d.keys():
            if not t in typed_dfs:
                typed_dfs[t] = []
            if t in d:
                logger.debug(f"DEBUG: melt_concat_dfs - Melted columns\n{d[t].columns}")
                typed_dfs[t].append(d[t])

    for t in typed_dfs.keys():
        # Replace list of dataframes with concatenated dataframe
        typed_dfs[t] = concat_table_list(typed_dfs[t])

    return typed_dfs


# %%
def melt_multiple_tables(long_table_def: dict) -> dict:
    """Load, type-split, melt, multiple tables, concat, handle NA

    longe_table_def contains following keys:
    - tables : array of dict with following keys:
      + table
      + columns (list of strings, fed into SELECT clause, so may contain '*')
      * optional: feature_column + features
      * optional: row_filter
    - keep_columns : array of strings with column names to keep (id_vars in pd.melt)
    - melted_column_name : string, name of new column
    - value_column_name : optional string, default: 'value'
    - replace_na : optional dict {'type': <na_value>} (default: remove all NA; special: "keep_NA")

    """

    # Set defaults
    value_name = (
        long_table_def["value_column_name"]
        if "value_column_name" in long_table_def
        else "value"
    )
    replace_na = long_table_def["replace_na"] if "replace_na" in long_table_def else {}

    # Load tables
    logger.info("Reading tables")
    tables = [read_one_table(t_d) for t_d in long_table_def["tables"]]

    # Type-split, melt, concat
    logger.info("Split int/float/string, melt and concatenate")
    dfs = melt_concat_dfs(
        tables,
        long_table_def["keep_columns"],
        long_table_def["melted_column_name"],
        value_name,
    )

    # Handle NA
    for t in dfs.keys():
        logger.info(f"processing NA for table type {t}")
        if t in replace_na:
            logger.debug(f"DEBUG: replace_na[{t}]: {replace_na[t]}")
            if not replace_na[t] == "keep_NA":
                logger.debug(f"DEBUG: replacing NA with: {replace_na[t]}")
                dfs[t][value_name] = dfs[t][value_name].fillna(value=replace_na[t])
            else:
                logger.debug("DEBUG: leaving NA as is")
        else:
            logger.debug("DEBUG: default action: dropping NA values")
            dfs[t] = dfs[t].dropna(axis=0, subset=[value_name]).reset_index(drop=True)

    return dfs


# %% [raw]
#
