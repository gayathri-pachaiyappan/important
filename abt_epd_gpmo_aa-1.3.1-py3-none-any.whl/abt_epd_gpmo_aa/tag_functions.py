# %%
"""
This notebook provides generic functions to handle compressed DCS / PCS tag data
The compression is 'Sloping Boxcar Compression' and is only applicable to
floating point data. Integer and string type data keep their value until the
timestamp of a new value.
"""

# %%
# Data processing
import math

# %%
import numpy as np
import pandas as pd

# %%
# Load main modules of our team library
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import logger, tag_utils

# %%
"""
The functions to calculate a feature have the following interface:
Argument:
- tag_data: list of numpy ndarrays. Each array contains a column 0 with time (epoch)
and a column 1 with values at the times given in column 0
Returns:
- floating point number giving the value of the feature.
"""


# %%
def f_max(tag_data: list, parms: dict = {}) -> float:
    """Return the max value of tag data in list value 0, column 1 (values)"""

    return np.max(tag_data[0][1])


# %%
def f_min(tag_data: list, parms: dict = {}) -> float:
    """Return the min value of tag data in list value 0, column 1 (values)"""

    return np.min(tag_data[0][1])


# %%
def f_area_under_the_curve(tag_data: list, parms: dict = {}) -> float:
    """Return the area under the curve of ndarray 1"""

    return np.trapz(y=tag_data[0][1], x=tag_data[0][0])


# %%
def f_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the duration of the time period"""

    # Get the epochs (column 0 of a dataset) from the first dataset in the list
    epochs = tag_data[0][0]
    # duration is the difference between last and first
    return epochs[-1] - epochs[0]


# %%
def f_first(tag_data: list, parms: dict = {}) -> float:
    """Return tag value at the start of the current period"""

    y = tag_data[0][1]
    # first element of list
    return y[0]


# %%
def f_middle(tag_data: list, parms: dict = {}) -> float:
    """Return the tag value at the middle of the time period."""

    start = f_start_time(tag_data)
    end = f_end_time(tag_data)
    mid_epoch = (start + end) / 2.0
    # interpolate to get the value at the middle point in time
    return np.interp(mid_epoch, xp=tag_data[0][0], fp=tag_data[0][1])


# %%
def f_last(tag_data: list, parms: dict = {}) -> float:
    """Return tag value at the end of the current period"""

    y = tag_data[0][1]
    # last element of list
    return y[-1]


# %%
def f_diff_last_first(tag_data: list, parms: dict = {}) -> float:
    """Return the difference between last and first element of tag values"""

    y = tag_data[0][1]
    # the difference between last and first
    return y[-1] - y[0]


# %%
def f_avg(tag_data: list, parms: dict = {}) -> float:
    """Return the avg value of tag data in list element 0, column 1 (values)"""

    return f_area_under_the_curve(tag_data) / f_duration(tag_data)


# %%
def f_median(tag_data: list, parms: dict = {}) -> float:
    """Return the median value of tag data in list element 0, column 1 (values)"""

    epoch_value = tag_data[0]

    # First find duration between two values
    duration_avg = np.diff(epoch_value)
    # And find the average of the values. We take the average as the constant value during 'duration'
    duration_avg[1] = epoch_value[1, :-1] + duration_avg[1] / 2

    # find median by sorting the values, summing all durations and taking the value at half of the total time
    duration_avg = duration_avg[:, duration_avg[1].argsort()]
    cumulative_duration = np.nancumsum(duration_avg[0])
    if len(cumulative_duration) == 0:
        return np.nan
    half_duration = cumulative_duration[-1] / 2

    # The median is in the first period where cum_duration is equal or larger than total_duration/2
    all_idx_above_half = np.nonzero(cumulative_duration > half_duration)[0]
    if len(all_idx_above_half) == 0:
        return np.nan
    first_idx_above_half = all_idx_above_half[0]
    # This first index above half duration always exists and may be index 0
    if first_idx_above_half > 0:
        # Interpolate to get the best estimate of the value at half of the total time
        fraction = (half_duration - cumulative_duration[first_idx_above_half - 1]) / (
            cumulative_duration[first_idx_above_half]
            - cumulative_duration[first_idx_above_half - 1]
        )
        median = duration_avg[1][first_idx_above_half - 1] + fraction * (
            duration_avg[1][first_idx_above_half]
            - duration_avg[1][first_idx_above_half - 1]
        )
    else:
        # Nothing to interpolate in case the first duration is already larger than half of the total
        median = duration_avg[1][0]

    return median


# %%
def f_std(tag_data: list, parms: dict = {}) -> float:
    """Return the std of tag data in list[0], col 1 (values) over the period indicated by col 0 (times)

    Description:
    Std is standard deviation.
    In statistics, std is the square root of 1/(N-1) * sum (y-avg y)^2
    The std for a time continuous signal is calculated using the root mean square of (the signal y minus
    the average of y).
    The root mean square (RMS) is the root of (the time continuous integral of the sqared function y over
    the time period, divided by the duration of that time period).
    The function y is a series of straight lines between two points in time. The slope of the line for
    segment i, a[i], is (dy/dt)[i] = (y(t[i+1])-y(t[i]))/(t[i+1]-t[i]) and the starting point of the
    line is b[i] = y(t[i]).
    The square is (for one segment with t=0 the start of the segment): a^2 * t^2 + 2abt + b^2
    The integral of the squared line is: (a^2)/3*(t^3) + ab*(t^2) + (b^2)*t
    That integral has to be determined over each segment of length dt[i].
    The integral over the whole period is the sum of all segments within the overall period.

    So, RMS = sqrt(sum{a^2(dt[i]^3)/3 + a*b*(dt[i])^2 + (b^2)*dt[i]} / sum[dt])
    -> RMS^2 = (sum{a^2(dt[i]^3)/3} + sum{a*b*(dt[i])^2} + sum{(b^2)*dt[i]}) / sum[dt])
    dt[i] = t[i+1] - t[i]
    dy[i] = y[i+1] - y[i]
    In this, y[i] = value[i] - avg values

    However, RMS^2 is equivalent to 1/N * sum (y - avg y)^2, so we have to correct for N versus N-1.
    Therefore, std = sqrt( N/(N-1) * RMS^2)
    That is, multiply by N/(N-1) before taking the square root.
    """

    t = tag_data[0][0]
    y = tag_data[0][1] - f_avg(tag_data)
    n = len(t)

    # Add 0.1 ms to avoid division by 0.
    dt = np.diff(t) + 0.0001
    del t
    dy = np.diff(y)
    # The starting value, b, of each segment equals y. Like the length of dy and dt, the number of segments
    # is one less than the number of values in y. Therefore, drop the last value, which is the end value of
    # the last segment.
    b = y[:-1]
    del y
    logger.debug(
        f"f_std: count(dt<0.001): {np.count_nonzero(dt < 0.001)}, len(dt): {len(dt)},"
        + f" NaNs(dt): {np.count_nonzero(np.isnan(dt))}, NaNs(dy): {np.count_nonzero(np.isnan(dy))}, "
    )
    a = np.true_divide(dy, dt)
    del dy

    power3_part = np.sum(np.multiply(np.square(a), np.power(dt, 3))) / 3.0
    squared_part = np.sum(np.multiply(np.multiply(a, b), np.square(dt)))
    del a
    linear_part = np.sum(np.multiply(np.square(b), dt))
    del b, dt
    mean_square = (power3_part + squared_part + linear_part) / f_duration(tag_data)

    return math.sqrt(mean_square * n / (n - 1))


# %%
def f_median_of_abs_deviation_from_median(tag_data: list, parms: dict = {}) -> float:
    """Return the medianof deviations of tag data in list element 0, column 1 (values)"""

    epoch_value = np.array(tag_data[0], copy=True)
    # find difference
    epoch_value[1] -= f_median(tag_data)
    epoch_value[1] = np.absolute(epoch_value[1])
    # return median of absolute difference
    return f_median([epoch_value])


# %%
def f_number_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the nr of times the value in ndarray 1 becomes greater than the value in ndarray 2"""

    # Compare the values of the first and the second data set
    compare = tag_data[0][1] > tag_data[1][1]
    # Generate "greater than events" at the transition from False to True
    gt_event = np.diff(compare.astype(int)) > 0
    # return the count of the transitions and add 1 in case the initial state is '>'
    return np.sum(gt_event) + float(compare[0])


# %%
def f_number_less_than(tag_data: list, parms: dict = {}) -> float:
    """Return the nr of times the value in ndarray 1 becomes less than the value in ndarray 2"""

    # Compare the values of the first and the second data set
    compare = tag_data[0][1] < tag_data[1][1]
    # Generate "less than events" at the transition from False to True
    lt_event = np.diff(compare.astype(int)) > 0
    # return the count of the transitions and add 1 in case the initial state is '<'
    return np.sum(lt_event) + float(compare[0])


# %%
def intersection(x, y, z: np.ndarray) -> np.ndarray:
    """Find x where y=z and return all (x,y) pairs (column 0: x, column 1: y)"""

    # Compare the values of the first and the second data set
    compare = y > z
    # Generate "greater than events" at the transition from False to True and True to False
    crossings = np.diff(compare)
    cross_indices = np.where(crossings != 0)[0]

    intersections = []
    for idx in cross_indices:
        # Two straight lines
        #    y = y1 + (y2-y1) * (x-x1)/(x2-x1)
        # and
        #    z = z1 + (z2-z1) * (x-x1)/(x2-x1)
        # have their intersection y = z at x where
        #    x = x1 + (x2-x1) * (y1 -z1) / [ (z2-z1) - (y2-y1)]
        exact_x = x[idx] + (x[idx + 1] - x[idx]) * (y[idx] - z[idx]) / (
            (z[idx + 1] - z[idx]) - (y[idx + 1] - y[idx])
        )
        exact_y = y[idx] + (y[idx + 1] - y[idx]) * ((exact_x - x[idx])) / (
            x[idx + 1] - x[idx]
        )
        intersections.append((exact_x, exact_y))

    return np.array(intersections).transpose()


# %%
def f_duration_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the total time the value in ndarray 1 is greater than the value in ndarray 2"""

    epochs = tag_data[0][0]
    y = tag_data[0][1]
    z = tag_data[1][1]
    intersections = intersection(epochs, y, z)
    if not len(intersections):
        if y[0] <= z[0]:
            return 0.0
        else:
            # y[0] is greater than z[0], all the time. Return duration.
            return f_duration(tag_data)
    exact_times = intersections[0]
    exact_times = np.insert(exact_times, 0, epochs[0])
    exact_times = np.append(exact_times, epochs[-1])
    # Get all individual time periods between each pair of crossings
    time_diff = np.diff(exact_times)
    # There is a crossing at each time in 'exact_times'. The value in ndarray 1 is alternatingly
    # above and below the reference value in ndarray 2. So, we are only interested in indeces 2n or 2n+1.
    indices = np.arange(int(len(time_diff) / 2) + 1) * 2
    # Determine if we have to take the sum of the odd or even time differences
    # If we start with tag_data[0] > tag_data[1], we need time_diff[2n]
    indices += 1 - int(y[0] > z[0])

    # return the sum of the time differences at the relevant indices (i.e. y > z)
    return np.sum(time_diff[indices[indices < len(time_diff)]])


# %%
def f_duration_less_than(tag_data: list, parms: dict = {}) -> float:
    """Return the total time the value in ndarray 1 is less than the value in ndarray 2"""

    return f_duration(tag_data) - f_duration_greater_than(tag_data)


# %%
def f_start_time(tag_data: list, parms: dict = {}) -> float:
    """Return the duration of the time period"""

    # Get the epochs (column 0 of a dataset) from the first dataset in the list
    epochs = tag_data[0][0]
    # start_time is simply the first timestamp
    return epochs[0]


# %%
def f_end_time(tag_data: list, parms: dict = {}) -> float:
    """Return the duration of the time period"""

    # Get the epochs (column 0 of a dataset) from the first dataset in the list
    epochs = tag_data[0][0]
    if epochs[0] < epochs[-1]:
        return epochs[-1]
    else:
        return np.nan


# %%
def f_era(tag_data: list, parms: dict = {}) -> float:
    """Return the duration of the time period"""

    # Get the epochs (column 0 of a dataset) from the first dataset in the list
    epoch_start = f_start_time(tag_data)
    era = 0.0
    for i in range(len(tag_data)):
        if epoch_start > tag_data[i][1][0]:
            era = i + 1.0
    return era


# %%
def get_peaks(tag_data: list) -> np.ndarray:
    """Get boolean array with True at last point before significant change in ndarray 1

    Significant change: the value in ndarray 1 changes more than the first value in ndarray 2"""

    values = tag_data[0][1].astype(float)

    # get peak_threshold from the constants array
    peak_threshold = tag_data[1][1][0].astype(float)

    # Identify peaks based on a significant raise or drop in the value

    # Create a boolean array indicating significant changes
    if peak_threshold >= 0.0:
        # finds negative peaks
        significant_changes = np.diff(values, append=values[-1]) > peak_threshold
    else:
        # finds positive peaks
        significant_changes = np.diff(values, append=values[-1]) < peak_threshold

    # logger.debug(f"DEBUG: get_peaks - values:\n{values}\nresult:\n{significant_changes}")
    peaks = np.ediff1d(significant_changes.astype(int), to_begin=0) > 0
    return peaks


# %%
def f_peak_median(tag_data: list, parms: dict = {}) -> float:
    """Return the median of peaks (value right befor a significant change) in ndarray 1

    Significant change: the value in ndarray 1 changes more than the first value in ndarray 2
    As only the first value in ndarray 2 will be used, it usually is a constant"""

    peak_selection = get_peaks(tag_data)
    if np.any(peak_selection):
        # Use the values (column 1 of a dataset) from the first dataset in the list
        values = tag_data[0][1].astype(float)
        return np.median(values[peak_selection])
    else:
        return np.nan


# %%
def f_peak_sum(tag_data: list, parms: dict = {}) -> float:
    """Return the sum of peaks (value right befor a significant change) in ndarray 1

    Significant change: the value in ndarray 1 changes more than the first value in ndarray 2
    As only the first value in ndarray 2 will be used, it usually is a constant"""

    peak_selection = get_peaks(tag_data)
    if np.any(peak_selection):
        # Use the values (column 1 of a dataset) from the first dataset in the list
        values = tag_data[0][1].astype(float)
        return np.sum(values[peak_selection])
    else:
        return np.nan


# %% [markdown]
# .

# %%
# The next functions can also be replaced with post processing functions


# %%
def f_relative_duration_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the total time the value in ndarray 1 is greater than the value in ndarray 2"""

    return f_duration_greater_than(tag_data) / f_duration(tag_data)


# %%
def f_difference(tag_data: list, parms: dict = {}) -> float:
    """Return the total differe between the auc value in ndarray 1 and ndarray 2"""

    logger.debug(f"DEBUG: len(tag_data): {len(tag_data)}")
    return f_area_under_the_curve([tag_data[0]]) - f_area_under_the_curve([tag_data[1]])


# %%
def f_diff_last_first_reset(tag_data: list, parms: dict = {}) -> float:
    """Return the difference between last and first element of tag values plus peak values

    This function returns the increase of counters or totalizers that can be reset to
    zero during the time period.
    """
    if len(tag_data) == 1:
        # constant not provided. threshold for peak detection set to -0.1
        peak_tag_data = [tag_data[0], np.array([[tag_data[0][0][0]], [-0.1]])]
    else:
        peak_tag_data = tag_data
    res = f_peak_sum(peak_tag_data)
    if np.isnan(res):
        # no peaks, so start at zero
        res = 0.0
    # then take the normal difference, without looking at peak-reset events
    res += f_diff_last_first(tag_data)
    return res


# %%
"""
Specific functions for the clarification step
"""


# %%
def get_sub_time_periods(
    epochs, compare: np.ndarray, include_edges: bool
) -> pd.DataFrame:
    """Return dataframes with start and end epochs where compare becomes 1 and 0, respectively.

    Arguments:
    - epochs: 1D np.ndarray with timestamps
    - compare: np.array of same size as epochs containing zeros and ones
    Returns:
    DataFrame with the following columns:
    - start_epoch
    - end_epoch
    Description:
    Used to determine start and stop times of 'periods' where 'compare' has value 1.
    """

    #  1|           *    *    *
    #   |         /              \
    #  0+-*----*----+----+----+----*----*----*----*
    #   --+----+----+----+----+----+----+----+----+
    #    t0   t1   t2   t3   t4   t5   t6   t7   t8
    # Compare is a series of zeros and ones

    # using the difference, we find edges.
    #  1|      *
    #   |      |
    #  0+-*----+----*----*----+----*----*----*----X
    #   |                     |
    # -1|                     *
    #   --+----+----+----+----+----+----+----+----+
    #    t0   t1   t2   t3   t4   t5   t6   t7   t8
    edges = np.diff(compare.astype(int))

    # At the start of a period (edges == +1) and at the end (edges == -1)
    # At all other points (edges == 0).

    # We have to obtain the start and end times via the indices, as edges is one element shorter than epochs.
    start_idx = np.where(edges > 0)[0] + 1
    end_idx = np.where(edges < 0)[0] + 1
    # if there are positive edges, only include the negative ones after the first starting edge
    if len(start_idx) and len(end_idx):
        if include_edges:
            if start_idx[0] > end_idx[0]:
                # We start with an 'end', so we have to insert the beginning (index 0) at the start
                start_idx = np.concatenate(([0], start_idx))
            if end_idx[-1] < start_idx[-1]:
                # We end with a 'start', so we have to append the end (len(epochs -1))
                end_idx = np.concatenate((end_idx, [len(epochs) - 1]))
        else:
            # only include end times after the first start
            end_idx = end_idx[end_idx > start_idx[0]]
            # ...and only include start times before the last end
            start_idx = start_idx[start_idx < end_idx[-1]]
    else:
        # At least one of start_idx, end_idx is empty
        if len(end_idx):
            if include_edges:
                start_idx = np.array([0])
            else:
                end_idx = np.array([])
        if len(start_idx):
            if include_edges:
                end_idx = np.array([len(epochs) - 1])
            else:
                start_idx = np.array([])
        # Both start_idx and end_idx empty is also fine
        if len(start_idx) + len(end_idx) == 0:
            if compare[0] > 0.5:
                start_idx = np.array([0])
                end_idx = np.array([len(epochs) - 1])

    if len(start_idx) != len(end_idx):
        logger.warning(f"DEBUG: {len(start_idx)} != {len(end_idx)}")
        logger.warning(f"DEBUG:\n{start_idx}\n{end_idx}")
        logger.warning(f"DEBUG:\n{edges}")

    df = pd.DataFrame({"start_epoch": epochs[start_idx], "end_epoch": epochs[end_idx]})
    # Now, each row in df defines one period of ones in 'compare'
    return df


# %%
def get_per_slot_function_result(
    df: pd.DataFrame, tag_data: list, f_name: str
) -> pd.Series:
    """return for each slot in df the result of f_name applied to tag_data[1] between start_epoch and end_epoch"""

    return df.apply(
        lambda x: tag_functions[f_name](
            tag_utils.select_ndarray_list(tag_data, (x.start_epoch, x.end_epoch))
        ),
        axis=1,
    )


# %%
def clarification_slots(tag_data: list) -> pd.DataFrame:
    """Return information about the 'slots' during clarification.

    Arguments:
    - tag_data - list with (defined in pcs_feature_definitions.py):
      # [0] fc1415_020_pid1_out_cv -> flow control (column 0: epoch; column 1: value)
      # [1] fc1415_020_pid1_pv_cv  -> flow process value (column 0: epoch; column 1: value)
      # [2] fc1415_020_pid1_sp_cv  -> flow setpoint (column 0: epoch; column 1: value)
    Returns:
    DataFrame with the following columns:
    - start_epoch
    - end_epoch
    - duration
    - avg_flow_pv
    Each row identifies one 'slot' of at least 10 minutes with an average flow of at least 10.0
    """

    # Check: The setpoint follows the process value while flow control == 0.0??
    # A slot is defined where (setpoint > 1.0) & (flow control > 0)
    flow_setpoint = tag_data[2][1]
    flow_control = tag_data[0][1]
    # Compare is a series of zeros and ones
    compare = (flow_setpoint > 0.0) & (flow_control > 0)

    epochs = tag_data[0][0]

    df = get_sub_time_periods(epochs=epochs, compare=compare, include_edges=False)
    # Now, each row in df defines one slot within the batch
    if df.shape[0] == 0:
        logger.warning("WARNING: no slots found in data.")
        return df.assign(duration=0.0, avg_flow_pv=0.0)

    # We can now calculate features for each slot
    # If needed, we can treat each slot as if it is an individual batch. That means,
    # we can select tag data for one slot using 'tag_utils.select_ndarray()' and we can
    # then process that data using functions like f_avg(<list of tag data>).
    df = df.assign(
        duration=get_per_slot_function_result(df, [tag_data[1]], "duration"),
        avg_flow_pv=get_per_slot_function_result(df, [tag_data[1]], "avg"),
    )

    # Find slots that are have a duration of at least 10 minutes and have at least an average flow of 10.0
    valid_slots = (df.duration >= 600.0) & (df.avg_flow_pv > 10.0)
    if valid_slots.sum() == 0:
        logger.warning(f"WARNING: no valid slots found in data frame\n{df}")
    df = df[valid_slots].reset_index(drop=True)

    # Return the definitions of the valid slots for further processing.
    return df


# %%
def f_clarification_number_slots(tag_data: list, parms: dict = {}) -> float:
    """Return the total number of periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above

    return clarification_slots(tag_data).shape[0]


# %%
def f_clarification_max_slot_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the maximum duration of slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above

    return clarification_slots(tag_data).duration.max()


# %%
def f_clarification_min_slot_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the minimum duration of slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above

    return clarification_slots(tag_data).duration.min()


# %%
def merge_slot_data(df_slots: pd.DataFrame, one_tag_data: np.ndarray) -> np.ndarray:
    """Return all slot data concatenated with virtual timestamps

    Arguments:
    - df_slots - data frame with columns 'start_epoch' and 'end_epoch' defining the time slots of interest
    - one_tag_data - 2D ndarray with column [0] containing epoch and column [1] data
    Returns:
    2D ndarray with column [0] virtual timestamps (epoch-like) and column [1] data
    Description:
    If df contains two time slots, with epoch 10.0 - 15.0 and 20.0 - 30.0 and one_tag_data
    contains epochs 10.0, 12.0, 15.0, 17.0, 20.0, 30.0 with values 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 then
    this function will return an array with column 0 the epoch-like virtual timestamps:
    0.0000001, 2.0, 5.0, 5.0000001, 15.0 (corresponding with original values 10, 12, 15, 20 and 30,
    and thus excluding 17). The returned values in column 1 are: 1, 2, 3, 5, 6 (excluding 4).
    """

    start_list = df_slots.start_epoch.sort_values().to_list()
    end_list = df_slots.end_epoch.sort_values().to_list()
    slot_data_list = []

    for i in range(len(start_list)):
        slot_data = tag_utils.select_ndarray(one_tag_data, (start_list[i], end_list[i]))
        if i > 0:
            # Add the last([-1]) epoch([0]) of the previous ndarray in the list([-1]),
            # plus 1 us minus the start epoch of the time slot, so we get
            # a continuous time series with a 1 us jump
            slot_data[0] += slot_data_list[-1][0][-1] + 0.000001 - start_list[i]
        else:
            # subtract the start epoch of the (first) slot, so we start our new time series
            # at virtual epoch 0.0 s
            slot_data[0] -= start_list[i]

            slot_data_list.append(slot_data)

    if len(slot_data_list) > 0:
        return np.concatenate(slot_data_list, axis=1)
    else:
        logger.warning("WARNING: merge_slot_data: df_slots is empty.")
        return np.array([[np.nan], [np.nan]])  # return empty 2D ndarray


# %%
def merge_slot_data_list(df_slots: pd.DataFrame, tag_data: np.ndarray) -> list:
    """Call 'merge_slot_data' for each item in tag_data_list and return a list of all results."""

    data_list = []
    for one_tag_data in tag_data:
        data_list.append(merge_slot_data(df_slots, one_tag_data))
    return data_list


# %%
def f_clarification_max(tag_data: list, parms: dict = {}) -> float:
    """Return the max over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_max(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_min(tag_data: list, parms: dict = {}) -> float:
    """Return the min over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_min(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_area_under_the_curve(tag_data: list, parms: dict = {}) -> float:
    """Return the area under the curce over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_area_under_the_curve(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the duration over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_duration(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_avg(tag_data: list, parms: dict = {}) -> float:
    """Return the avg over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_avg(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_median(tag_data: list, parms: dict = {}) -> float:
    """Return the median over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_median(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_std(tag_data: list, parms: dict = {}) -> float:
    """Return the std over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_std(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_median_of_abs_deviation_from_median(
    tag_data: list, parms: dict = {}
) -> float:
    """Return the median_of_abs_deviation_from_median over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_median_of_abs_deviation_from_median(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_number_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the number_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_number_greater_than(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_duration_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the duration_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_duration_greater_than(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_relative_duration_greater_than(
    tag_data: list, parms: dict = {}
) -> float:
    """Return the relative_duration_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_relative_duration_greater_than(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
def f_clarification_difference(tag_data: list, parms: dict = {}) -> float:
    """Return the difference over all slot periods"""

    # tag_data contains list with data as listed for function clarification_slots defined above
    # tag_data[3] should contain the data of interest

    return f_difference(
        merge_slot_data_list(df_slots=clarification_slots(tag_data), tag_data=tag_data)[
            3:
        ]
    )


# %%
"""
Specific functions for turbidity during the clarification step
"""


# %%
def adjust_sub_time_periods(
    df_start_end: pd.DataFrame, start_offset, end_offset: float
) -> pd.DataFrame:
    """Return dataframe with respective offsets applied to corresponding columns.

    Arguments:
    - df_start_end - dataframe with columns start_epoch and end_epoch that have to be adjusted
    Returns:
    DataFrame with the following columns:
    - start_epoch
    - end_epoch
    Description:
    Adjust start and end times with given offset and remove rows with resulting end_epoch < start_epoch
    """

    df_start_end["start_epoch"] += start_offset
    # We want to take a margin of 300 seconds after the discharge cycle ends
    df_start_end["end_epoch"] += end_offset
    df_start_end = df_start_end[df_start_end.start_epoch < df_start_end.end_epoch]

    return df_start_end


# %%
def create_pseudo_tag_from_start_end_times(
    df: pd.DataFrame, active_value: int, time_range: tuple
) -> np.ndarray:
    """Convert start and end times to an array with epochs and 1 / 0 values

    Arguments:
    - df - DataFrame with columns start_epoch and end_epoch
    - active_value - 1 or 0, indicates the value that should be returnd between df.start_epoch and df.end_epoch
    - time_range[0] - the start of the period of interest, should be at or before the minimum of df.start_epoch
    - time_range[1] - the end of the period of interest, should be at or after the maximum of df.end_epoch
    Returns:
    ndarray with two columns: column 0 contains the epoch and column 1 contains the values (0 or 1)
    """

    # First add additional timestamps to get nice(*) '(in)active' periods
    # (*): nice block wave shape instead of triangle wave shape after linear interpolation.
    df["start_extra"] = df.end_epoch - 0.0001
    df["end_extra"] = (df.start_epoch - 0.0001).shift(
        periods=-1, fill_value=time_range[1]
    )

    # The value in 'active_data' is assigned to the value in the periods start_epoch to end_epoch.
    # During end_epoch to (the next) start_epoch the value of 'inactive_data' is assigned.
    df["active_data"] = active_value
    df["inactive_data"] = 1 - active_value

    epoch_value = (
        pd.concat(
            (
                pd.DataFrame({"t": [time_range[0]], "v": [1 - active_value]}),
                df[["start_epoch", "active_data"]].rename(
                    columns={"start_epoch": "t", "active_data": "v"}
                ),
                df[["start_extra", "active_data"]].rename(
                    columns={"start_extra": "t", "active_data": "v"}
                ),
                df[["end_epoch", "inactive_data"]].rename(
                    columns={"end_epoch": "t", "inactive_data": "v"}
                ),
                df[["end_extra", "inactive_data"]].rename(
                    columns={"end_extra": "t", "inactive_data": "v"}
                ),
            ),
            axis=0,
            join="outer",
            ignore_index=True,
        )
        .sort_values(by="t")
        .to_numpy()
        .transpose()
    )

    return epoch_value


# %%
def turbidity_slots(tag_data: list) -> pd.DataFrame:
    """Return information about the 'clear periods' between discharges during the slots.

    Arguments:
    - tag_data - list with (defined in pcs_feature_definitions.py):
      The first three elements are required for determination of clarification slots
      - [0] fc1415_020_pid1_out_cv - flow control (column 0: epoch; column 1: value)
      - [1] fc1415_020_pid1_pv_cv  - flow process value (column 0: epoch; column 1: value)
      - [2] fc1415_020_pid1_sp_cv  - flow setpoint (column 0: epoch; column 1: value)
      The next two elements are required to find discharge sub-slots
      - [3] qi1420_220_ai1_pv_cv   - turbidity (column 0: epoch; column 1: value)
      - [4] zn1420_014_ai1_pv_cv   - discharge (column 0: epoch; column 1: value)
    Returns:
    DataFrame with the following columns:
    - start_epoch
    - end_epoch
    - duration
    Each row identifies one 'discharge slot' with more than 6 minutes between discharges
    Description:
    Turbidity readings are only reliable in a steady flow. Therefore, we not only have
    to look at clarification slots, but also at discharge cycles that disturb turbidity
    readings a lot. As a safeguard we will also excluse some time after the start and
    before the end of slots and periods between discharges.
    As an additional safeguard we filter out turbidity readings > 499.0
    """

    ######
    # Discharge cycles only exist between the main clarification slots, so get them first
    df_main_slots = clarification_slots(tag_data)[["start_epoch", "end_epoch"]]
    if df_main_slots.shape[0] == 0:
        return df_main_slots

    # For turbidity, we only want to use measurements during a good flow. So, we take a margin
    # of 300 s after the start and before the end and an additional 25 minutes (1800 s in total)
    # before the end of the last slot.
    end_epoch_col_nr = df_main_slots.columns.get_loc("end_epoch")
    df_main_slots.iloc[-1, end_epoch_col_nr] -= 1500
    df_main_slots = adjust_sub_time_periods(
        df_main_slots, start_offset=300, end_offset=-300
    )

    ######
    # Find times before / after / between discharge cycles
    compare = tag_data[4][1] < 0.5
    df_discharges = get_sub_time_periods(
        epochs=tag_data[4][0], compare=compare, include_edges=True
    )

    # We want to take a margin of 60 seconds before and 300 s after the discharge cycle
    df_discharges = adjust_sub_time_periods(
        df_discharges, start_offset=300, end_offset=-60
    )

    # Determine the overall start and end epoch
    overall_start_epoch = pd.concat(
        (df_main_slots.start_epoch, df_discharges.start_epoch),
        axis=0,
        join="outer",
        ignore_index=True,
    ).min()
    overall_end_epoch = pd.concat(
        (df_main_slots.end_epoch, df_discharges.end_epoch),
        axis=0,
        join="outer",
        ignore_index=True,
    ).max()

    ######
    # Create additional filters based on flow rate and turbidity
    compare = tag_data[1][1] > 10.0
    df_high_flow = get_sub_time_periods(
        epochs=tag_data[1][0], compare=compare, include_edges=True
    )
    df_high_flow = df_high_flow[
        (df_high_flow.end_epoch > overall_start_epoch)
        & (df_high_flow.start_epoch < overall_end_epoch)
    ]

    compare = tag_data[3][1] <= 499.0
    df_low_turb = get_sub_time_periods(
        epochs=tag_data[3][0], compare=compare, include_edges=True
    )
    df_low_turb = df_low_turb[
        (df_low_turb.end_epoch > overall_start_epoch)
        & (df_low_turb.start_epoch < overall_end_epoch)
    ]

    ######
    # Combine all lists of start and end epochs, keeping only the overlapping intervals
    # Now create 1 / 0 data with these timestamps in our "tag_data" format (list[0] is discharge, list[1] is main)
    pseudo_tag_data = [
        create_pseudo_tag_from_start_end_times(
            df_main_slots,
            active_value=1,
            time_range=(overall_start_epoch, overall_end_epoch),
        ),
        create_pseudo_tag_from_start_end_times(
            df_discharges,
            active_value=1,
            time_range=(overall_start_epoch, overall_end_epoch),
        ),
        create_pseudo_tag_from_start_end_times(
            df_high_flow,
            active_value=1,
            time_range=(overall_start_epoch, overall_end_epoch),
        ),
        create_pseudo_tag_from_start_end_times(
            df_low_turb,
            active_value=1,
            time_range=(overall_start_epoch, overall_end_epoch),
        ),
    ]

    # Align all data sets, so they have the same set of epochs (union)
    pseudo_tag_data = tag_utils.align_epoch_for_ndarray_list(pseudo_tag_data)

    # A logical AND of all sets of 0 / 1 values is the same as multiplication
    compare = pseudo_tag_data[0][1]
    for i in range(1, len(pseudo_tag_data)):
        compare *= pseudo_tag_data[i][1]

    ######
    # Get all resulting time periods
    df = get_sub_time_periods(
        epochs=pseudo_tag_data[0][0], compare=compare, include_edges=True
    )

    # Return the definitions of the valid slots for further processing.
    return df


# %%
def f_turbidity_number_slots(tag_data: list, parms: dict = {}) -> float:
    """Return the total number of periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above

    return turbidity_slots(tag_data).shape[0]


# %%
def f_turbidity_max_slot_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the maximum duration of slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above

    df = turbidity_slots(tag_data)
    df["duration"] = df.end_epoch - df.start_epoch
    return df.duration.max()


# %%
def f_turbidity_min_slot_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the minimum duration of slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above

    df = turbidity_slots(tag_data)
    df["duration"] = df.end_epoch - df.start_epoch
    return df.duration.min()


# %%
def f_turbidity_max(tag_data: list, parms: dict = {}) -> float:
    """Return the maximum flow over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain flow data

    return f_max(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_min(tag_data: list, parms: dict = {}) -> float:
    """Return the minimum flow over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain flow data

    return f_min(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_area_under_the_curve(tag_data: list, parms: dict = {}) -> float:
    """Return the area under the curce over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_area_under_the_curve(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_duration(tag_data: list, parms: dict = {}) -> float:
    """Return the duration over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_duration(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_avg(tag_data: list, parms: dict = {}) -> float:
    """Return the avg over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_avg(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_median(tag_data: list, parms: dict = {}) -> float:
    """Return the median over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_median(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_std(tag_data: list, parms: dict = {}) -> float:
    """Return the std over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_std(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_median_of_abs_deviation_from_median(
    tag_data: list, parms: dict = {}
) -> float:
    """Return the median_of_abs_deviation_from_median over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_median_of_abs_deviation_from_median(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_number_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the number_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_number_greater_than(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_duration_greater_than(tag_data: list, parms: dict = {}) -> float:
    """Return the duration_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_duration_greater_than(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_relative_duration_greater_than(
    tag_data: list, parms: dict = {}
) -> float:
    """Return the relative_duration_greater_than over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_relative_duration_greater_than(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
def f_turbidity_difference(tag_data: list, parms: dict = {}) -> float:
    """Return the difference over all slot periods"""

    # tag_data contains list with data as listed for function turbidity_slots defined above
    # tag_data[5] should contain the data of interest

    return f_difference(
        merge_slot_data_list(df_slots=turbidity_slots(tag_data), tag_data=tag_data)[5:]
    )


# %%
"""
Name all functions listed above for use in feature definitions
"""

# %%
tag_functions = {
    "max": f_max,
    "min": f_min,
    "auc": f_area_under_the_curve,
    "duration": f_duration,
    "avg": f_avg,
    "median": f_median,
    "std": f_std,
    "median_of_abs_deviation_from_median": f_median_of_abs_deviation_from_median,
    "number_gt": f_number_greater_than,
    "number_lt": f_number_less_than,
    "duration_gt": f_duration_greater_than,
    "duration_lt": f_duration_less_than,
    "start_time": f_start_time,
    "end_time": f_end_time,
    "era": f_era,
    "peak_median": f_peak_median,
    "peak_sum": f_peak_sum,
    "rel_duration_gt": f_relative_duration_greater_than,
    "diff": f_difference,
    "first": f_first,
    "middle": f_middle,
    "last": f_last,
    "diff_last_first": f_diff_last_first,
    "diff_last_first_reset": f_diff_last_first_reset,
    # Clarification functions
    "c_number_slots": f_clarification_number_slots,
    "c_max_slot_duration": f_clarification_max_slot_duration,
    "c_min_slot_duration": f_clarification_min_slot_duration,
    "c_max": f_clarification_max,
    "c_min": f_clarification_min,
    "c_auc": f_clarification_area_under_the_curve,
    "c_duration": f_clarification_duration,
    "c_avg": f_clarification_avg,
    "c_median": f_clarification_median,
    "c_std": f_clarification_std,
    "c_median_of_abs_dev_from_med": f_clarification_median_of_abs_deviation_from_median,
    "c_number_gt": f_clarification_number_greater_than,
    "c_duration_gt": f_clarification_duration_greater_than,
    "c_rel_duration_gt": f_clarification_relative_duration_greater_than,
    "c_diff": f_clarification_difference,
    # Turbidity functions
    "t_number_slots": f_turbidity_number_slots,
    "t_max_slot_duration": f_turbidity_max_slot_duration,
    "t_min_slot_duration": f_turbidity_min_slot_duration,
    "t_max": f_turbidity_max,
    "t_min": f_turbidity_min,
    "t_auc": f_turbidity_area_under_the_curve,
    "t_duration": f_turbidity_duration,
    "t_avg": f_turbidity_avg,
    "t_median": f_turbidity_median,
    "t_std": f_turbidity_std,
    "t_median_of_abs_dev_from_med": f_turbidity_median_of_abs_deviation_from_median,
    "t_number_gt": f_turbidity_number_greater_than,
    "t_duration_gt": f_turbidity_duration_greater_than,
    "t_rel_duration_gt": f_turbidity_relative_duration_greater_than,
    "t_diff": f_turbidity_difference,
}
