# %%
"""
Generic Preprocess data utilities


Configuration items in misc_utils.config
- PCS_PARTITION_PERIOD

This module provides:
 - def get_last_epoch_of_preproc() -> float:
 - def get_last_preprocessed_datapoints(base_table_info: dict, table_type_names: list) -> pd.DataFrame:
 - def update_last_preprocessed_datapoints(df_last: pd.DataFrame, df_new: pd.DataFrame) -> pd.DataFrame:
 - def process_generic_step_1(df: pd.DataFrame) -> pd.DataFrame:
 - def drop_existing_data(df_new, df_last_ext: pd.DataFrame) -> pd.Series:
 - def process_generic_step_2(df: pd.DataFrame, df_last: pd.DataFrame) -> pd.DataFrame:
 - def preprocess_tag_type_definition(tag_type: dict) -> dict:

"""

# %%
import io

# %%
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, but still empty
from abt_epd_gpmo_aa import (
    athena_utils,
    logger,
    preprocess_text_table_utils,
    preprocess_utils,
    s3_utils,
    tag_utils,
)

# %%
# Define some (configurable) constants relevant for PCS processing
misc_utils.config = misc_utils.set_composed_defaults(
    misc_utils.config,
    {
        "PCS_TABLE": "{PREPROCESSED_TABLE_PREFIX}pcs",
        "PCS_S3_PATH": "{PREPROCESSED_S3_PATH}pcs/",
    },
)


# %%
def get_last_epoch_of_preproc() -> float:
    """
    Get last epoch time from preproc_pcs_float db
    (1 value in epoch format)
    """
    logger.info("Read last epoch from preproc database...")
    try:
        last_epoch = tag_utils.get_maxmin_timestamp(most_recent=True, data_type="float")
    except Exception:
        logger.warning(
            "WARNING: Table does not exist (exception during query). Returning epoch 0"
        )
        last_epoch = 0

    logger.info(f"Last epoch of pcs preproc float table: {last_epoch}")

    return last_epoch


# %%
def get_last_preprocessed_datapoints(
    base_table_info: dict, table_type_names: list
) -> pd.DataFrame:
    """Get row_id of most recent datapoint for each tag

    Returns: DataFrame with columns: 'tag', 'epoch' and 'row_id'
    """

    since = get_last_epoch_of_preproc() - 365 * 86400  # search in the last year
    # Combine all tags in one dataframe; make sure we return at least an empty dataframe
    list_of_df = [pd.DataFrame(columns=["row_id", "tag", "epoch"])]
    for type_name in table_type_names:
        table = f"{base_table_info['name']}_{type_name}"
        if table in athena_utils.get_tables():
            logger.info(f"Reading last data point from table {table}")
            list_of_df.append(
                athena_utils.get_last_pcs_preprocessed_datapoints(table, since)
            )
        else:
            logger.warning(
                f"Table {table} does not exist (get last ext. PCS datapoints)"
            )
    df_return = pd.concat(list_of_df, axis=0, join="outer", ignore_index=True)
    # Note: ascending on 'epoch', na_position and keep should be aligned so NA is dropped
    df_return = (
        df_return.sort_values(
            by=["tag", "epoch"],
            ascending=[True, False],
            na_position="last",
            ignore_index=True,
        )
        .drop_duplicates(subset="tag", keep="first", ignore_index=True)
        .reset_index(drop=True)
        .copy()
    )
    return df_return


# %%
def update_last_preprocessed_datapoints(
    df_last: pd.DataFrame, df_new: pd.DataFrame
) -> pd.DataFrame:
    """Get row_id of most recent datapoint for each tag, found in df_last, merged with df_new

    Arguments
    - two dataframes with columns: 'tag', 'epoch' and 'row_id'

    Returns: DataFrame with columns: 'tag', 'epoch' and 'row_id'
    """

    # Combine all tags in one dataframe; make sure we return at least an empty dataframe
    col_list = ["tag", "epoch", "row_id"]
    df_merged = pd.concat(
        (df_last[col_list], df_new[col_list]),
        axis="index",
        join="outer",
        ignore_index=True,
    )

    df_merged = df_merged.dropna(axis="index", how="any", subset=["tag", "epoch"])
    df_merged = df_merged.sort_values(
        by=["epoch"], ascending=True, na_position="first", ignore_index=True
    )
    df_merged = df_merged.drop_duplicates(subset="tag", keep="last", ignore_index=True)

    return df_merged.copy()


# %% [raw]
#


# %%
def process_generic_step_1(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generic processing of the data step 1:
    - generate unique row IDs from the combination of original tag name and timestamp
    - convert tag names to lower cast and replace chars not in [0-9a-z_] by '_'

    Arguments:
    DataFrame df should contain columns: 'tag_name', 'epoch', 'timestamp' 'value_string'(, 'value_type')

    Adds columns
     - 'row_id' (from tag_name, timestamp),
     - 'tag' (from tag_name),
    Removes columns
     - 'tag_name' and
     - 'timestamp'

    Returns DataFrame with columns: 'row_id', 'tag', 'epoch', 'value_string'(, 'value_type')

    """

    logger.info("Generic processing: Adding row_ids...")
    df["row_id"] = preprocess_utils.generate_rowid(df, ["tag_name", "timestamp"])

    df["tag"] = df["tag_name"].apply(tag_utils.convert_tag_name)

    # Free up some memory, dropping 'tag_name' and 'timestamp' (use .copy() after function call)
    return df[["row_id", "tag", "epoch", "value_string", "value_type"]]


# %%
def drop_existing_data(df_new, df_last_ext: pd.DataFrame) -> pd.Series:
    """Return boolean Series with True for 'new' rows in df_new

    df_new should contain columns 'tag', 'epoch'
    df_last_ext should contain columns 'tag', 'epoch'

    Remarks
    - existing is defined as "epoch of df_new[<specific tag>] older than/equal epoch of df_last_ext[<same tag>]"
    """

    # Initialize mask with all True values
    logger.info("Masking of existing data starts...")
    # df_new contains tags multiple times with different epoch
    # df_last_ext contains tags only once with the last external epoch
    # Create df with all 'new' tags and merge last_ext epoch for that tag
    df_ext_epochs = df_new[["tag"]].copy()
    # logger.info(f"df_ext_epochs.shape: {df_ext_epochs.shape}")
    df_ext_epochs.index.name = None
    df_ext_epochs = (
        df_ext_epochs.reset_index(drop=False)  # Keep index!!!
        .merge(df_last_ext[["tag", "epoch"]], how="left", on="tag", copy=False)
        .set_index(keys="index")  # Set index back!!
        .fillna(0.0)
        .copy()
    )
    df_ext_epochs.index.name = None

    logger.info("Masking step 2...")
    # add result to temporary DataFrame, to keep indices right
    df_ext_epochs["mask"] = df_new["epoch"] > df_ext_epochs["epoch"]
    logger.info("Masking ready!")

    # If we re-process data that is already in the database we will get double data.
    # To avoid this, erase all datapoints that already are in the database
    logger.info("Dropping existing rows")
    # note: df.mask is a method, so use ["mask"] to identify the column
    return df_new[df_ext_epochs["mask"]].reset_index(drop=True).copy()


# %%
def process_generic_step_2(
    df: pd.DataFrame, df_last: pd.DataFrame, df_lookup: pd.DataFrame = None
) -> pd.DataFrame:
    """
    Generic processing of the data:
    - add reference to previous data point
    - remove duplicate lines

    Arguments:
    DataFrame df should contain columns:  'row_id', 'tag', 'epoch', 'value_string'(, 'value_type')
    DataFrame df_last should contain columns: 'tag', 'epoch' and 'row_id'
    DataFrame df_lookup should contain columns: 'tag', 'tag_id'

    Adds columns
     - 'prev_row_id' and
     - 'partition_id' (from epoch).
    Drops duplicates, based on new column row_id
    Swaps the tag name for tag ids from the tags look up table in the 'tag' columns

    Returns DataFrame with columns: 'row_id', 'tag', 'prev_row_id', 'epoch', 'value_string', 'partition_id'(, 'value_type')

    """

    if df_lookup is not None:
        logger.info("Generic processing 2: Adding tag ids from the lookup table...")
        df_check_missing_tags = pd.merge(df, df_lookup, how="left", on="tag")
        if len(df_check_missing_tags[df_check_missing_tags["tag_id"].isnull()]) > 0:
            logger.warning(
                f"WARNING: The following tags did not have a tag_id in the lookup table and will be removed from the table: {list(df_check_missing_tags[df_check_missing_tags['tag_id'].isnull()]['tag'].unique())}"
            )
        df = pd.merge(df, df_lookup, how="inner", on="tag")
        df["tag"] = df["tag_id"]

    logger.info("Sorting before adding X-ref...")
    df = df.sort_values(by=["tag", "epoch"], axis=0, ascending=True)
    df = (
        df.drop_duplicates(subset="row_id", ignore_index=True)
        .reset_index(drop=True)
        .copy()
    )
    logger.info("Adding X-ref...")
    # Add col 'prev_row_id'
    df = preprocess_utils.add_cross_references(
        df, df_last, group_col="tag", id_col="row_id"
    )

    df = drop_existing_data(df, df_last)

    logger.info("Adding partition ids...")
    df["partition_id"] = preprocess_utils.generate_partition_id(
        df["epoch"], misc_utils.config["PCS_PARTITION_PERIOD"]
    )

    # keep only relevant columns
    cols = [
        c
        for c in df.columns
        if c
        in [
            "row_id",
            "tag",
            "prev_row_id",
            "epoch",
            "value_string",
            "partition_id",
            "value_type",
        ]
    ]
    return df[cols].reset_index(drop=True).copy()


# %%
def preprocess_tag_type_definition(tag_type: dict) -> dict:
    "Convert tags (keys) and types (values) to valid lower case versions and return"

    return {tag_utils.convert_tag_name(k): v.lower() for k, v in tag_type.items()}


# %%
def get_base_tag_type_definitions() -> list:
    """Get list with standard codes, functions and names"""

    return [
        {
            "type_code": "s",  # string
            "conversion_function": preprocess_text_table_utils.convert_string_to_string,
            "table_type_name": "string",
        },
        {
            "type_code": "i",  # integers
            "conversion_function": preprocess_text_table_utils.convert_string_to_int,
            "table_type_name": "int",
        },
        {
            "type_code": "f",  # floating point
            "conversion_function": preprocess_text_table_utils.convert_string_to_float,
            "table_type_name": "float",
        },
    ]


# %%
def read_tags_lookup_table():
    """
    Return the tags id look up tables from S3

    """
    if s3_utils.file_exists(f"{misc_utils.config['S3_LOOKUP_PREFIX']}pcs_tags.parquet"):
        logger.info("Reading the lookup table on S3...")
        return pd.read_parquet(
            io.BytesIO(
                s3_utils.get_file_data(
                    f"{misc_utils.config['S3_LOOKUP_PREFIX']}pcs_tags.parquet"
                )
            )
        )
    else:
        logger.warning("WARNING: The lookup table does not exist on S3.")
        return None
