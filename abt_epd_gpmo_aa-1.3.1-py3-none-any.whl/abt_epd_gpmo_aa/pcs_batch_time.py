# %%
"""
Derive features from PCS / DCS / DeltaV / OSI-Pi data

See the OneNote file GLB-EPD-AIDA 02 Kedro2AWS, section 'New Architecture', page 'PCS Preprocessed -> feature'
"""

# %%
import logging
import operator

# %%
import numpy as np
import pandas as pd
from scipy import signal

# %%
# Load main modules of our team library
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, the main config
from abt_epd_gpmo_aa import logger, tag_utils

# %%
"""
Helper functions to determine the relevant time periods within the start and end times of the batches to process
"""


# %%
def notclose(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """wrapper around logical not and isclose"""
    return np.logical_not(np.isclose(a, b))


# %%
rel_ops = {
    ">": operator.gt,
    "<": operator.lt,
    ">=": operator.ge,
    "<=": operator.le,
    "==": operator.eq,
    "!=": operator.ne,
    "isclose": np.isclose,
    "notclose": notclose,
}


# %%
def get_epoch_last_existing_batch(
    df_last: pd.DataFrame, feature_group_names: list
) -> float:
    """Get epoch of last existing batch for one of the features in the list

    Description:
    As all features in the list use the same batch time refinement definition,
    they all use exactly the same time period for a specific batch id. Therefore,
    if data for one of the features was available at a given time, the data for
    all these features was available.
    """

    # Ref: https://www.epochconverter.com/
    # 1 Jan 2015 0:00:00 UTC: 1420070400
    since_epoch = 1420070400.0
    if df_last.shape[0] == 0:
        return since_epoch

    matching_features = df_last["feature_name"].str.startswith(feature_group_names[0])
    for feature_group_name in feature_group_names:
        # do a logical or with the previous results
        matching_features |= df_last["feature_name"].str.startswith(feature_group_name)
    # If of at least one of the features a previous batch is found, use that as
    # starting point in time from where we will process new batches.
    # Otherwise, we will use the epoch of 1 Jan 2015 as starting point
    if matching_features.any():
        since_epoch = df_last["epoch"][matching_features].iloc[0]
        logger.info(
            f"Last features found at epoch: {since_epoch} (in {len(feature_group_names)} feature groups)"
        )
    else:
        logger.info(f"No last features found. Using epoch: {since_epoch}")

    logger.debug(
        f"Last features found at epoch: {since_epoch} (in feature groups: {feature_group_names})"
    )
    return since_epoch


# %%
def get_new_time_for_batch(
    single_batch_data: pd.Series,
    df_time_values: pd.DataFrame,
    event_time_indices: np.ndarray,
    start: bool,
    conditions: np.ndarray,
    debug: bool = False,
) -> float:
    """Determine new (start or end) time for a single batch

    Arguments:
    - single_batch_data : pd.Series with elements 'start_time' and 'end_time'
    - df_time_values : pd.DataFrame with all 'start_time' and 'next_time' of tag data
    - event_time_indices : np.ndarray with indices into df_time_values with relevant moments
    - start : boolean whether to take the first (True) or last candidate event time index
    Returns:
    - time in epoch
    """

    # get valid candidate elements from df_time_values
    mask_indices = np.nonzero(
        (
            df_time_values["start_time"].to_numpy()
            <= float(single_batch_data["end_time"] + 0.001)
        )
        & (
            df_time_values["next_time"].to_numpy()
            >= float(single_batch_data["start_time"] - 0.001)
        )
    )[0]

    # Check if event_time_indices overlap with mask_indices
    overlap_indices = mask_indices[np.isin(mask_indices, event_time_indices)]

    if debug:
        logger.debug(f"""get_new_time_for_batch() - mask_indices:\n{mask_indices}""")
        logger.debug(
            "get_new_time_for_batch() - event_indices (close to mask):\n"
            + f"""{[i for i in event_time_indices.tolist() if i > mask_indices[0]-10 and i < mask_indices[-1]+10]}"""
        )
        logger.debug(
            f"""get_new_time_for_batch() - overlap_indices:\n{overlap_indices}"""
        )

    # early return in case of missing data (no overlap at all)
    if len(overlap_indices) == 0:
        logger.debug(f"mask_indices: {mask_indices}")
        logger.debug(f"event_time_indices: {event_time_indices}")
        logger.debug("Returning NaN.")
        return np.nan

    # Early return in case of first / last event before / after overlap period (but
    # condition True at original start/end)
    if overlap_indices[0] >= 1 and start:
        # Look one before (if possible) as that one will have 'event' before overlapping range.
        # If we miss it here, it will have an event at the first overlapping point, so we'll catch it anyway
        first_condition_idx = (
            overlap_indices[0] - 1 if overlap_indices[0] > 0 else overlap_indices[0]
        )
        if conditions[first_condition_idx] == True:
            if debug:
                logger.debug(
                    f"""get_new_time_for_batch() - return original start {float(single_batch_data["start_time"])}"""
                )
            return float(single_batch_data["start_time"])
    else:
        # In case we end with a True condition and the end event is after the current end time,
        # then keep the current end time
        if conditions[overlap_indices[-1]] == True:
            if debug:
                logger.debug(
                    f"""get_new_time_for_batch() - return original end {float(single_batch_data["end_time"])}"""
                )
            return float(single_batch_data["end_time"])

    # Find first / last event and return that time as new time
    if start:
        event_time = float(df_time_values["start_time"].iloc[overlap_indices[0]])
        if debug:
            logger.debug(
                f"""get_new_time_for_batch() - event_time: {float(event_time)}"""
            )
        if event_time < float(single_batch_data["start_time"]):
            return float(single_batch_data["start_time"])
        else:
            return event_time
    else:
        event_time = float(df_time_values["start_time"].iloc[overlap_indices[-1]])
        if debug:
            logger.debug(
                f"""get_new_time_for_batch() - event_time: {float(event_time)}"""
            )
        if event_time > float(single_batch_data["end_time"]):
            return float(single_batch_data["end_time"])
        else:
            return event_time


# %%
def determine_per_batch_new_times_for_one_refinement_step(
    refinement_step: dict,
    df_batch_timings: pd.DataFrame,
    df_time_values: pd.DataFrame,
) -> np.ndarray:
    """refinement_step must contain "func" and "offset" """

    tag_type = tag_utils.get_tag_type(refinement_step["tag"])
    if (
        not (tag_type.endswith("int") or tag_type.endswith("float"))
    ) or not "func" in refinement_step:
        raise Exception("No function or non-numeric tag")

    new_times = np.full_like(df_batch_timings["start_time"].to_numpy(), np.nan)
    new_time_index = 0

    functions = {
        "max": np.nanmax,
        "min": np.nanmin,
    }
    func_rel_ops = {
        "max": operator.ge,  # >=
        "min": operator.le,  # <=
    }
    # (values <= max(values) + offset)   --> normally: offset <= 0
    # (values >= min(values) + offset)   --> normally: offset >= 0

    func = functions[refinement_step["func"]]
    rel_op = func_rel_ops[refinement_step["func"]]
    offset = refinement_step["offset"]

    np_values = df_time_values["value"].to_numpy()
    logger.debug(
        f"Individually processing {len(df_batch_timings)} batches for refinement step:\n{refinement_step}"
    )
    for index, batch_timing in df_batch_timings.iterrows():
        logger.debug(f"batch: {batch_timing.to_string()}")
        relevant_selection = (
            (df_time_values["next_time"] > batch_timing["start_time"])
            & (df_time_values["start_time"] < batch_timing["end_time"])
        ).to_list()
        logger.debug(f"# relevant_values: {np.sum(relevant_selection)}")
        if (
            logger.isEnabledFor(logging.DEBUG)
            and "debug" in refinement_step
            and batch_timing["batch_id"] == refinement_step["debug"]
        ):
            logger.debug(f"relevant_values: {np_values[relevant_selection].tolist()}")
        if np.sum(relevant_selection) > 0:
            f_result = func(np_values[relevant_selection])
            logger.debug(f"func() result: {f_result}")
            condition = rel_op(
                np_values,
                f_result + offset,
            )
            logger.debug(f"# true condition: {np.nansum(condition)}")
            logger.debug(
                f"# true condition in relevant selection: {np.nansum(condition[relevant_selection])}"
            )
        else:
            logger.debug("No relevant data points in time interval.")
            condition = np.full(np_values.shape, False)

        if (
            logger.isEnabledFor(logging.DEBUG)
            and "debug" in refinement_step
            and batch_timing["batch_id"] == refinement_step["debug"]
        ):
            logger.debug(f"tag({refinement_step['tag']}), time/values")
            logger.debug(f"{df_time_values[relevant_selection].to_string()}")
            logger.debug(f"condition:\n{condition[relevant_selection].tolist()}")

        # Surround 'condition' with 'False' values, so 'diff' will detect the
        # cases 'condition[0] == True' and 'condition[-1] == True'
        # In these cases the start or end time of the batch should be taken
        f_condition_f = np.concatenate(([False], condition, [False]))
        # In the same way, surround 'event' with zeros, so argrelmax will find a
        # relative maximum at the start.
        events = np.concatenate(([0], np.sign(np.diff(f_condition_f.astype(int))), [0]))

        # Use start or end of the period where 'f_condition_f == True'
        if refinement_step["start"]:
            # Compensate the indices for the 'True' and '[0]' values we added to
            # 'f_condition_f' and 'events', respectively
            event_time_indices = signal.argrelmax(events)[0] - 1
        else:
            # Compensate the indices for the 'True' and '[0]' values we added to
            # 'f_condition_f' and 'events', respectively
            event_time_indices = signal.argrelmin(events)[0] - 1

        # event_time_indices are indices for df_time_values["start_time"].to_numpy()[]
        new_time = get_new_time_for_batch(
            batch_timing,
            df_time_values,
            event_time_indices,
            refinement_step["start"],  # parameter 'start'
            condition,
        )
        logger.debug(f"new time: {new_time}")

        new_times[new_time_index] = new_time
        new_time_index += 1

    # logger.debug(f"new times: {new_times.tolist()}")
    return new_times


# %%
def determine_one_pass_new_times_for_one_refinement_step(
    refinement_step: dict,
    df_batch_timings: pd.DataFrame,
    df_time_values: pd.DataFrame,
) -> np.ndarray:

    if ("func" in refinement_step) and (refinement_step["func"] == "offset"):
        if refinement_step["offset"] > 0:
            new_times = df_batch_timings["start_time"] + refinement_step["offset"]
            new_times[new_times > df_batch_timings["end_time"]] = np.nan
        else:
            new_times = df_batch_timings["end_time"] + refinement_step["offset"]
            new_times[new_times < df_batch_timings["start_time"]] = np.nan
        return new_times

    logger.debug(
        f"Bulk processing {len(df_batch_timings)} batches for refinement step:\n{refinement_step}"
    )

    tag_type = tag_utils.get_tag_type(refinement_step["tag"])
    # The tag type is more than the data type only, but always ends with string, int or float
    if tag_type.endswith("string"):
        # refinement_step must contain "regex"
        # Set 'na' values to empty string for defined results with following 'contains'
        df_time_values.loc[df_time_values["value"].isna(), ["value"]] = ""
        condition = (
            df_time_values["value"].str.contains(refinement_step["regex"]).to_numpy()
        )
    elif tag_type.endswith("int") or tag_type.endswith("float"):
        if "cmp_op" in refinement_step:
            # refinement_step must contain "cmp_op" and "cmp_val"
            condition = rel_ops[refinement_step["cmp_op"]](
                df_time_values["value"].to_numpy(), refinement_step["cmp_val"]
            )
        else:
            raise Exception("function not implemented for non-string tags")
    else:
        raise Exception("no functions for unknown tag type")

    batch_debug = False
    if logger.isEnabledFor(logging.DEBUG):
        if "debug" in refinement_step and np.any(
            df_batch_timings["batch_id"] == refinement_step["debug"]
        ):
            batch_debug = True
            logger.debug(
                "determine_one_pass_new_times_for_one_refinement_step() - Active debug batch_id found"
                + f""" for {refinement_step["debug"]}"""
            )
            debug_batch_idx = np.nonzero(
                (df_batch_timings["batch_id"] == refinement_step["debug"]).to_numpy()
            )[0]
            logger.debug(f"""Batch_id for debug found at index: {debug_batch_idx}""")
            logger.debug(
                f"One_refinement_step for batches:\n{df_batch_timings.iloc[debug_batch_idx].to_string()}"
            )
            logger.debug(f"tag({refinement_step['tag']}), time/values")
            batch_start = float(df_batch_timings["start_time"].iloc[debug_batch_idx])
            batch_end = float(df_batch_timings["end_time"].iloc[debug_batch_idx])
            logger.debug(
                f"""Head and tail of df_time_values (batch_start: {batch_start}, batch_end: {batch_end}):\n{df_time_values.head()}\nTail:\n{df_time_values.tail()}"""
            )
            logger.debug(
                f"""\n{df_time_values[(df_time_values["next_time"] > batch_start) & (df_time_values["start_time"] < batch_end)].to_string()}"""
            )
            logger.debug(
                f"""max value: {np.nanmax(df_time_values["value"].to_numpy())}"""
            )
            logger.debug(
                f"""condition:\n{condition[(df_time_values["next_time"] > batch_start) & (df_time_values["start_time"] < batch_end)].tolist()}"""
            )
            logger.debug("Check the above for unexpected True at begin or end...")

    # Surround 'condition' with 'False' values, so 'diff' will detect the
    # cases 'condition[0] == True' and 'condition[-1] == True'
    # In these cases the start or end time of the batch should be taken
    f_condition_f = np.concatenate(([False], condition, [False]))
    # In the same way, surround 'event' with zeros, so argrelmax will find a
    # relative maximum at the start.
    events = np.concatenate(([0], np.sign(np.diff(f_condition_f.astype(int))), [0]))

    # Use start or end of the period where 'f_condition_f == True'
    if refinement_step["start"]:
        # Compensate the indices for the 'True' and '[0]' values we added to
        # 'f_condition_f' and 'events', respectively
        event_time_indices = signal.argrelmax(events)[0] - 1
        # event_time_indices are indices for df_time_values["start_time"].to_numpy()[]
        if batch_debug:
            debug_new_time = get_new_time_for_batch(
                df_batch_timings.iloc[debug_batch_idx],
                df_time_values,
                event_time_indices,
                True,  # parameter 'start'
                condition,
                debug=True,
            )
            logger.debug(f"""debug_new_time: {debug_new_time} """)
        new_times = df_batch_timings.apply(
            get_new_time_for_batch,
            axis=1,
            args=(
                df_time_values,
                event_time_indices,
                True,  # parameter 'start'
                condition,
            ),
        )

    else:
        # Compensate the indices for the 'True' and '[0]' values we added to
        # 'f_condition_f' and 'events', respectively
        event_time_indices = signal.argrelmin(events)[0] - 1
        # event_time_indices are indices for df_time_values["next_time"].to_numpy()[]
        if batch_debug:
            debug_new_time = get_new_time_for_batch(
                df_batch_timings.iloc[debug_batch_idx],
                df_time_values,
                event_time_indices,
                True,  # parameter 'start'
                condition,
                debug=True,
            )
            logger.debug(f"""debug_new_time: {debug_new_time} """)
        new_times = df_batch_timings.apply(
            get_new_time_for_batch,
            axis=1,
            args=(
                df_time_values,
                event_time_indices,
                False,  # parameter 'start'
                condition,
            ),
        )

    if batch_debug:
        logger.debug(f"""events:\n{events}""")
        logger.debug(f"""event_time_indices:\n{event_time_indices}""")
        # debug_batch_idx was already set above where batch_debug was set to True as well
        logger.debug(
            f"""determine_one_pass_new_times_for_one_refinement_step() return value:\n{new_times.iloc[debug_batch_idx].to_string()}"""
        )

    return new_times


# %%
def determine_new_times_for_one_refinement_step(
    refinement_step: dict, df_batch_timings: pd.DataFrame
) -> pd.Series:
    """
    Get first or last times of 'events' within the time range of each batch.

    Arguments:
    - refinement_step: dict containing tag, regexp for the value and some booleans
    - df_batch_timings: data frame containing start/end times of all batches
    Returns:
    - pd.Series: with one time for each batch, possibly containing 'NaN'

    Description:
    Depending on the definition of the refinement_step, determine when 'events'
    occur. An 'event' is the start or end of a 'condition'. Currently, the  only
    'condition' is a regex match on the value of the tag.
    After the time of events are determined, for each batch is determined
    which events occur within the (current) begin and end time for the batch.
    For each batch the time of the first or last event is returned, or NaN in case
    there were no events within the begin and end of a batch.
    """

    if ("func" in refinement_step) and (refinement_step["func"] == "offset"):
        return determine_one_pass_new_times_for_one_refinement_step(
            refinement_step,
            df_batch_timings,
            df_time_values=pd.DataFrame(),
        )

    df_time_values = tag_utils.get_tag_data(
        tag=refinement_step["tag"],
        time_range=(
            df_batch_timings["start_time"].min(),
            df_batch_timings["end_time"].max(),
        ),
    )

    tag_type = tag_utils.get_tag_type(refinement_step["tag"])
    # The tag type is more than the data type only, but always ends with string, int or float
    if tag_type.endswith("string"):
        return determine_one_pass_new_times_for_one_refinement_step(
            refinement_step,
            df_batch_timings,
            df_time_values,
        )
    elif tag_type.endswith("int") or tag_type.endswith("float"):
        if "cmp_op" in refinement_step:
            return determine_one_pass_new_times_for_one_refinement_step(
                refinement_step,
                df_batch_timings,
                df_time_values,
            )
        elif "func" in refinement_step:
            # refinement_step must contain "func" and "offset"
            return determine_per_batch_new_times_for_one_refinement_step(
                refinement_step,
                df_batch_timings,
                df_time_values,
            )
        else:
            raise Exception("function not implemented for non-string tags")
    else:
        raise Exception("no functions for unknown tag type")


# %%
def refine_batch_timings(
    df_batch_timings: pd.DataFrame, refinement_def: dict
) -> pd.DataFrame:
    """Apply all refinement steps of a batch time refinement definition to a set of batch times."""

    # refine_tags_data = get_all_tag_data_for_refinement(
    #     refinement_def,
    #     (df_batch_timings["start_time"].min(), df_batch_timings["end_time"].max()),
    # )

    df_refined = df_batch_timings.copy()

    # Do batch start time refinements, one step at a time
    for refinement_step in refinement_def["start_refinements"]:
        new_times = determine_new_times_for_one_refinement_step(
            refinement_step,
            df_refined,  # refine_tags_data
        )
        if refinement_step["ignore_missing"]:
            new_times[new_times.isna()] = df_refined["start_time"][new_times.isna()]
        df_refined = df_refined.assign(start_time=new_times)
        if df_refined.isna().to_numpy().any():
            logger.debug(
                f"refine_batch_timings() - {df_refined.isna().to_numpy().sum()} NaNs found after refinement step"
                + f"{refinement_step}\n"
                + f"Refined:\n{df_refined}"
            )

    # Do batch end time refinements, one step at a time
    for refinement_step in refinement_def["end_refinements"]:
        new_times = determine_new_times_for_one_refinement_step(
            refinement_step,
            df_refined,  # refine_tags_data
        )
        if refinement_step["ignore_missing"]:
            new_times[new_times.isna()] = df_refined["end_time"][new_times.isna()]
        df_refined = df_refined.assign(end_time=new_times)
        if df_refined.isna().to_numpy().any():
            logger.debug(
                f"refine_batch_timings() - {df_refined.isna().to_numpy().sum()} NaNs found after refinement step"
                + f"{refinement_step}\n"
                + f"Refined:\n{df_refined}"
            )

    # If we have batches with start or end time NaN, drop those batches
    if df_refined.isna().to_numpy().any():
        logger.warning(
            f"refine_batch_timings() - {df_refined.isna().to_numpy().sum()} refinements conditions not met -> dropping batches"
        )
        logger.debug(
            f"refine_batch_timings() -\n{refinement_def}\n"
            + f"Batch:\n{df_batch_timings}\n"
            + f"Refined:\n{df_refined}"
        )
        nr_batches = df_refined.shape[0]
        df_refined = df_refined.dropna(axis=0, how="any")
        nr_valid_batches = df_refined.shape[0]
        logger.info(
            f"refine_batch_timings() - dropped {nr_batches - nr_valid_batches} batches; remaining: {nr_valid_batches}"
        )

    # Return refined version of df_batch_timings
    return df_refined


# %%
def get_tag_based_base_batch_timings(
    refinement: dict, since_epoch: float
) -> pd.DataFrame:
    # Add 0.1 to start_time to get only later batches
    df_batch_timings = tag_utils.get_all_batch_id_time_ranges(
        tag=tag_utils.convert_tag_name(refinement["batch_tag"]),
        start_epoch=since_epoch + 0.1,
        value_re=refinement["regexp"],
    )
    # prevent errors in case of an empty DataFrame
    if df_batch_timings.shape[0] > 0:
        df_batch_timings = df_batch_timings.drop(columns=["tag"])

    return df_batch_timings


# %%
def get_base_batch_timings(refinement: dict, since_epoch: float) -> pd.DataFrame:
    """
    returns:
    pd.DataFrame with columns: batch_id, start_time and end_time
    """
    if "batch_tag" in refinement:
        return get_tag_based_base_batch_timings(refinement, since_epoch)
    else:
        # For now, basic time based batch IDs and times can be done with 'pseudo_' tag name
        # See tag_utils for details
        # Once we nee something more complex, it should go here.
        raise NotImplementedError(
            "ERROR: get_base_batch_timings not yet supports 'batch_tag'-less definitions"
        )


# %%
def get_new_batch_timings(
    refinement: dict, df_last: pd.DataFrame, pcs_feature_groups: list
) -> pd.DataFrame:
    """Determine all timings of all new batches for the given refinement."""

    # Find feature names that depend on time refinement definition
    # feature_groups_with_same_timing = [
    #     g for g in feature_groups if g["refinement"] == refinement["refinement_name"]
    # ]
    feature_group_names = [
        g["feature_group_name"]
        for g in pcs_feature_groups
        if g["refinement"] == refinement["refinement_name"]
    ]

    if len(feature_group_names) == 0:
        raise ValueError(
            f"No feature groups defined with refinement name {refinement['refinement_name']}"
        )
    since_epoch = get_epoch_last_existing_batch(df_last, feature_group_names)

    df_batch_timings = get_base_batch_timings(refinement, since_epoch)

    if df_batch_timings.shape[0] > 0:
        # if the end time of the batch is very close to the end time of the cache,
        # drop the last batch, as the data for this batch might be incomplete
        if (
            tag_utils.get_cache_time_range()[1] - df_batch_timings["end_time"].iloc[-1]
        ) < misc_utils.config["PCS_FEATURE_PROC_BATCH_GUARD_TIME"]:
            df_batch_timings = df_batch_timings[:-1]

    if df_batch_timings.shape[0] > 0:
        # Refinement of start and end time to get time period of interest within each batch
        df_batch_timings = refine_batch_timings(df_batch_timings, refinement)

    return df_batch_timings


# %% [raw]
#
