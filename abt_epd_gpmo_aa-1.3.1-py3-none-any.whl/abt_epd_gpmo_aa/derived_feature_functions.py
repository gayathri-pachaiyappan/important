# %%
"""
Functions to create derived features from other features.

Each function takes a DataFrame and a list of columns to act on and
then returns a Series with the resulting feature.

A column name might be a special name starting with "__const_" to indicate a
constant. The format is:
__const_<<type>>_<<value>>
in this
- <<type>> is a single character f (float), i (int), s (string)
- <<value>> is the (valid) value of the given type
  - type 'f' should match regex ([-+]?\d*\.\d+|[-+]?\d+)
"""

import operator

# %%
import re

# %%
import numpy as np
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import logger, preprocess_text_table_utils

# %%
"""
Helper functions
"""


# %%
def get_const_sources(feature_source: list) -> list:
    """return sublist with elements refering to constant values"""

    return [fs for fs in feature_source if fs.startswith("__const_")]


# %%
def get_parm_sources(feature_source: list) -> list:
    """return sublist with elements refering to parameter values"""

    return [fs for fs in feature_source if fs.startswith("__parm_")]


# %%
def get_nonconst_sources(feature_source: list) -> list:
    """return sublist with elements refering to non-constant values"""

    return [
        fs
        for fs in feature_source
        if (not (fs.startswith("__const_") or fs.startswith("__parm_")))
    ]


# %%
def get_value_sources(feature_source: list) -> list:
    """return sublist with elements refering to constant and non-constant values

    Note: this is different from "get_const_sources()+get_nonconst_sources()" as
          that would ruin the order in which both types of values are specified
    """

    return [fs for fs in feature_source if (not fs.startswith("__parm_"))]


# %%
def extract_const_value(name: str, idx: pd.Index) -> pd.Series:
    re_match = re.search(r"^__const_([fis])_(.+)$", name)
    if re_match:
        const_type = re_match.group(1)
        s = pd.Series(data=re_match.group(2), index=idx)
        if const_type == "f":
            return preprocess_text_table_utils.convert_string_to_float(s)
        elif const_type == "i":
            return preprocess_text_table_utils.convert_string_to_int(s)
        else:  # elif const_type == "s":
            return preprocess_text_table_utils.convert_string_to_string(s)
    else:
        logger.error(f"extract_const_value() - not recognised const name ({name})")
        raise ValueError("extract_const_value() - not recognised const name")


# %%
def extract_parm_value(name: str):
    """extract constant from __parm_... feature source and return as single number (float, int, bool) or string

    This function is especially intended for parameter constants (__parm_...)
    For compatibility, this function also accepts "__const_..."
    """

    re_match = re.search(r"^__(?:parm|const)_([fisb])_(.+)$", name)
    if re_match:
        const_type = re_match.group(1)
        s = re_match.group(2)
        if const_type == "f":
            return float(s)
        elif const_type == "i":
            return int(s)
        elif const_type == "b":
            return s.lower() == "true"
        else:  # elif const_type == "s":
            return str(s)
    else:
        logger.error(f"extract_parm_value() - not recognised const name ({name})")
        raise ValueError("extract_parm_value() - not recognised const name")


# %%
def get_value(df: pd.DataFrame, feature_name: str) -> pd.Series:
    """return series indicated by feature_name"""

    if feature_name.startswith("__parm_"):
        logger.error(
            f"""get_value() - Illegal use of "__parm_..." feature ({feature_name})"""
        )
        raise ValueError("get_value() - Illegal use of __parm_ feature name")
    if feature_name.startswith("__const_"):
        return extract_const_value(feature_name, df.index).copy()
    else:
        return df[feature_name].copy()


# %%
"""
Generic functions
"""


# %%
def f_count(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Count the number of columns with (valid) values per batch_id
    """
    non_const_feature_source = get_nonconst_sources(feature_source)
    result_series = df.loc[:, non_const_feature_source].count(axis=1).copy()
    result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA
    return result_series.copy()


# %%
def f_count_nonzero(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Count the number of columns with (valid) values, not zero per batch_id
    """
    non_const_feature_source = get_nonconst_sources(feature_source)
    result_series = pd.Series(
        np.count_nonzero(df.loc[:, non_const_feature_source].copy().fillna(0), axis=1)
    )
    result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA
    return result_series.copy()


# %%
def f_sum(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the sum of 'feature_source' columns per batch_id

    Optional 'feature source' "__parm_b_True/False" controls skipna (default True)
    """
    parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    if len(parm_feature_source) > 0:
        skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    if len(non_const_feature_source) > 0:
        result_series = (
            df.loc[:, non_const_feature_source].sum(axis=1, skipna=skip_na).copy()
        )
        result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA
    else:
        # set correct length
        result_series = df.iloc[:, 0]
        result_series.loc[:] = pd.NA

    # Now use const feature sources
    const_feature_source = get_const_sources(feature_source)
    if len(const_feature_source) > 0:
        for c in const_feature_source:
            result_series = result_series + extract_const_value(c, df.index)

    result_series = pd.to_numeric(result_series, errors="coerce").fillna(pd.NA)
    return result_series.copy()


# %%
def f_max(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Calculate the max of 'feature_source' columns per batch_id"""
    # parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    # if len(parm_feature_source) > 0:
    #     skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    if len(non_const_feature_source) > 0:
        result_series = (
            df.loc[:, non_const_feature_source].max(axis=1, skipna=skip_na).copy()
        )
        result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA
    else:
        # set correct length
        logger.warning(
            f"""WARNING: no non-const feature sources {non_const_feature_source}"""
        )
        result_series = df.iloc[:, 0].copy()
        result_series.loc[:] = pd.NA

    # Now use const feature sources
    const_feature_source = get_const_sources(feature_source)
    if len(const_feature_source) > 0:
        for c in const_feature_source:
            tmp = get_value(df, c)
            result_series[tmp > result_series] = tmp

    return result_series.copy()


# %%
def f_min(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Calculate the min of 'feature_source' columns per batch_id"""
    # parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    # if len(parm_feature_source) > 0:
    #     skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    if len(non_const_feature_source) > 0:
        result_series = (
            df.loc[:, non_const_feature_source].min(axis=1, skipna=skip_na).copy()
        )
        result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA
    else:
        # set correct length
        result_series = df.iloc[:, 0].copy()
        result_series.loc[:] = pd.NA

    # Now use const feature sources
    const_feature_source = get_const_sources(feature_source)
    if len(const_feature_source) > 0:
        for c in const_feature_source:
            tmp = get_value(df, c)
            result_series[tmp < result_series] = tmp

    return result_series.copy()


# %%
def f_mean(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Calculate the average of 'feature_source' columns per batch_id"""
    # parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    # if len(parm_feature_source) > 0:
    #     skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    return df.loc[:, non_const_feature_source].mean(axis=1, skipna=skip_na).copy()


# %%
def f_median(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Calculate the median of 'feature_source' columns per batch_id"""
    # parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    # if len(parm_feature_source) > 0:
    #     skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    return df.loc[:, non_const_feature_source].median(axis=1, skipna=skip_na).copy()


# %%
def f_product(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Calculate the product of 'feature_source' columns per batch_id

    Optional 'feature source' "__parm_b_True/False" controls skipna (default True)
    """
    parm_feature_source = get_parm_sources(feature_source)
    skip_na = True
    if len(parm_feature_source) > 0:
        skip_na = extract_parm_value(parm_feature_source[0])
    non_const_feature_source = get_nonconst_sources(feature_source)
    result_series = (
        df.loc[:, non_const_feature_source].prod(axis=1, skipna=skip_na).copy()
    )
    result_series[df.loc[:, non_const_feature_source].isna().all(axis=1)] = pd.NA

    # Now use const feature sources
    const_feature_source = get_const_sources(feature_source)
    if len(const_feature_source) > 0:
        for c in const_feature_source:
            result_series = result_series * extract_const_value(c, df.index)

    result_series = pd.to_numeric(result_series, errors="coerce")
    return result_series.copy()


# %%
def f_operator_div(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise (per batch_id) division of column feature_source[0] by column feature_source[1]
    """
    value_source = get_value_sources(feature_source)
    result_series = get_value(df, value_source[0]) / get_value(
        df, value_source[1]
    ).replace({0: np.nan})
    result_series = pd.to_numeric(result_series, errors="coerce")
    return result_series.copy()


# %%
def f_operator_mod(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise (per batch_id) modulo of column feature_source[0] by column feature_source[1]
    """
    value_source = get_value_sources(feature_source)
    result_series = get_value(df, value_source[0]) % get_value(
        df, value_source[1]
    ).replace({0: np.nan})
    return result_series.copy()


# %%
def f_operator_sub(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the subtraction of 'feature_source' columns per batch_id
    """

    value_source = get_value_sources(feature_source)
    result_series = get_value(df, value_source[0])

    for feat_item in value_source[1:]:
        result_series = result_series - get_value(df, feat_item)

    # Convert to float after calculation
    result_series = pd.to_numeric(result_series, errors="coerce")
    result_series = result_series.fillna(np.nan)
    return result_series.copy()


# %%
def f_log(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise (per batch_id) log of column feature_source[0] with base column feature_source[1]
    """
    value_source = get_value_sources(feature_source)
    # Natural logarithm, element-wise
    result = np.log(get_value(df, value_source[0]).fillna(np.nan).to_numpy())
    if len(value_source) > 1:
        # in case a base is provided, use it: y-log(x) = ln(x) / ln(y)
        result = result / np.log(
            get_value(df, value_source[1]).fillna(np.nan).to_numpy()
        )
    return pd.Series(result).copy()


# %%
def f_trunc(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise np.trunc of column feature_source[0]
    """
    value_source = get_value_sources(feature_source)
    result = np.trunc(get_value(df, value_source[0]).fillna(np.nan).to_numpy())
    return pd.Series(result).copy()


# %%
def f_rint(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise np.rint of column feature_source[0]
    """
    value_source = get_value_sources(feature_source)
    result = np.rint(get_value(df, value_source[0]).fillna(np.nan).to_numpy())
    return pd.Series(result).copy()


# %%
def f_ceil(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise np.ceil of column feature_source[0]
    """
    value_source = get_value_sources(feature_source)
    result = np.ceil(get_value(df, value_source[0]).fillna(np.nan).to_numpy())
    return pd.Series(result).copy()


# %%
def f_floor(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise np.floor of column feature_source[0]
    """
    value_source = get_value_sources(feature_source)
    result = np.floor(get_value(df, value_source[0]).fillna(np.nan).to_numpy())
    return pd.Series(result).copy()


# %%
def f_rate(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the element-wise (per batch_id) rate


    Description
    rate definition: (value t1 - value t0) / duration (t1 - t0)

    value t0: column feature_source[0]
    value t1: column feature_source[1]
    duration (t2 - t1): column feature_source[2]
    """

    value_source = get_value_sources(feature_source)
    startvalue_col = value_source[0]
    endvalue_col = value_source[1]
    duration_col = value_source[2]

    result_series = (
        get_value(df, endvalue_col) - get_value(df, startvalue_col)
    ) / get_value(df, duration_col).replace({0: np.nan})
    result_series = pd.to_numeric(result_series, errors="coerce")
    return result_series.copy()


# %%
def f_first_non_na(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Find the element-wise (per batch_id) first non-NA value, starting at first feature in feature_source list


    Description
    Copy values of feature_source[0]. If any values are NA/NaN, use values from feature_source[1]. Repeat
    for feature_source[2], etc.
    """

    value_source = get_value_sources(feature_source)
    result_series = get_value(df, value_source[0])

    for feat_item in value_source[1:]:
        result_series[result_series.isna()] = get_value(df, feat_item)

    return result_series.copy()


# %%
def f_drop_value(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Replace given values in one feature by pd.NA/np.nan, causing them to be dropped

    Description
    Copy values of feature_source[0]. If any values match a specific value or regex,
    they are replaced by pd.NA or np.nan
    """

    value_source = get_value_sources(feature_source)
    parm_source = get_parm_sources(feature_source)
    result_series = get_value(df, value_source[0])
    parm_value = [extract_parm_value(v) for v in parm_source]

    dtype_name = str(result_series.dtype).lower()

    if "__parm_s_" in parm_source[0]:
        # values to drop are strings -> make sure dtype is nullable
        result_series = result_series.astype("string")

        parm = parm_value[0]
        to_drop = result_series.str.contains(parm, na=pd.NA, regex=True)
        for parm in parm_value[1:]:
            to_drop |= result_series.str.contains(parm, na=pd.NA, regex=True)
        result_series[to_drop] = pd.NA

    elif "int" in dtype_name:
        # values to drop are integers -> make sure dtype is nullable
        result_series = result_series.astype("Int64")

        parm = parm_value[0]
        to_drop = result_series == parm
        for parm in parm_value[1:]:
            to_drop |= result_series == parm
        result_series[to_drop] = pd.NA

    elif "float" in dtype_name or "object" in dtype_name:
        # values are NaN-able; no need to convert

        parm = parm_value[0]
        num_values = result_series.copy().fillna(np.nan).to_numpy()
        to_drop = np.isclose(num_values, parm)
        for parm in parm_value[1:]:
            to_drop |= np.isclose(num_values, parm)
        result_series[to_drop] = np.nan

    else:
        logger.error(
            f"""ERROR: feature {value_source[0]} has unknow data type {result_series.dtype}"""
        )
        raise ValueError("""Unknown dtype for feature column""")

    return result_series.copy()


# %%
def f_extract_string(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Extract substring from string
    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] contains series from where substring is extracted
    feature_source[1] contains the regular expression to be used for extraction of the substring
    regular expression has the prefix "__const_s_"
    """

    non_const_feature_source = get_nonconst_sources(feature_source)
    parm_feature_source = [
        extract_parm_value(i)
        for i in get_parm_sources(feature_source) + get_const_sources(feature_source)
    ]
    if len(parm_feature_source) != 1:
        raise ValueError(
            """You must provide 1 parameter: regular expression (with a capture group), e.g.: "__parm_s_^(.*)$" """
        )

    result_series = get_value(df, non_const_feature_source[0])
    # The 2nd 'source' should be a string containing the regex for extraction, normally a const
    regex_str = str(parm_feature_source[0])

    result_series = result_series.str.extract(pat=regex_str, expand=False)

    result_series = result_series.fillna(pd.NA).astype("string")  # nullable string type
    return result_series.copy()


# %%
def f_utcoffset(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Get offset of local time in timezone at time of (UTC) epoch in data
    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] feature name containing time in epoch
    feature_source[1] parameter containing the timezone, for example "Europe/Amsterdam", "Europe/Berlin"

    See also:
        import zoneinfo
        zoneinfo.available_timezones()
    """

    non_const_feature_source = get_nonconst_sources(feature_source)
    parm_feature_source = [
        extract_parm_value(i)
        for i in get_parm_sources(feature_source) + get_const_sources(feature_source)
    ]
    if len(parm_feature_source) != 1:
        raise ValueError(
            """You must provide 1 parameter: time zone, e.g.: "__parm_s_Europe/Amsterdam" """
        )

    time_string_col = non_const_feature_source[0]
    timezone = str(parm_feature_source[0])

    # First convert to 'datetime' objects, timezone aware, in UTC and then to requested timezone
    result_series = pd.Series(
        pd.to_datetime(get_value(df, time_string_col).to_numpy(), utc=True, unit="s")
    ).dt.tz_convert(timezone)
    # then get offset from UTC, converted to float
    result_series = result_series.apply(
        lambda x: (x.utcoffset() / pd.Timedelta("1s")) if pd.notna(x) else np.nan
    )
    return result_series.copy()


# %%
def f_astype_int64(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Convert column to integer dtype with missing values
    """

    value_source = get_value_sources(feature_source)
    feature_series = get_value(df, value_source[0])
    # astype("Int64") cannot handle floats as (int) can, but we need it for pd.NA
    first_step = pd.to_numeric(feature_series, errors="coerce")
    result_series = first_step.fillna(0).astype(int).astype("Int64")
    result_series[first_step.isna()] = pd.NA
    return result_series.copy()


# %%
def f_astype_float_or_int64(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Convert column to float and if possible to integer dtype with missing values
    """

    value_source = get_value_sources(feature_source)
    result_series = pd.to_numeric(get_value(df, value_source[0]), errors="coerce")
    return result_series.copy()


# %%
def f_astype_string(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Convert column to string dtype
    """

    value_source = get_value_sources(feature_source)
    return get_value(df, value_source[0]).astype("string").copy()


# %%
def f_concat_string(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Concatenate string features, separated by __parm_...

    During concatenation, NA values are replaced by the empty string.
    If, after concatenation, the result only contains the separators, it is set to NA.
    Note, this will set the concatenation of all empty strings to NA as well.
    """
    value_source = get_value_sources(feature_source)
    parm_source = get_parm_sources(feature_source)
    result_series = get_value(df, value_source[0])
    parm_value = [extract_parm_value(v) for v in parm_source]

    result_series = result_series.astype("string")
    separator = ""
    all_separator = ""
    for val_col in value_source[1:]:
        if len(parm_value):
            separator = str(parm_value.pop(0))
        # If there are no more parameter values, all_seperator will be extended with the last value
        # as that will also happen in .str.cat(). Later we use it to test if the result only consists
        # of separators.
        all_separator += separator
        result_series = result_series.str.cat(
            get_value(df, val_col).astype("string"), sep=separator, na_rep=""
        )
    # In case all values are NA (or ""), the result will be the concatenation of all separators -> set it to NA
    to_drop = result_series == all_separator
    result_series[to_drop] = pd.NA
    return result_series.copy()


# %%
def f_whole_float_to_string(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Convert from rounded floating point value to (nullable) string for precise matching"""

    value_source = get_value_sources(feature_source)
    # From a (almost) whole number float -> +/-0.1  to prevent rounding issues; ->string to allow for pd.NA
    data_values = get_value(df, value_source[0]).fillna(np.nan).to_numpy()
    # Add +0.3/-0.1 for correct value after truncate of the (almost whole) numbers (0.1 for sign(0))
    return_series = pd.Series(
        np.rint(data_values) + 0.1 + 0.2 * np.sign(data_values), index=df.index
    )
    # The real 'trunc' is done in the string representation
    return_series = return_series.astype("string").str.replace(r"\..*$", "", regex=True)
    # replace literal string 'nan', 'inf', etc to pd.NA as would be expected
    return_series.loc[np.logical_not(np.isfinite(data_values))] = pd.NA

    return return_series.copy()


# %%
def f_condition(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Set result to 0 (false) or 1 (true) based on a condition

    df: contains dataframe with feature data: one row per batch, one column per feature
    value_source[0] feature name that the condition acts on
    value_source[1] feature name supporting the condition in case of a binary operator
    parameter_source[0] parameter specifying the condition
    parameter_source[1+] parameter supporting the condition in case the condition requires parameters

    Note, above 'feature_source' is used for simplicity; it really is value_source[...]
    i.e. the feature_source without the elements starting with "__parm_..."
    """

    def np_isclose_wrapper(a: pd.Series, b: pd.Series) -> pd.Series:
        """wrapper around isclose"""
        return pd.Series(
            np.isclose(a.fillna(np.nan).to_numpy(), b.fillna(np.nan).to_numpy()),
            index=a.index,
        )

    def notclose(a: pd.Series, b: pd.Series) -> pd.Series:
        """wrapper around logical not and isclose"""
        return pd.Series(
            np.logical_not(
                np.isclose(a.fillna(np.nan).to_numpy(), b.fillna(np.nan).to_numpy())
            ),
            index=a.index,
        )

    # Initialise
    value_source = get_value_sources(feature_source)
    parm_source = get_parm_sources(feature_source)
    under_test = get_value(df, value_source[0])
    parm_value = [extract_parm_value(v) for v in parm_source]
    condition = parm_value[0]
    result_values = pd.Series(0, index=df.index)

    # Prepare execution of conditions
    binary_operators = {
        ">": operator.gt,
        "<": operator.lt,
        ">=": operator.ge,
        "<=": operator.le,
        "==": operator.eq,
        "!=": operator.ne,
        "isclose": np_isclose_wrapper,
        "notclose": notclose,
    }
    unary_operators_with_reference = {
        "isna": pd.isna,
        "notna": pd.notna,
    }

    # Execute condition testing
    if condition in binary_operators:
        reference_value = get_value(df, value_source[1])
        result_values = binary_operators[condition](under_test, reference_value)
        # .astype("Int64") cannot handle pd.NA, but no problem here
        result_values = result_values.astype("Int64")
        result_values[reference_value.isna()] = pd.NA
    elif condition in unary_operators_with_reference:
        result_values = unary_operators_with_reference[condition](under_test)
    elif condition == "regex":
        pat = parm_value[1]
        result_values = under_test.str.contains(
            pat, case=True, flags=0, na=None, regex=True
        )
        # later .astype("Int64") can't handle NA, so replace here. Will be corrected as final step
        result_values = result_values.fillna(False)
    else:
        logger.error(f"""ERROR: Unknown condition '{condition}' parameter specified.""")
        raise ValueError("""Unknown condition parameter specified.""")

    result_values = result_values.astype("Int64")
    if not condition in unary_operators_with_reference:
        # Set NA as expected
        result_values[under_test.isna()] = pd.NA
    else:
        # A feature can be NA due to missing (but expected) values,
        # or due to pivot from long to wide format.
        # Don't NA the results of an NA test; use 'reference feature' instead.
        reference_value = get_value(df, value_source[1])
        result_values[reference_value.isna()] = pd.NA

    return result_values


# %%
def f_select(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Index based copy of a value

    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] column name index value (0 based)
    feature_source[1] column name with values for index '0'
    feature_source[...] column name with values for index '...'
    feature_source[N]  column name with values for index 'N-1'

    Note, index 'i' is rounded to the nearest integer and limited to [0..N-1]
    In formula: i_effective = min(max(rint(i), 0), N-1)
    Note, above 'feature_source' is used for simplicity; it really is value_source[...]
    i.e. the feature_source without the elements starting with "__parm_..."

    """

    # Initialise
    value_source = get_value_sources(feature_source)
    indices = get_value(df, value_source[0])
    result_values = pd.Series(pd.NA, index=df.index)

    # Prepare selection of values
    select_columns = value_source[1:]  # remove first (which is 'indices')
    max_valid_indeces = len(select_columns) - 1
    indices = indices.astype("Int64")
    indices[indices < 0] = 0
    indices[indices > max_valid_indeces] = max_valid_indeces

    # Select values
    for i in range(max_valid_indeces + 1):
        result_values[indices == i] = get_value(df, select_columns[i])

    return result_values


# %%
def f_id_based_on_time_window(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Determine string window (batch) ID related to time point in time window

    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] column name time point
    feature_source[1] column name time window start
    feature_source[2] column name time window end
    feature_source[3] column name of ID to tie to time point

    Returns:
    pd.Series: series containing batch_id related to time point
    """

    value_source = get_value_sources(feature_source)
    if len(value_source) != 4:
        logger.warning(
            f"""Incorrect number of value itemsi ({len(value_source)}) in feature_source list."""
        )
        raise ValueError("Incorrect number of items in feature_source list.")

    time_point_col = value_source[0]
    window_starttime_col = value_source[1]
    window_endtime_col = value_source[2]
    id_col = value_source[3]
    df_windows = (
        df[value_source]  # all relevant columns
        .copy()
        .dropna(
            axis=0, how="any", subset=[window_starttime_col, window_endtime_col]
        )  # ,ignore_index=True)
        .reset_index(drop=True)
        .copy()
    )
    df_ret = df[[time_point_col]].copy()
    epochs = df_ret[time_point_col]
    df_ret["__return_value"] = pd.NA
    for (_, window_row) in df_windows.iterrows():
        # Set "__return_value" for all time points between start and end time of window
        df_ret.loc[
            (epochs >= window_row[window_starttime_col])
            & (epochs < window_row[window_endtime_col]),
            "__return_value",
        ] = window_row[id_col]
    df_ret["__return_value"] = df_ret["__return_value"].astype("string")

    return df_ret["__return_value"].copy()


# %%
def f_time_align_value(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """Add the time until the next mass arrives at the filter

    Requires time sorted df with the following columns:
     - feature_source[0] value to align
     - feature_source[1] time related to value
     - feature_source[2] target time
    """

    value_source = get_value_sources(feature_source)
    if len(value_source) != 3:
        logger.warning("Incorrect number of items in feature_source list.")
        raise ValueError("Incorrect number of items in feature_source list.")

    value_col = value_source[0]
    time_of_value_col = value_source[1]
    target_time_col = value_source[2]
    df_ret = df[[target_time_col]].copy()
    df_base_data = (
        df[[value_col, time_of_value_col]]
        .copy()
        .dropna(
            axis=0, how="any", subset=[value_col, time_of_value_col]
        )  # ,ignore_index=True)
        .sort_values(by=time_of_value_col, axis=0, ascending=True, ignore_index=True)
        .copy()
    )

    # align by linear interpolation
    df_ret["__return_value"] = np.interp(
        df_ret[target_time_col]
        .fillna(np.nan)
        .astype(float)
        .to_numpy(),  # times for which to interpolate
        df_base_data[time_of_value_col].astype(float).to_numpy(),  # known times
        df_base_data[value_col].astype(float).to_numpy(),  # known values
    )
    return df_ret["__return_value"].copy()


# %%
def f_groupby(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate aggregating function over groups (mutiple rows with same feature value to group by)

    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] - (required) feature to group by
    feature_source[1] - (required) feature with values to aggregate
    feature_source[2] - (required) feature name to merge group results to (for example 'batch_id' or the groupby feature)
    feature_source[3] - (required) name function to calculate (__parm_s_ )
    feature_source[4] - (optional) control drop of NA as group (__parm_b_ default True)

    For the possible function names see:
    https://pandas.pydata.org/docs/dev/user_guide/groupby.html#built-in-aggregation-methods

    Returns:
    pd.Series: series containing aggregated values left merged to rows with source [2] and source [0]
    """
    value_source = get_value_sources(feature_source)
    parm_feature_source = get_parm_sources(feature_source)

    if len(value_source) != 3:
        logger.warning("Incorrect number of feature names feature_source list.")
        raise ValueError("Incorrect number of items in feature_source list.")
    if (len(parm_feature_source) < 1) or (len(parm_feature_source) > 2):
        logger.warning("Incorrect number of parameters in feature_source list.")
        raise ValueError(
            """You must provide 1 or 2 parameter values for function and (optional) drop_na"""
        )

    groupby_col = value_source[0]
    value_col = value_source[1]
    merge_col = value_source[2]
    fun = extract_parm_value(parm_feature_source[0])
    drop_na = True
    if len(parm_feature_source) > 1:
        drop_na = extract_parm_value(parm_feature_source[1])
        if not isinstance(drop_na, bool):
            raise TypeError(
                f"parameter drop_na: must be Boolean, but got value: {drop_na}, which is of type {type(drop_na).__name__}"
            )

    df_groupby = (
        df[[groupby_col, value_col]]
        .copy()
        .groupby(
            by=groupby_col,
            axis=0,
            as_index=False,
            group_keys=True,
            observed=True,
            dropna=drop_na,
        )
        .agg(fun)
        .rename(columns={value_col: "__return_value"})
    )
    df_result = (
        df[[merge_col]]
        .copy()
        .reset_index(
            drop=False,
        )  # names="__index")  # keep index
        .rename(columns={"index": "__index"})
        .merge(
            df_groupby,
            how="left",
            left_on=merge_col,
            right_on=groupby_col,
        )
    )
    df_result = df_result.set_index(
        "__index", drop=True
    )  # drop column that held the index
    return df_result["__return_value"].copy()


# %%
def f_rolling(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the rolling function of a selected column (feature_source[1]) according to the time dimension (feature_source[0]) provided.
    feature_source should be provided as a 4 item list in the following order (order applies for non-constant
    and parameter (/constant) features independently):
        - (required) time feature (time_feature)
        - (required) feature to perform calculation on (target_feature)
        - (required) rolling window period (__parm_[si]_ feature; use of __const_ deprecated)
        - (required) function to calculate (__parm_s_ feature; use of __const_ deprecated)
        - (optional) control drop of NAs in time feature (__parm_b_ default False; use of __const_ deprecated)
    """
    ### Get non-constant features and parameter values (incl. parms in contant features for <v1.0.0 compatibility)
    non_const_feature_source = get_nonconst_sources(feature_source)
    parm_feature_source = [
        extract_parm_value(i)
        for i in get_parm_sources(feature_source) + get_const_sources(feature_source)
    ]
    if len(parm_feature_source) == 0:
        raise ValueError(
            """You must provide at least 2 parameter values for window, fun and (optional) skip_na_in_time_feature, e.g.: "__parm_s_24H", "__parm_s_max", "__parm_b_True" """
        )

    ## get non constant features
    time_feature = non_const_feature_source[0]
    target_feature = non_const_feature_source[1]
    ## get parameter features
    window = parm_feature_source[0]
    if isinstance(window, int):
        rolling_over_time = False
    else:
        rolling_over_time = True
    fun = parm_feature_source[1]
    # Accept 'avg' as an alias for 'mean' for compatibility
    fun = "mean" if fun == "avg" else fun
    if fun in ["cov", "corr", "quantile", "apply", "aggregate"]:
        logger.error(f"""ERROR: rolling does not support {fun}""")
        raise ValueError(
            """function name in parameter is not supported with 'rolling'"""
        )

    # select the required columns
    df_ret = df.loc[:, non_const_feature_source[0:2]].copy()
    # create a new index column so we do not lose the original sorting of the data when we sort later
    df_ret = df_ret.reset_index()
    ret_index = pd.DataFrame(index=list(df_ret["index"]))
    # perform sorting on the time_feature column for consistent results (+required to perform rolling using time)
    df_ret = df_ret.sort_values(by=time_feature, na_position="last")
    # Convert target values into float, even if there are pd.NA present
    df_ret[target_feature] = df_ret[target_feature].fillna(np.nan).astype(float)

    # Handle NA (have to be removed in case of time window...)
    skip_na_in_time_feature = False
    if len(parm_feature_source) > 2:
        skip_na_in_time_feature = parm_feature_source[2]
        if not isinstance(skip_na_in_time_feature, bool):
            raise TypeError(
                f"For skip_na_in_time_feature expected a boolean, but got value: {skip_na_in_time_feature}, which is of type {type(skip_na_in_time_feature).__name__}"
            )
    if skip_na_in_time_feature:
        df_ret = df_ret.dropna(subset=[time_feature])

    if rolling_over_time:
        # convert epoch to datetime (required for time based rolling windows to work)
        df_ret["__datetime"] = pd.to_datetime(df_ret[time_feature], unit="s")
        ## ignore rows with missing time feature, if requested
        df_ret = df_ret.set_index("__datetime")
        min_periods = 1
    else:
        min_periods = window

    # Do the real rolling
    # Note: min_periods has a future warning about the default, so set it explicitly
    df_ret["__rolling"] = (
        df_ret[target_feature].rolling(window, min_periods=min_periods).agg(fun)
    )

    # Correct for sorting, setting index, etc.
    df_ret = df_ret.set_index("index")
    # create rows with na values for rows with indeces that were removed because of skip_na_in_time_feature
    # This will also sort into original order
    df_ret = ret_index.join(df_ret, how="left")

    result_series = df_ret.loc[:, "__rolling"]
    return result_series.copy()


# %%
"""
!!! DEPRECATED functions !!!
"""


# %%
def f_extract_int_from_string(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Extract substring from string - deprecated
    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] contains series from where substring is extracted
    feature_source[1] contains the regular expression to be used for extraction of the substring
    regular expression has the prefix "__const_s_"
    """

    # First extract the right part of the string values
    result_series = f_extract_string(df, feature_source).copy()

    # then convert strings
    # However, this sets all NAs to np.iinfo(np.int64).min that are not filtered out with 'dropna()'
    return preprocess_text_table_utils.convert_string_to_int(result_series).copy()


# %%
def f_x_group_sum(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Compatibility function for groupby().sum()

    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] column name groupby e.g. child_batch_id_mbv
    feature_source[1] column name containing feature values to be summed
    feature_source[2] column name to merge group results to (for example 'batch_id' or the groupby column)

    Returns:
    pd.Series: series containing summed values left merged to rows with source [2] and source [0]
    """

    ret_values = f_groupby(df.copy(), feature_source + ["__parm_s_sum"])
    ret_values = pd.to_numeric(ret_values, errors="coerce")
    return ret_values.copy()


# %%
"""
!!! DEPRECATED functions !!!
"""


# %%
def f_weighted_average(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate the weighted average of list 'feature_source' columns per batch_id
    list feature_source contains tuple with flock_age and trolley_cnt in pairs of the same farmer
    wa formula:

    weighted_avg_n = sum(a_n * weights_n) / sum(weights_n)

    where
    a_n = feature_source[2*n] and
    weights_n = feature_source[2*n +1]

    in other words:
    feature_source[0] tuple of column name mean value e.g. flockage farm 1 and
    column name weight value e.g. trolleys delivered farm 1
    feature_source[1] tuple of column name mean value e.g. flockage farm 2 and
    column name weight value e.g. trolleys delivered farm 2
    :
    feature_source[n] tuple of column name mean value e.g. flockage farm n and
    column name weight value e.g. trolleys delivered farm n

    df: contains dataframe with feature data: one row per batch, one column per feature

    Returns:
    pd.Series: series containing weighed average values one row per batch

    """
    sumteller = 0
    sumnoemer = 0
    for farm in feature_source:
        sumteller = sumteller + df.loc[:, farm].copy().fillna(0).prod(
            axis=1, numeric_only=True
        )
        # if flockage = NaN than trolley count must not included
        sumnoemer = sumnoemer + (df.loc[:, farm[0]].copy().notna()) * (
            df.loc[:, farm[1]].copy().fillna(0).astype("float")
        )
    sumteller = sumteller.astype("float")  # prevent ZeroDivisionError exception
    sumnoemer = sumnoemer.astype("float")
    result_series = sumteller / sumnoemer

    result_series = pd.to_numeric(result_series, errors="coerce")
    return result_series.copy()


# %%
def f_diff_max_min(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate difference between the minimum and the maximum found from all the columns selected

    df: contains dataframe with feature data: one row per batch, one column per feature

    Returns:
    pd.Series: series containing the duration in seconds between the min and max epochs found in all the columns provided to the function

    """

    # get the selected columns:

    result = df.loc[:, feature_source].copy()

    # calculate the difference:

    return result.max(axis=1) - result.min(axis=1)


# %%
"""
IVM specific functions
"""


# %%
def f_flockage_calc(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Calculate element-wise (per batch_id) the flockage
    Flockage is the column flock_laying_date_epoch_smart (feature_source[0]) subtracted by column
    farm_{farm}_flock_birth_date_epoch_smart (feature_source[1]) if column
    farm_{farm}_trolleys_cnt_smart > 0 (feature_source[2])

    If column trolley_cnt == 0 no eggs are delivered by this farmer -> the flockage is not applicable (nan)
    """
    result_series = pd.Series(data=np.NaN, index=df.index, dtype=float)

    if len(feature_source) != 3:
        logger.warning("Incorrect number of items in feature_source list.")
        raise ValueError("Incorrect number of items in feature_source list.")
    else:
        mask = df.loc[:, feature_source[2]].copy().fillna(0) > 0
        result_series[mask] = (
            df.loc[:, feature_source[0]].copy() - df.loc[:, feature_source[1]].copy()
        )

    return result_series.copy()


# %%
def f_count_flock_breed(df: pd.DataFrame, feature_source: list) -> pd.Series:
    """
    Count the number of flocks breeds of 'feature_source' columns per batch_id

    df: contains dataframe with feature data: one row per batch, one column per feature
    feature_source[0] column name flockbreed farm 1
    feature_source[1] column name trolleys delivered farm 1
    feature_source[2] column name flockbreed farm 2
    feature_source[3] column name trolleys delivered farm 2
    :
    feature_source[n-1] column name flockbreed farm n
    feature_source[n] column name trolleys delivered farm n

    Returns:
    pd.Series: series containing number of flock breeds one row per batch

    """
    col_breed = feature_source[0::2]
    col_trolley = feature_source[1::2]
    if len(col_breed) == len(col_trolley):
        df_mask = df[col_trolley].copy().fillna(0).astype("Int64")
        # columns get new name -> df can be masked
        df_mask = df_mask.rename(
            columns=dict(zip(col_trolley, range(len(col_trolley))))
        )
        mask = df_mask > 0
        mask = mask.astype(bool)

        df_breed = df[col_breed].copy().fillna(pd.NA)
        # columns get new name -> df can be masked
        df_breed = df_breed.rename(columns=dict(zip(col_breed, range(len(col_breed)))))

        df_result = df_breed[mask]
        df_result = df_result.replace(["", " ", np.NaN], pd.NA)
        result_series = df_result.nunique(axis=1, dropna=True)
    else:
        logger.warning("Number of flock breed columns is not equal to trolley columns.")
        raise ValueError(
            "Number of flock breed columns is not equal to trolley columns."
        )

    return result_series.astype("Int64").copy()


# %%
"""
Name all functions listed above for use in feature definitions
"""

# %%
feature_functions = {
    "count_valid": f_count,
    "count_nonzero": f_count_nonzero,
    "sum": f_sum,
    "max": f_max,
    "min": f_min,
    "mean": f_mean,
    "median": f_median,
    "multiply": f_product,
    "divide": f_operator_div,
    "modulo": f_operator_mod,
    "subtract": f_operator_sub,
    "log": f_log,
    "trunc": f_trunc,
    "rint": f_rint,
    "ceil": f_ceil,
    "floor": f_floor,
    "rate": f_rate,
    "first_non_na": f_first_non_na,
    "drop_value": f_drop_value,
    "extract_str": f_extract_string,
    "utcoffset": f_utcoffset,
    "astype_int": f_astype_int64,
    "astype_float_or_int": f_astype_float_or_int64,
    "astype_string": f_astype_string,
    "concat_string": f_concat_string,
    "whole_float_to_string": f_whole_float_to_string,
    "condition": f_condition,
    "select": f_select,
    "id_based_on_time_window": f_id_based_on_time_window,
    "time_align_value": f_time_align_value,
    "groupby": f_groupby,
    "rolling": f_rolling,
    # historic functions to be removed in a future version
    "avg": f_mean,
    "extract_str_as_int": f_extract_int_from_string,
    "x_group_sum": f_x_group_sum,
    "weighted_avg": f_weighted_average,
    "diff_max_min": f_diff_max_min,
    "flockage_calc": f_flockage_calc,
    "flockbreed_cnt": f_count_flock_breed,
}
