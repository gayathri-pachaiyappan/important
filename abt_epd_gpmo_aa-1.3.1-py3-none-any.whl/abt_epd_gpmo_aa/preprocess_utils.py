# %%
"""
Generic Preprocess data utilities

This module provides:
 - def find_preproc_definitions(def_name: str) -> list:
 - def get_data_paths(file_def: dict, new: bool) -> list:
 - def hash64(data: str) -> int:
 - def generate_rowid(df: pd.DataFrame, cols: list) -> pd.Series:
 - def add_cross_references(df: pd.DataFrame, df_last_ext: pd.DataFrame, group_col: str, id_col: str) -> pd.DataFrame:
 - def generate_partition_id(epoch: pd.Series, partition_period: int) -> pd.Series:
 - def get_element_lists_per_type(element_type: dict) -> dict:
 - def write_single_type_data(df: pd.DataFrame, base_table_info: dict, type_name: str) -> None:
 - def write_preprocessed_data_per_type(...) -> None:

"""

# %%
import hashlib
import re

# %%
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import athena_utils, logger, misc_utils, s3_utils


# %%
def find_preproc_definitions(def_name: str) -> list:
    """Find toml/json definition files and return all filenames found"""

    def_files = misc_utils.find_project_files(
        f'{misc_utils.config["PREPROCESSED"]}_{def_name}.*'
    )
    # strip .toml or .json from file names
    preproc_def_files = [
        re.sub(r"^.*/([^/]*)\.(?:toml|json)$", r"\1", f)
        for f in def_files
        if re.search(r"\.(?:toml|json)$", f)
    ]

    if not len(preproc_def_files):
        logger.error(
            f'ERROR: {misc_utils.config["PREPROCESSED"]}_{def_name}.(toml|json) not found in project or current directory.'
        )
        raise ValueError(
            f'{misc_utils.config["PREPROCESSED"]}_{def_name}.(toml|json) not found.'
        )
    else:
        return preproc_def_files


# %%
def get_data_paths(file_def: dict, new: bool) -> list:
    """Find S3 paths of original data files

    Arguments:
    - file_def : dict containing keys "datasource_name", "filename" with
        "filename" a 'full matching' regular expression (backwards compatible
        with just the full name normal string that it used to be)
    - new : boolean whether to pich data from the 'new' or from the 'processed' folder
    """

    # File is read straight from the bucket
    base_path = (
        misc_utils.config["ORIGINAL_DATA_S3_PATH"]
        + file_def["datasource_name"]
        + "/"
        + ("new" if new else "processed")
        + "/"
    )

    all_files = s3_utils.get_sorted_file_paths(base_path)

    return [
        f for f in all_files if re.fullmatch(file_def["filename"], f.split("/")[-1])
    ]


# %%
def hash64(data: str) -> int:
    """Calculate 64 bit (cryptographic) hash"""
    # Don't use python hash, as it uses a random seed at each run
    sha_hash = hashlib.sha256(data.encode("utf-8"))
    # Take 1st 16 Hex digits of hash and convert to 64 bit int.
    return int(sha_hash.hexdigest()[0:16], 16)


# %%
def generate_rowid(df: pd.DataFrame, cols: list) -> pd.Series:
    """Generate unique row IDs from the string concatenation of cols"""

    # generate row_ids
    logger.debug("Generating hashes...")
    combined_data = df[cols.pop(0)].astype(
        "string"
    )  # get the first column from the list
    for c in cols:
        combined_data = combined_data + df[c].astype("string")

    # Apply(hash64) returns uint64, which is not compatible with Glue catalog table
    return combined_data.apply(hash64).astype("int64")


# %%
# TODO: perhaps,n the future also: return pd.Series instead of DataFrame
def add_cross_references(
    df: pd.DataFrame, df_last_ext: pd.DataFrame, group_col: str, id_col: str
) -> pd.DataFrame:
    """Add a reference to the previous datapoint for the same group

    df should contain columns: group_col, id_col and should already be sorted (ascending by group, then time or
    other property that defines 'previous')
    df_last_ext should contain columns: group_col,  and id_col

    Returns: same df, with added column 'prev_<id_col>'
    """

    shifted_group = df[group_col].shift(periods=1, fill_value="")
    prev_id_col = "prev_" + id_col
    prev_id = df[id_col].shift(periods=1, fill_value=0)
    prev_id = prev_id.rename(prev_id_col)

    # Rows are sorted by group. Find the rows that have a different group than the previous row
    # These rows should get the 'prev_id_col' set to the one found in 'df_last_ext'
    new_group_idx = (df[group_col] != shifted_group).to_numpy().nonzero()[0]
    # 'shifted_group' is not needed anymore
    del shifted_group

    logger.info("Getting prev_id from df_last_ext for 'new group' rows")
    df_ext_group_list = df_last_ext[group_col].to_list()
    replacement_list = []
    for idx in new_group_idx:
        last_ext_ref = 0
        current_group = df[group_col].iloc[idx]
        if current_group in df_ext_group_list:
            last_ext_ref = df_last_ext[df_last_ext[group_col] == current_group][
                id_col
            ].iloc[0]
        else:
            if df_last_ext.shape[0] > 0:
                logger.warning(
                    f"Group {current_group} does not exist in existing preprocessed data"
                )
        replacement_list.append(last_ext_ref)

    logger.info("Composing update column")
    prev_id_update = pd.Series(
        data=replacement_list,
        index=new_group_idx,
        dtype=df[id_col].dtype,
        name=prev_id_col,
    )
    logger.info("Updating column/series prev_id")
    # DO NOT use ...update, as it checks for NaN and does so by converting to float, resulting in imprecision :-/
    # prev_id.update(prev_id_update)
    prev_id[prev_id_update.index] = prev_id_update

    return pd.concat((df, prev_id), axis="columns", join="outer")


# %%
def generate_partition_id(epoch: pd.Series, partition_period: int) -> pd.Series:
    """Generate epoch based IDs for partitioning"""

    # generate ids
    logger.debug("Generating partition ids...")
    # use epoch based period number to create partitions of 'PERIOD' size
    return (epoch.astype("int64") // partition_period).astype("int64")


# %% [raw]
#


# %%
def get_element_lists_per_type(element_type: dict) -> dict:
    """Convert element type_name pairs to list of elements per type_name

    Argument: dict with "element - type_name" pairs
    Return dict with "type_name - list of elements" pairs
    """
    element_lists_per_type = {}
    type_list = [t for t in set(element_type.values())]
    for t in type_list:
        element_lists_per_type[t] = [e for e, v in element_type.items() if v == t]
    return element_lists_per_type


# %% [raw]
#


# %%
def write_single_type_data(
    df: pd.DataFrame, base_table_info: dict, type_name: str
) -> None:
    """Append or overwrite data to partitioned or normal table, based on presence of optional keys

    Arguments:
    df: DataFrame containing the data to be written
    base_table_info: dict with keys: 'name', 's3_path' and
                     optional keys: 'partition_col', 'overwrite' (mutually exclusive)
    type_name: name of the type (becomes part of table name and S3 path)
    """

    table = base_table_info["name"] + "_" + type_name
    if not df.empty:
        s3_path = base_table_info["s3_path"] + type_name + "/"

        logger.info(f"Writing {type_name} data ({len(df)} records)...")
        if "partition_col" in base_table_info:
            partition_col = base_table_info["partition_col"]

            # Try to speed up writing and reduce memory use by offering data per partition
            for part_id in df[partition_col].unique():
                athena_utils.append_table(
                    df[df[partition_col] == part_id],
                    table=table,
                    s3_folder=s3_path,
                    partition_cols=[partition_col],
                )
        elif "overwrite" in base_table_info and base_table_info["overwrite"]:
            athena_utils.overwrite_table(
                df,
                table=table,
                s3_folder=s3_path,
            )
        else:
            athena_utils.append_table(
                df,
                table=table,
                s3_folder=s3_path,
            )
    else:
        logger.warning(f"Not writing empty table {table}.")


# %% [raw]
#


# %%
def write_preprocessed_data_per_type(
    df: pd.DataFrame,
    split_column: str,
    element_types: dict,
    type_conversion_def: list,
    base_table_info: dict,
    str_val_col: str,
    val_col: str,
) -> None:
    """
    Split, convert and append data to Glue catalog tables, according to the defined data type of the values.

    Arguments:
    df: should contain column <str_val_col> -> converted to <val_col>; then <str_val_col> is dropped.
    split_column: column name in df that contains "element values" which determine the split
    element_types: dict containing "element value: type code" pairs
    type_conversion_def: list of dicts containing "type_code", "conversion_function" and "table_type_name"
    base_table_info: dict with keys: 'name', 's3_path' and optional 'partition_col'

    Remarks:
    - all unique values in df[split_column] are expected to be found as key in element_types
    - all "type codes" (values in element_types) are expected to be found in type_conversion_def[n]["type_code"]
    - type_conversion_def[n]["table_type"] is a string appended to the table name and S3 path
    - rows with an unrecognised value in df[split_column] end up in table_type "undefined"
    """

    logger.info(
        f"Splitting df (shape {df.shape}) into float, int, string and undefined data..."
    )
    # Get the intended types for each element
    element_lists_per_type = get_element_lists_per_type(element_types)

    # Do a check on types in 'element_lists_per_type'
    # first get all conversion types
    conversion_types = [c["type_code"] for c in type_conversion_def]
    # then check each type name in element_lists_per_type against the conversion types
    for e_t in element_lists_per_type.keys():
        if not e_t in conversion_types:
            logger.warning(f"Some elements have unknown type '{e_t}' specified.")

    # Now do the conversion and write resulting tables
    for conv in type_conversion_def:
        logger.info(f"Processing type code: {conv['type_code']} data...")
        if conv["type_code"] in element_lists_per_type:
            df_write = df[
                df[split_column].isin(element_lists_per_type[conv["type_code"]])
            ].copy()
            df_write[val_col] = conv["conversion_function"](df_write[str_val_col])
            df_write = df_write.drop(columns=str_val_col)
            if not df_write.empty:
                # remove lines from df that are now in df_write, to save memory
                df = df[
                    ~df[split_column].isin(element_lists_per_type[conv["type_code"]])
                ].copy()

                write_single_type_data(
                    df_write, base_table_info, conv["table_type_name"]
                )
            else:
                logger.info(f"No data present of short type {conv['type_code']}.")
        else:
            logger.info(
                f"Short type {conv['type_code']} does not exist in 'element - type' types."
            )

    # Write remaining data to "undefined"
    logger.info("Processing undefined data...")
    df_write = df.copy()  # remaining items
    if not df_write.empty:
        # remove lines from df that are now in df_write, to save memory
        del df
        write_single_type_data(df_write, base_table_info, "undefined")
    else:
        logger.info("No data present of 'undefined' type (OK).")
