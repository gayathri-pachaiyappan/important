# %%
"""
Copy full or partial tables from Glue Catalog tables (on S3) to Redshift tables

This glue job script depends on the following project configuration details
- [[DATA_SHARING]] table containing
- ACTIVE - true or false
- TABLE_SELECTOR - containing one of: startswith, endswith, contains, equals, regex
- TABLE_NAME - combines with TABLE_SELECTOR
- INCREMENTAL - true or false, indicating if the source table is partitioned
- for INCREMENTAL is false:
-   MODE: append, overwrite or upsert
- for INCREMENTAL is true:
-   NR_PARTITIONS (int, optional) - number of partitions to copy (last 'n' if sorted ascending; default 57)
-   PARTITION_COLUMN (string, optional) - name of column table is partitioned on (default 'partition_id')
-   LOOKUP_TABLES (list of string, optional) - list of lookup table names needed to create the shared table
-   in case LOOKUP_TABLES is _NOT_specified:
-     COLUMNS - (string or list of string, optional) - list of columns in 'SELECT' (default '*')
-   in case LOOKUP_TABLES is specified:
-     COLUMNS - (list of (string or list of string), mandatory) - list of columns list for each table (may be: "*")
-               (first element is for main table, next for each lookup table, in same order)
-     JOIN_COLUMNS_MAIN - (list of string, mandatory) - list of columns to join each of the lookup tables on
-     JOIN_COLUMNS_LOOKUP - (list of string, mandatory) - list of columns to join on, one for each lookup table
-     JOIN_TYPE - (list of string, optional) - list of join types (INNER, LEFT, RIGHT, FULL, CROSS),
-         one for each lookup table
-     WHERE - (list of string, optional) - the elements will be ANDed together. Note it must reference the tables
          that fields are from, using '"A".' for the main table and '"B".', '"C".' etc. for the lookup tables.
"""

# %%
import re
import time

# %%
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import athena_utils, logger, misc_utils, redshift_utils, s3_utils


# %%
def table_selector(athena_table_name, table_name_to_be_copied, table_selector) -> bool:
    """
    Takes the table selector and applies the right operation to evaluate if the
    table should be copied to RedShift
    """
    if table_selector == "contains":
        return table_name_to_be_copied in athena_table_name
    if table_selector == "startswith":
        return athena_table_name.startswith(f"{table_name_to_be_copied}")
    if table_selector == "endswith":
        return athena_table_name.endswith(f"{table_name_to_be_copied}")
    if table_selector == "regex":
        return bool(re.search(table_name_to_be_copied, athena_table_name))
    if table_selector == "equals":
        return athena_table_name == table_name_to_be_copied
    if table_selector == "asis":  # Legacy
        return athena_table_name == table_name_to_be_copied


# %%
def load_into_redshift(share_table: dict, s3_url: str, delete_files: bool) -> None:
    table = share_table.get("TABLE_NAME")
    overwrite_method = share_table.get("OVERWRITE_METHOD", "drop")
    logger.info(f"Loading table {table} into Redshift from {s3_url}")
    redshift_utils.copy_table_from_files(
        s3_url=s3_url,
        table=table,
        mode="overwrite",
        method=overwrite_method,
        delete_files=delete_files,
    )
    logger.debug(f"DEBUG: Finished loading table ({table}).")


# %%
def get_partition_ids(table: str, part_col: str, nr_partitions: int) -> list:
    # get list of partition ids to be pushed
    logger.info(f"Getting list of partition IDs for table {table}...")
    select = f"""DISTINCT "{part_col}" """
    query = f"""
        ORDER BY "{part_col}" DESC
        LIMIT {nr_partitions}
        """
    df_partition_ids = athena_utils.get_table_free_query(
        table=table, select=select, query=query
    )
    return df_partition_ids[part_col].to_list()


# %%
def copy_partitioned_table_single(table: str, share_table: dict) -> None:
    """
    Copy last N partitions, using S3 for intermediate storage from one single table (no lookup)

    Arguments:
    - table: name of the partitioned table to copy from
      (it MUST be partitioned using a numeric column with ordered values)
    - share_table: dictionary containing at least the keys:
        * "NR_PARTITIONS" (int, optional) - number of partitions to copy (last 'n' if sorted ascending; default 57)
        * "PARTITION_COLUMN" (string, optional) - name of column table is partitioned on (default 'partition_id')
        * "COLUMNS" (string or list of string, optional) - list of columns in 'SELECT' (default '*')

    :return: None
    """

    defaults = {
        "NR_PARTITIONS": 57,  # default just over one year in case of partitions per week
        "PARTITION_COLUMN": "partition_id",
        "COLUMNS": "*",
    }
    settings = misc_utils.set_simple_defaults(share_table, defaults)

    partition_ids = get_partition_ids(
        table, settings["PARTITION_COLUMN"], settings["NR_PARTITIONS"]
    )
    # Get the lowest number, so we can select everything greater/equal to it
    min_partition = sorted(partition_ids)[0]

    # Copy relevant data to S3, ready for Redshift
    select = (
        f""" "{'","'.join(settings["COLUMNS"])}" """
        if settings["COLUMNS"] != "*"
        else "*"
    )
    query = f"""
        WHERE "{settings["PARTITION_COLUMN"]}" >= {min_partition}
        """
    s3_folder = misc_utils.config["S3_DATA_PREFIX"] + "tmp/datasharing_" + table
    logger.info(f"Unloading table {table} to {s3_folder}...")
    athena_utils.unload_table_free_query_to_s3(
        table=table,
        select=select,
        query=query,
        s3_folder=s3_folder,
    )

    load_into_redshift(
        share_table, s3_utils.path_to_url([s3_folder])[0], delete_files=True
    )


# %%
def copy_partitioned_table_lookup(tables: list, share_table: dict) -> None:
    """
    Copy last N partitions, using S3 for intermediate storage from main table joined with lookup tables

    Arguments:
    - tables: names of the tables to copy from. First must be partitioned, others are joined
      (it MUST be partitioned using a numeric column with ordered values)
    - share_table: dictionary containing at least the keys:
        * "NR_PARTITIONS" (int, optional) - number of partitions to copy (last 'n' if sorted ascending; default 57)
        * "PARTITION_COLUMN" (string, optional) - name of column table is partitioned on (default 'partition_id')
        * "JOIN_COLUMNS_MAIN" (list of string, mandatory) - list of columns to join each of the other tables on
        * "JOIN_COLUMNS_LOOKUP" (list of string, mandatory) - list of columns to join on for 2nd and further tables
        * "JOIN_TYPE" - (list of string, optional) - list of join types (INNER, LEFT, RIGHT, FULL, CROSS),
          one for each lookup table
        * "COLUMNS" (list of (string or list of string), mandatory) - list of columns list for each table (in same order)
          The list of columns might be expressed with a single string containing "*".
        * "WHERE" (list of string, optional) - the elements will be ANDed together. Note it must reference the tables
          that fields are from using '"A".' for the main table and '"B".', '"C".' etc. for the lookup tables.

    :return: None
    """

    defaults = {
        "NR_PARTITIONS": 57,  # default just over one year in case of partitions per week
        "PARTITION_COLUMN": "partition_id",
    }
    settings = misc_utils.set_simple_defaults(share_table, defaults)
    # first (main) table is destination table and name of partitioned table
    table = tables[0]

    partition_ids = get_partition_ids(
        table, settings["PARTITION_COLUMN"], settings["NR_PARTITIONS"]
    )
    # Get the lowest number, so we can select everything greater/equal to it
    min_partition = sorted(partition_ids)[0]

    # Copy relevant data to S3, ready for Redshift
    select = "SELECT "
    database = misc_utils.config["DATABASES"]["default"]["DATABASE"]
    from_join = ""
    where = ""
    for i in range(len(tables)):
        table_char = chr(ord("A") + i)

        if i > 0:
            select += ","

        # Quote column names, but not "*" for all columns...
        if settings["COLUMNS"][i] == "*":
            select += f'"{table_char}".*'
        else:
            select += (
                f'"{table_char}"."'
                + f'","{table_char}"."'.join(settings["COLUMNS"][i])
                + '"'
            )

        # "FROM " for first table, "JOIN " for following tables
        if i > 0:
            join_type = (
                settings["JOIN_TYPE"][i - 1] if "JOIN_TYPE" in settings else "INNER"
            )
            from_join += (
                f"""{join_type} JOIN "{database}"."{tables[i]}" AS "{table_char}" """
                + f"""ON "A"."{settings["JOIN_COLUMNS_MAIN"][i-1]}" = """
                + f'''"{table_char}"."{settings["JOIN_COLUMNS_LOOKUP"][i-1]}"'''
            )
        else:
            from_join = f"""FROM "{database}"."{tables[i]}" AS "A" """

    where = ""
    if "WHERE" in settings:
        where = " AND ".join(settings["WHERE"])
        where = " AND " + where if len(where) else ""
    where = f"""WHERE "{settings["PARTITION_COLUMN"]}" >= {min_partition}""" + where

    # compile the full SQL query
    sql = f"""{select} {from_join} {where}"""
    logger.info(f"""copy_partitioned_table_lookup() - SQL:\n{sql}""")

    s3_folder = misc_utils.config["S3_DATA_PREFIX"] + "tmp/datasharing_" + table
    logger.info(f"Unloading table {table} with lookups from {tables} to {s3_folder}...")

    athena_utils.unload_query_to_s3(
        sql_query=sql,
        s3_folder=s3_folder,
    )

    load_into_redshift(
        share_table, s3_utils.path_to_url([s3_folder])[0], delete_files=True
    )


# %%
def copy_partitioned_table(table: str, share_table: dict) -> None:
    """
    Copy last N partitions, using S3 for intermediate storage from a table (with or without lookup)

    Arguments:
    - table: name of the partitioned table to copy from
      (it MUST be partitioned using a numeric column with ordered values)
    - share_table: dictionary containing at least the keys:
        * "NR_PARTITIONS" (int, optional) - number of partitions to copy (last 'n' if sorted ascending; default 57)
        * "PARTITION_COLUMN" (string, optional) - name of column table is partitioned on (default 'partition_id')
        * "COLUMNS" (string or list of string, optional) - list of columns in 'SELECT' (default '*')
        * _NOT_ containing "LOOKUP_TABLES"
    or
    - share_table: dictionary containing at least the keys:
        * "LOOKUP_TABLES" (list of string, mandatory) - list of lookup table names needed to create the shared table
        * "NR_PARTITIONS" (int, optional) - number of partitions to copy (last 'n' if sorted ascending; default 57)
        * "PARTITION_COLUMN" (string, optional) - name of column table is partitioned on (default 'partition_id')
        * "COLUMNS" (list of (string or list of string), mandatory) - list of columns list for each table (in same order)
          The list of columns might be expressed with a single string containing "*".
        * "JOIN_COLUMNS_MAIN" (list of string, mandatory) - list of columns to join each of the other tables on
        * "JOIN_COLUMNS_LOOKUP" (list of string, mandatory) - list of columns to join on for 2nd and further tables
        * "WHERE" (list of string, optional) - the elements will be ANDed together. Note it must reference the tables
          that fields are from, using '"A".' for the main table and '"B".', '"C".' etc. for the lookup tables.

    :return: None
    """

    if "LOOKUP_TABLES" in share_table:
        copy_partitioned_table_lookup(
            [table] + share_table["LOOKUP_TABLES"], share_table
        )
    else:
        copy_partitioned_table_single(table, share_table)


# %%
def copy_full_table(table: str, share_table: dict) -> None:
    """
    Copy one full table from Athena to Redshift
    Note: table must be small, so it completely fits in memory
    :return: None
    """

    logger.debug(f"DEBUG: Getting S3 path for Athena table ({table}).")
    s3_url = athena_utils.get_table_s3_location(table)
    load_into_redshift(share_table, s3_url, delete_files=False)


# %%
def create_availability_table(copied_tables: list, list_type: str) -> None:
    """
    Create table containing the names of all shared tables
    :returns: None
    """

    df_available_tables = pd.DataFrame(
        {"table_name": list(copied_tables), "last_updated": time.time()}
    )
    table_name = f'{misc_utils.config["LINE"]}_available_tables_{list_type}'

    if not df_available_tables.empty:
        logger.info(f"create_availability_table {table_name} ({copied_tables}).")

        redshift_utils.copy_table(
            df=df_available_tables,
            table=table_name,
            mode="upsert",
            pk_columns=["table_name"],
        )
    else:
        logger.info(f"Not writing empty table {table_name}.")
