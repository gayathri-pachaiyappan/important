# %%
"""
This notebook provides generic functions to handle compressed DCS / PCS tag data
The compression is 'Sloping Boxcar Compression' and is only applicable to
floating point data. Integer and string type data keep their value until the
timestamp of a new value.
"""

# %% [markdown]
# This module contains the following external functions.
#
# Tag info
# - def retrieve_all_tagnames_in_db() -> dict:
# - def convert_tag_name(tag_name: str) -> str:
# - def get_tag_type(tag: str) -> str:
# - def get_tag_list(include_undefined: bool = False) -> list:
#
# Cache related
# - def clean_cache() -> None:
# - def add_to_cache(tags: list, time_range: tuple) -> None:
# - def clean_fill_cache(tags: list, time_range: tuple) -> None:
# - def get_data_from_cache(
# - def get_cache_time_range() -> tuple:
#
# Batch timing
# - def get_all_batch_id_time_ranges(
#
# Get tag data in data frame (incl. calculated virtual tags)
# - def get_const_data(tag: str, time_range: tuple) -> pd.DataFrame:
# - def get_pseudo_data(tag: str, time_range: tuple) -> pd.DataFrame:
# - def get_tag_data(tag: str, time_range: tuple) -> pd.DataFrame:
# - def get_multi_tag_data(tags: list, time_range: tuple) -> pd.DataFrame:
#
# Get tag data in (list of) ndarray
# - def get_tag_ndarray(tag: str, time_range: tuple) -> np.ndarray:
# - def get_tag_ndarray_list(tags: list, time_range: tuple) -> list:
# - def select_data(df: pd.DataFrame, time_range: tuple) -> pd.DataFrame:
# - def select_ndarray(tag_data: np.ndarray, time_range: tuple) -> np.ndarray:
# - def select_ndarray_list(tag_data_list: list, time_range: tuple) -> list:
# - def remove_nan(arr: np.ndarray) -> np.ndarray:
# - def remove_nan_list(tag_data_list: list) -> list:
# - def align_epoch_for_ndarray_list(tag_data_list: list) -> list:

# %% [markdown]
# NOTE on tags!!!
# To identify a tag, there are three 'layers' to identify a specific tag:
# - 1) externally used name(*): can contain upper case and special characters
# - 2) normalised name: lower case, only a-z, 0-9 and remaining converted to '_'
# - 3) UID: looked up from 2) using file global varable uid_cache
# (*) externally to this module and preprocessing
#
# Preprocessing used to store the normalised string value as tag UID (so layer 3
# was identical to layer 2).
# Later, a 64 bit integer value was introduced as tag UID, as multiple names
# for the same tag came into existance from the source (even after normailsation).
# The name to 64 bit conversion is done using a lookup table. For speed this is
# a parquet file in S3 as well as a table in Athena (only used for data sharing
# which is done in SQL).
# For backward compatibility, during the transition, the code should be able to
# work both with string and integer based tag UIDs.
# Conceptual both string based and integer based UIDs are UIDs.
#
# In the code something like "..._name" refers to layer 1 or 2 names, while
# "..._uid" refers to the layer 3 UID.
# In case one specific form of UID is intended, that is clearly expressed in the
# variable name (like "int_uid_flag" that is True in case of integer UIDs)
#
# For backward compatibility, named arguments still have the same name, mostly
# "tag: str" or "tags: list". This refers to layer 1 or layer 2 tag names.


# %%
import re
import time
import warnings
from functools import reduce

# %%
# Data processing
import numpy as np
import pandas as pd

# %%
# Load main modules of our team library
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, the main config
from abt_epd_gpmo_aa import athena_utils, logger, preprocess_pcs_utils

# %%
logger.info("Initialising tag_utils...")
PCS = "pcs"
PCS_TABLE = misc_utils.config["PREPROCESSED_TABLE_PREFIX"] + PCS
# TAG_LOOKUP_FILE = misc_utils.config["S3_LOOKUP_PREFIX"] + "_" + PCS + "/" + PCS + "_tags.parquet"
TAG_LOOKUP_FILE = misc_utils.config["S3_LOOKUP_PREFIX"] + PCS + "_tags.parquet"


# %%
"""
Functions regarding tag names and types
"""

# %%
# Precompile regex for repeated use in the function 'convert_tag_name'
# The regex matches on all but the wanted characters
re_wrong_tag_name_char = re.compile(r"[^a-z0-9_]")


# %%
def convert_tag_name(tag_name: str) -> str:
    """
    Convert tag names to lower case and replace chars not in [0-9a-z_] by '_'
    """
    return re_wrong_tag_name_char.sub("_", tag_name.lower())


# %%
def retrieve_all_tags_in_db() -> dict:
    """Retrieve all tags (UIDs) available in all PCS preprocessed data tables

    Returns:
    dict containing keys with the table suffix (float, int, etc.) and the values
    are for each key a list of UIDs.
    Note: the UID can be int (new) or string (legacy)"""

    logger.info("Getting list of all PCS tags from database.")
    all_pcs_tables = [t for t in athena_utils.get_tables() if t.startswith(PCS_TABLE)]
    logger.info(f"Scanning {len(all_pcs_tables)} tables for tags.\n{all_pcs_tables}")
    all_tags = {
        t.replace(PCS_TABLE + "_", ""): athena_utils.get_table_free_query(
            t, select="""DISTINCT "tag" """, query=""
        )["tag"].to_list()
        for t in all_pcs_tables
    }
    logger.info(f"""Found tag types: {list(all_tags.keys())}""")
    return all_tags


# %%
def retrieve_all_tagnames_in_db() -> dict:
    """Retrieve all tagnames (or UIDs) available in all PCS preprocessed data tables"""

    logger.warning(
        "LEGACY: use retrieve_all_tags_in_db instead of retrieve_all_tagnames_in_db"
    )
    return retrieve_all_tags_in_db()


# %%
"""
Cache management functions
"""

# %%
# file/module global variables all_db_* are
# modified in:
# - refresh_db_info()
# and used in:
# - get_tag_type
# - get_tag_list
# NOTE: DO NOT USE all_db_tags directly. Always use the above mentioned functions!
all_db_tags = {}
all_db_min_epoch = 0
all_db_max_epoch = 0


# %%
def refresh_db_info() -> None:
    """Clean file/module global variable all_db_*"""

    global all_db_tags
    global all_db_min_epoch
    global all_db_max_epoch
    all_db_tags = retrieve_all_tags_in_db()
    all_db_min_epoch = 0
    all_db_max_epoch = 0


# %%
# Now set the global variables all_db_* to their initial values
refresh_db_info()  # Set initial values

# %%
# file/module global variable df_cache is
# modified in:
# - add_to_cache
# - clean_cache
# and used in:
# - get_data_from_cache
# - get_cache_time_range
# NOTE: DO NOT USE df_cache directly. Always use the above mentioned functions!
df_cache = pd.DataFrame(
    columns=["tag", "value", "next_value", "start_time", "next_time"]
)
# file/module global variable uid_cache is
# modified in:
# - add_tag_uids_to_cache
# - clean_cache
# and used in:
# - get_data_from_cache
# NOTE: DO NOT USE directly. Always use the above mentioned functions!
uid_cache = {}

# %%
logger.info("Ready init tag_utils.")


# %%
def clean_cache() -> None:
    """Clean file/module global variable df_cache"""

    global df_cache
    global uid_cache
    df_cache = pd.DataFrame(
        columns=["tag", "value", "next_value", "start_time", "next_time"]
    )
    uid_cache = {}


# %%
def add_tag_uids_to_cache(tag_names: list) -> None:
    """Add UID lookup to dict for the selected tag names in the list"""

    global uid_cache

    df_tmp = preprocess_pcs_utils.read_tags_lookup_table()
    if df_tmp is not None:
        logger.debug(
            f"""DEBUG: add_tag_uids_to_cache() - columns in df_tmp: {df_tmp.columns}"""
        )
        for t in tag_names:
            uid_cache[t] = int(df_tmp[df_tmp["tag"] == t]["tag_id"])
    else:
        for t in tag_names:
            uid_cache[t] = t


# %%
def get_tag_type_by_uid(uid: int) -> str:
    """Returns postfix (without '_') for table the tag is found in.

    Arguments:
    - uid integer in the new situation, but can also be a string during the transition period.

    Description:
    The 'type' can be more than the datatype only. For example, generated
    string type tags are 'pseudostring' tags and are found in the table with
    postfix '_pseudostring'. The convention is to end the tag type with the
    name of the data type (string, int, float).
    """

    found_list = [k for k, v in all_db_tags.items() if uid in v]
    if len(found_list):
        postfix = found_list[0]
    else:
        logger.warning(
            f"""WARNING: get_tag_type_by_uid() - uid not in all_db_tags ({uid})"""
        )
        postfix = "undefined"
    return postfix


# %%
def get_tag_type(tag: str) -> str:
    """Returns postfix (without '_') for table the tag is found in.

    Description:
    The 'type' can be more than the datatype only. For example, generated
    string type tags are 'pseudostring' tags and are found in the table with
    postfix '_pseudostring'. The convention is to end the tag type with the
    name of the data type (string, int, float).
    """

    tag_name = convert_tag_name(tag)
    if tag_name.startswith("const_f_"):
        return "float"
    if tag_name.startswith("const_i_"):
        return "int"
    if tag_name.startswith("const_s_"):
        return "string"
    if tag_name.startswith("pseudo_batch_"):
        return "string"
    if tag_name not in list(uid_cache.keys()):
        logger.debug(
            f"""DEBUG: get_tag_type() - tag: {tag} -> {tag_name} not yet in uid_cache; adding..."""
        )
        add_tag_uids_to_cache([tag_name])
    tag_uid = uid_cache[tag_name]
    return get_tag_type_by_uid(tag_uid)


# %%
def get_tag_list(include_undefined: bool = False) -> list:
    """Get list of tag names that are in the database or lookup table (if used)"""
    l = []
    logger.debug(
        "DEBUG: get_tag_list() - type of all_db_tags values: "
        + f"""{list(all_db_tags.values())[0][0]} {type(list(all_db_tags.values())[0][0])}"""
    )
    if isinstance(list(all_db_tags.values())[0][0], str):
        for k, v in all_db_tags.items():
            if include_undefined or (k != "undefined"):
                l.extend(v)
    else:
        df = preprocess_pcs_utils.read_tags_lookup_table()
        l = df["tag"].to_list()
    return l


# %%
def get_maxmin_timestamp(most_recent: bool, data_type: str = "float") -> float:

    global all_db_min_epoch
    global all_db_max_epoch

    if most_recent and (all_db_max_epoch > 0):
        return all_db_max_epoch
    elif (not most_recent) and (all_db_min_epoch > 0):
        return all_db_min_epoch
    else:
        function = "MIN"
        if most_recent:
            function = "MAX"
        table = f"{PCS_TABLE}_{data_type}"
        query = f"""partition_id = (SELECT {function}(partition_id) AS m FROM "{misc_utils.config['DATABASE']}"."{table}")"""
        df = athena_utils.get_table_query(
            table, columns=[f"""{function}("epoch") AS "m_epoch" """], where=query
        )
        if most_recent:
            all_db_max_epoch = df.iloc[0, 0]
            logger.info(
                f"Preprocessed PCS data is available up to epoch {all_db_max_epoch}"
            )
        else:
            all_db_min_epoch = df.iloc[0, 0]
            logger.info(
                f"Preprocessed PCS data is available from epoch {all_db_min_epoch}"
            )
        return df.iloc[0, 0]


# %%
def add_to_cache(tags: list, time_range: tuple) -> None:
    """Add to file/module global variable df_cache: multiple tags from database for a time range

    Arguments:
    - tags : list with names of the tags of which data is requested
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - nothing (cache is prepared for use)
    Description:
      This function gets data from the database (slow operation), so other functions can use
      the cache to get specific information (fast operation)
    """

    global df_cache
    global uid_cache
    global all_db_max_epoch

    # convert tag names to correct format
    tag_names = [
        convert_tag_name(t)
        for t in tags
        if not (t.startswith("pseudo_") or t.startswith("const_"))
    ]
    add_tag_uids_to_cache(tag_names)
    tag_uids = [uid_cache[t] for t in tag_names]
    logger.debug(
        f"""DEBUG: add_to_cache() - tags, tag_names, tag_uids:\n{tags}\n{tag_names}\n{tag_uids}"""
    )
    int_uid_flag = tag_uids[0] != tag_names[0]
    logger.debug(f"""DEBUG: add_to_cache() - int_uid_flag: {int_uid_flag}""")

    # Make sure we know max epoch in the database
    if all_db_max_epoch == 0:
        get_maxmin_timestamp(most_recent=True, data_type="float")

    while len(tag_uids):
        tag_type = get_tag_type_by_uid(tag_uids[0])
        logger.info(f"""Adding to cache data type: {tag_type}""")
        postfix = "_" + tag_type

        same_type_tag_uids = [t for t in tag_uids if get_tag_type_by_uid(t) == tag_type]
        # convert list to format the SQL IN operator expects
        if int_uid_flag:
            tag_set_sql = ",".join([str(t) for t in same_type_tag_uids])
        else:
            tag_set_sql = "'" + "','".join(same_type_tag_uids) + "'"

        # Limit the dataset to seach through, to one partition before what is likely needed
        df_data = athena_utils.get_pcs_table_free_query(
            PCS_TABLE + postfix,
            select=r"""
             B."tag" AS "tag",
             B."value" AS "value",
             N."value" AS "next_value",
             B."epoch" AS "start_time",
             N."epoch" AS "next_time"
            """,
            query=f"""
            WHERE B."tag" IN ({tag_set_sql})
                AND B."row_id" <> B."prev_row_id"
                AND N."row_id" <> N."prev_row_id"
                AND N."epoch" > B."epoch"
                AND B."epoch" < {time_range[1]}
                AND N."epoch" > {time_range[0]}
                AND B."partition_id" >= {time_range[0] // misc_utils.config['PCS_PARTITION_PERIOD'] -1.1}
                AND N."partition_id" >= {time_range[0] // misc_utils.config['PCS_PARTITION_PERIOD'] -0.1}
            """,
        )
        logger.debug(
            f"""DEBUG: add_to_cache - adding (rows, columns): ({df_data.shape})"""
        )
        df_cache = pd.concat(
            (df_cache, df_data), axis=0, join="outer", ignore_index=True
        )
        # remove tags we've loaded and keep the remaining ones for the next loop
        tag_uids = [t for t in tag_uids if get_tag_type_by_uid(t) != tag_type]

    if time_range[1] >= all_db_max_epoch - 1000.0:
        logger.warning(
            "add_to_cache - add the last 'next value' as normal value for each tag; fake next time, value NA."
        )
        extra_df_list = []
        unique_tags = df_cache["tag"].unique()
        logger.info(
            f"Doing this for {len(unique_tags)}. On large cache may take a few seconds per tag."
        )
        for tag in unique_tags:
            tag_index = df_cache["tag"] == tag
            max_start_time = df_cache["start_time"][tag_index].max()
            tag_index = df_cache.index[
                tag_index & (df_cache["start_time"] == max_start_time)
            ]
            logger.debug(
                f"add_to_cache - Tag: {tag}, max_start_time_index: {tag_index} ({tag_index[0]})"
            )
            tag_index = tag_index[0:1]
            df_extra = df_cache.loc[tag_index, :]
            # Don't add additional data point if already done
            if df_extra["next_time"].iloc[0] < time_range[1]:
                df_extra["start_time"] = df_extra["next_time"]
                df_extra["value"] = df_extra["next_value"]
                df_extra["next_time"] = time_range[1] + 10
                df_extra["next_value"] = pd.NA
                extra_df_list.append(df_extra.copy())
                logger.debug(f"add_to_cache - Adding to df_cache:\n{df_extra}")

        logger.info(f"add_to_cache - Adding {len(extra_df_list)} extra datapoints.")
        # Check for empty extra_df_list...
        # The '-1000.0' might result in this situation in case all data is updated very frequently
        if len(extra_df_list) > 0:
            df_all_extra = pd.concat(
                extra_df_list,
                axis=0,
                join="outer",
                ignore_index=True,
            )
            df_cache = pd.concat(
                (df_cache, df_all_extra), axis=0, join="outer", ignore_index=True
            )
    logger.info("All data loaded in cache.")
    logger.debug(
        f"DEBUG: add_to_cache - cache size (rows, columns): ({df_cache.shape})"
    )


# %%
def clean_fill_cache(tags: list, time_range: tuple) -> None:
    """Clean file/module global variable df_cache and fill it with multiple tag data from database for a time range

    Arguments:
    - tags : list with names of the tags of which data is requested
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - nothing (cache is prepared for use)
    Description:
      This function first cleans the cache to free memory that is not needed and gets data from
      the database (slow operation), so other functions can use the cache to get specific
      information (fast operation)
    """

    clean_cache()
    add_to_cache(tags, time_range)


# %%
"""
Functions to retrieve data
"""


# %%
def get_data_from_cache(
    tags: list, start_time: float = 0, end_time: float = np.finfo(float).max
) -> pd.DataFrame:
    """Get multiple tag data from cache for a time range (i.e. from first to last batch to process).

    Arguments:
    - tags : list with names of the tags of which data is requested
    - start_time : epoch (in s) of start of time range to get from cache
    - end_time : epoch (in s) of end of time range to get from cache
    Returns:
    - pd.DataFrame : dataframe with the 'raw' tag data (epoch & value of datapoint and next datapoint)
    Description:
      This function gets the time/value pairs for all pairs that have
      - the start time before the end of the requested time range
      - the end after the beginning of time range.
      This ensures we also have the data pairs that have their start before the beginning or
      that have the next_time after the end of the requested time range.
      Note: this function uses the file/module global variable df_cache to get the data from.
    """

    # Define selection of the cache to return
    tag_names = [convert_tag_name(t) for t in tags]
    tag_uids = [uid_cache[t] for t in tag_names]
    selector = df_cache["tag"].isin(tag_uids)
    # Refine selection using the logical AND assignment operator
    selector &= df_cache["next_time"] > start_time
    selector &= df_cache["start_time"] < end_time
    # No problem if we return a view instead of copy as no assignments should be made to the result
    return df_cache[selector]


# %%
def get_cache_time_range() -> tuple:
    """Get time range of current (actual) tag data in the cache."""

    return (
        df_cache["next_time"].min(skipna=True),
        df_cache["start_time"].max(skipna=True),
    )


# %%
def get_cache_size() -> int:
    """Get nr of items in the cache."""

    return df_cache.shape[0]


# %%
def get_all_batch_id_time_ranges(
    tag: str, start_epoch: float, value_re: str
) -> pd.DataFrame:
    """Get start and end time of all unique (batch) IDs.

    Arguments:
    - tag : the batch-id tag to get all batch times for
    - start_epoch : start time to look for batch_ids, i.e. the start time of a batch has to
      be after this time. This is different from other uses of start time, where the requested
      start time has to be before the 'next_time'
    - value_re : regular expression for an additional filter on the values of the tag and to
      capture the batch-id
    Returns:
    - pd.DataFrame : containing tag, value, batch_id start_time and end_time (both in epoch)
    Description:
      Get the timestamps of the earliest occurrence and the latest 'next_epoch'
      of string type tags with the same batch_id. It returns these for each unique value.
    """

    # get all data for the batch-id tag
    df_batches = get_tag_data(tag, time_range=(start_epoch, time.time()))
    logger.debug(
        f"get_all_batch_id_time_ranges - initial df_batches ({start_epoch}, {time.time()}):\n{df_batches}"
    )
    # Add tag column that is stripped off by get_tag_data
    df_batches = df_batches.assign(tag=convert_tag_name(tag))
    # Fill selector with all True and correct size
    selector = df_batches["next_time"] > start_epoch
    # As value_re contains capture group(s) for the batch ID, function 'contains' will give a UserWarning...
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", "This pattern has match groups")
        # Only select the values matching the regular expression
        selector &= df_batches["value"].str.contains(value_re, na=False)
    df_batches = df_batches[selector]

    # Find batch_id
    df_batches = df_batches.assign(
        batch_id=df_batches["value"].apply(
            lambda x: "_".join(re.search(value_re, x).groups())
        )
    )
    # Find start and end time for each batch_id
    df_batches = df_batches.groupby(by=["tag", "batch_id"]).agg(
        {"start_time": [np.min], "next_time": [np.max]}
    )
    # Get index and column names right again
    df_batches = df_batches.reset_index(drop=False)
    # Rename new columns added by .groupby().agg()
    # Use "" as join string instead of "_", as columns tag and value will end up like 'tag'+'_'+'',
    # so with trailing '_'
    df_batches.columns = ["".join(col) for col in df_batches.columns]
    df_batches.rename(
        columns={"start_timeamin": "start_time", "next_timeamax": "end_time"},
        inplace=True,
    )
    if df_batches.shape[0] == 0:
        logger.warning(
            f"WARNING: get_all_batch_id_time_ranges - df_batches is empty: {df_batches.shape}, {df_batches.columns}"
        )
    else:
        df_batches = df_batches.sort_values(by=["tag", "start_time"], ignore_index=True)

    # Only select batches _starting_ after start_epoch (the previous commands retrieved all
    # data _ending_ after start_epoch)
    selector = df_batches["start_time"] > start_epoch
    df_batches = df_batches[selector].reset_index(drop=True)

    return df_batches

    # Original equivalent in SQL
    # df_batches = athena_utils.get_pcs_table_free_query(
    #     PCS_TABLE + "_string",
    #     select=r"""
    #     B."tag" AS "tag",
    #      B."value" AS "value",
    #      min(B."epoch") AS "start_time",
    #      max(N."epoch") AS "end_time"
    #     """,
    #     query=f"""
    #     WHERE regexp_like(B."tag", '{tag_re}')
    #         AND regexp_like(B."value", '{value_re}')
    #         AND B."epoch" >= {start_epoch}
    #     GROUP BY B."tag", B."value"
    #     """,
    # ).sort_values(
    #     by=["tag", "start_time"], ignore_index=True
    # )  # ORDER BY in SQL is not preserved
    # return df_batches.assign(
    #     batch_id=df_batches["value"].apply(
    #         lambda x: "_".join(re.search(value_re, x).groups())
    #     )
    # )


# %%
def get_const_data(tag: str, time_range: tuple) -> pd.DataFrame:
    """Get const data, based on the name of the tag for a time range.

    Arguments:
    - tag : name starting with 'const_' followed by the valuetype followed by the value (const_f_1.5)
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - pd.DataFrame : dataframe with the constant data in the same format as get_tag_data returns
    Description:
      This provides a constant value for the requested time range in the same format as get_tag_data.
      It is intended to be used with fake tag names in place of normal tags, which are recognised
      by the get_tag_data function. The value type can be 'f', 'i' or 's'
    """

    # Do some checks first
    if tag[:6].lower() != "const_":
        raise ValueError(f"Non-const tag ({tag}) used in get_const_data()")
    valuetype = tag[6].lower()
    allowed_values = ["s", "f", "i"]
    if valuetype not in allowed_values:
        raise ValueError(
            f"invalid type Const tag ({tag}) used in get_const_data() is not in {allowed_values}."
        )

    # if the value is incorrectly formatted for the conversion, it will raise an error automatically
    value = tag[8:]
    if valuetype == "f":
        value = float(value)
    if valuetype == "i":
        value = int(value)
    # otherwise, it is "s" and the value is already a string, so nothing to do.

    # This function is normally called from the get_tag_data function, so same return type
    # although it is a single row in this case.
    return pd.DataFrame(
        {
            "value": [value],
            "next_value": [value],
            "start_time": [time_range[0]],
            "next_time": [time_range[1]],
        }
    )


# %%
def get_pseudo_data(tag: str, time_range: tuple) -> pd.DataFrame:
    """Get pseudo data, based on the name of the tag for a time range.

    Arguments:
    - tag : name starting with
            'pseudo_const_' followed by the valuetype followed by the value (const_f_1.5)
            'pseudo_timeid_'
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - pd.DataFrame : dataframe with time based data in the same format as get_tag_data returns
    Description:
      This provides time based values for the requested time range in the same format as get_tag_data.
      It is intended to be used with fake tag names in place of normal tags, which are recognised
      by the get_tag_data function. The value type is 'string'
    """

    # Do some checks first
    if tag[7:6].lower() == "const_":
        return get_const_data(tag, time_range)

    # "pseudo_batch_<period in s>_<offset to epoch>_<prefix before period number>"
    re_pseudo_batch_id = re.compile(
        r"^pseudo_batch_(?P<period>[0-9]+)_(?P<offset>(\+|-)?[0-9]+)_(?P<prefix>.*)$"
    )

    m = re_pseudo_batch_id.match(tag)
    if not m:
        raise ValueError(
            f"invalid Pseudo tag ({tag}) did not match regular expression {re_pseudo_batch_id}."
        )

    period = int(m.group("period"))
    offset = int(m.group("offset"))
    value_prefix = m.group("prefix")

    if (int(time_range[0] + 0.001) - offset) % period == 0:
        start = int(time_range[0] + 0.001)
    else:
        start = (
            ((int(time_range[0] + 0.001) - offset) // period) + 1
        ) * period + offset

    df = pd.DataFrame(
        {
            "start_time": range(start, int(time_range[1] + 0.001) + 1, period),
            "next_time": range(
                start + period, int(time_range[1] + 0.001) + 1 + period, period
            ),
        }
    )
    df = df.assign(
        value=value_prefix + (df.start_time // period).astype(str),
        next_value=value_prefix + (df.next_time // period).astype(str),
        start_time=df.start_time.astype(float),
        next_time=df.next_time.astype(float),
    )

    # This function is normally called from the get_tag_data function, so same return type
    return df


# %%
def get_tag_data(tag: str, time_range: tuple) -> pd.DataFrame:
    """Get tag data from database for a time range (i.e. from first to last batch to process).

    Arguments:
    - tag : name of the tag of which data is requested
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - pd.DataFrame : dataframe with the 'raw' tag data (epoch and value of datapoint and next datapoint)
    Description:
      This function gets the time/value pairs for all pairs that have
      - the start time before the end of the requested time range
      - the end after the beginning of time range.
      This ensures we also have the data pairs that have their start before the beginning or
      that have the next_time after the end of the requested time range.
    """

    time_range_cache = get_cache_time_range()
    logger.debug(
        f"DEBUG: get_tag_data: time_range: {time_range}\ntime_range_cache: {time_range_cache}"
    )
    t_r = (
        max(time_range_cache[0], time_range[0]),
        min(time_range_cache[1], time_range[1]),
    )
    logger.debug(
        f"DEBUG: get_tag_data: time_range: {time_range}\ntime_range_cache: {time_range_cache}"
    )
    tag_name = convert_tag_name(tag)
    if tag_name.startswith("pseudo_"):
        return get_pseudo_data(tag, t_r)
    if tag_name.startswith("const_"):
        return get_const_data(tag, t_r)

    df_data = get_data_from_cache([tag], start_time=t_r[0], end_time=t_r[1])
    df_data = df_data.drop(columns=["tag"])
    df_data = df_data.sort_values(by=["start_time"], ignore_index=True)
    return df_data


# %%
def get_multi_tag_data(tags: list, time_range: tuple) -> pd.DataFrame:
    """Get multiple tag data from database for a time range (i.e. from first to last batch to process).

    Arguments:
    - tags : list with names of the tags of which data is requested
    - time_range : tuple with epoch (in s) of start and end time
    Returns:
    - pd.DataFrame : dataframe with the 'raw' tag data (epoch and value of datapoint and next datapoint)
    Description:
      This function gets the time/value pairs similar to get_tag_data() for multiple tag names at once.
    """

    # convert tag names to correct format
    tag_names = [convert_tag_name(t) for t in tags]

    df_data = pd.DataFrame(
        columns=["tag", "value", "next_value", "start_time", "next_time"]
    )
    for t in tag_names:
        df_data = df_data.append(get_tag_data(t, time_range).assign(tag=t))

    df_data = df_data.sort_values(by=["start_time"], ignore_index=True)
    return df_data


# %%
def get_tag_ndarray(tag: str, time_range: tuple) -> np.ndarray:
    """Get tag data from database for a time range (i.e. from first to last batch to process)."""

    df = get_tag_data(tag, time_range)
    # create arrays including the "next" (or "end") time/value of the last datapoint
    if df.shape[0] == 0:
        logger.warn(
            f"WARNING: get_tag_ndarray returns NaN values for tag {tag}, time range {time_range}"
        )
        return np.array((time_range, (np.nan, np.nan)))
    epochs = np.append(df.start_time, df.next_time.iloc[-1])
    values = pd.to_numeric(
        pd.Series(np.append(df["value"], df["next_value"].iloc[-1])), errors="coerce"
    ).astype("float64", errors="raise")
    # Special processing for integers
    if get_tag_type(tag) == "int":
        # Add extra values to prevent interpolation
        extra_epochs = epochs[1:] - 0.1
        extra_values = values[:-1]
        # Now append, get sort index of epoch, then re-order epochs and values
        epochs = np.append(epochs, extra_epochs)
        values = np.append(values, extra_values)
        inds = np.argsort(epochs)
        epochs = epochs[inds].copy()
        values = values[inds].copy()
        # Also convert encoded NaN (using largest negative as NaN only exists in float)
        if (df == np.iinfo(int).min).any(axis=None):
            logger.info(
                f"get_tag_ndarray (tag: {tag}) values contain int.min encoded NAs"
            )
            # Take a margin of 10000 as float has less precision than int.
            # We expect this large negative numbers not to occur in our data...
            values[values < np.iinfo(int).min + 10000.0] = np.nan

    return np.array((epochs, values.astype(np.double)))


# %%
def get_tag_ndarray_list(tags: list, time_range: tuple) -> list:
    """Call 'get_tag_ndarray' for each tag in tags and return the list of results."""

    logger.debug(f"DEBUG: get_tag_ndarray_list: list: {tags}")
    data_list = []
    for tag in tags:
        logger.debug(f"DEBUG: get_tag_ndarray_list: tag:{tag}, range:{time_range}")
        tag_values = get_tag_ndarray(tag, time_range)
        data_list.append(tag_values)

    return data_list


# %%
"""
Functions to select data for a time range
"""


# %%
def select_data(df: pd.DataFrame, time_range: tuple) -> pd.DataFrame:
    """Select relevant rows from df"""

    return df[
        (df.start_time < time_range[1]) & (df.next_time > time_range[0])
    ].reset_index(drop=True)


# %%
def select_ndarray(tag_data: np.ndarray, time_range: tuple) -> np.ndarray:
    """Select time range from epoch in column 0 (i.e. data for one batch).

    Arguments:
    - tag_data : ndarray with two columns. Column 0 contains epoch and column 1 values
    - time_range : tuple with requested begin and end time
    Returns:
    - ndarray similar to tag_data, containing epochs from time_range
    Description:
    For the return value [:,1:-2] the values are the same as original. For [:,[0,-1]]
    the values are the linear interpolation to match the exact times for the
    boundaries of time_range.
    """

    # Initial epoch_selector is True for index _between_ time range
    epoch_selector = (time_range[0] < tag_data[0]) & (tag_data[0] < time_range[1])
    if np.sum(epoch_selector) > 0:
        # 'normal' situation: datapoints between time range
        min_index = np.min(np.where(epoch_selector))
        max_index = np.max(np.where(epoch_selector))
    elif (
        np.sum(time_range[0] < tag_data[0]) * np.sum(tag_data[0] < time_range[1])
    ) > 0:
        # If the requested range is between two adjacent datapoints, make sure those
        # two datapoints will be selected later on
        min_index = np.min(np.where(time_range[0] < tag_data[0]))
        max_index = np.max(np.where(tag_data[0] < time_range[1]))
    else:
        logger.warn(
            f"WARNING: select_ndarray: will return NaN values for time range {time_range}"
        )
        return np.array((time_range, (np.nan, np.nan)))

    # If possible, select the first datapoints outside the time range
    # for linear interpolation of the boundaries
    if min_index > 0:
        epoch_selector[min_index - 1] = True
    if max_index < (epoch_selector.shape[0] - 1):
        epoch_selector[max_index + 1] = True

    epochs = tag_data[0, epoch_selector]
    if min_index > 0:
        epochs[0] = time_range[0]
    if max_index < (epoch_selector.shape[0] - 1):
        epochs[-1] = time_range[1]

    values = np.interp(epochs, tag_data[0, epoch_selector], tag_data[1, epoch_selector])
    return np.array((epochs, values))


# %%
def select_ndarray_list(tag_data_list: list, time_range: tuple) -> list:
    """Call 'select_ndarray' for each item in tag_data_list and return a list of all results."""

    data_list = []
    for tag_data in tag_data_list:
        data_list.append(select_ndarray(tag_data, time_range))
    return data_list


# %%
def remove_nan(arr: np.ndarray) -> np.ndarray:
    """Remove NaN values

    Arguments:
    - arr - a 2D array with shape (2,n). first index 0 -> epoch; 1 -> values
    Description
    Return arr, eliminating NaN values and their corresponding epoch, unless all values
    are NaN (then [[first epoch, last epoch], [NaN, NaN]] is returned).
    In case the first or last value is NaN, it is replaced with the first or last valid
    value. This way the first and last epoch will always remain in the returned array.
    """

    time_range = (arr[0][0], arr[0][-1])
    valid_val = ~np.isnan(arr[1])
    if np.any(valid_val):
        valid_idx = np.nonzero(valid_val)
        del valid_val
        # Make sure first and last are valid values ->
        # copy first valid or last valid to first and last
        arr[1][0] = arr[1][valid_idx[0][0]]
        arr[1][-1] = arr[1][valid_idx[0][-1]]
        del valid_idx
        return arr[..., ~np.isnan(arr[1])]
    else:
        return np.array([time_range, [np.nan, np.nan]])


# %%
def remove_nan_list(tag_data_list: list) -> list:
    """Remove NaN values using remove_nan() for each element in the list"""

    return [remove_nan(tag_data) for tag_data in tag_data_list]


# %%
def align_epoch_for_ndarray_list(tag_data_list: list) -> list:
    """Get the union of all epoch lists and interpolate corresponding values

    Arguments:
    - tag_data_list : list of 2D ndarrays with epoch in 1st column and values in 2nd
    Returns:
    - same list of ndarrays, with each ndarray having the same superset of epochs in col 1
    Description:
    Imagine a list with two ndarrays with the following epochs: 1.0, 3.0, 5.0, 10.0 in ndarray 1
    and 1.0, 2.0, 3.0, 7.0, 10.0 in ndarray 2. The resulting ndarrays will have the following
    epochs: 1.0, 2.0, 3.0, 5.0, 7.0, 10.0. For ndarray 1 values for epoch 2.0 and 7.0 will be
    interpolated. For ndarray 2 the values for epoch 3.0 and 5.0 have to be interpolated.

    Given a list of two ndarrays with epochs, with some values missing, e.g.:
            tag_data_list = [
                np.array([
                    [1.0,      3.0, 5.0,      10.0],  # epochs
                    [1,        2,   3,        4], # values
                ]
                ),
                np.array([
                    [1.0, 2.0, 3.0, 7.0, 10.0],  # epochs
                    [1,   2,   3,   4,   5],      # values
                ])
            ]
    transform so that we get:
            result = [
                np.array([
                    [1.0, 2.0, 3.0, 5.0, 7.0, 10.0],
                    [1,   1.5, 2,   3,   3.4, 4],
                    #     ^^^            ^^^
                ]),
                np.array([
                    [1.0, 2.0, 3.0, 5.0, 7.0, 10.0],
                    [1,   2,   3,   3.5, 4,   5],
                    #               ^^^
                ])
            ]
    """

    # First get full list of (unique) epochs:
    epochs = reduce(np.union1d, (arr[0] for arr in tag_data_list))
    # return list with epoch column replaced and values column linear interpolated
    return [
        np.array((epochs, np.interp(epochs, xp=arr[0], fp=arr[1])))
        for arr in tag_data_list
    ]
