# %%
"""
Preprocess utilities for data from OSI-Pi

Configuration items in misc_utils.config
- OSIPI_TABLE

This module provides:
 - def get_first_last_epoch_of_osipi(table: str) -> tuple:
 - def get_epoch_list_of_new_time_range(table: str, part_period: int=86400) -> list:
 - def load_osipi_data_to_df(table: str, timestamp_epoch: float, period: float) -> pd.DataFrame:
 - def process_osi_pi_specific(df: pd.DataFrame) -> pd.DataFrame:

"""

# %%
import numpy as np
import pandas as pd

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import athena_utils, logger, misc_utils, preprocess_pcs_utils

# %% [raw]
#


# %%
def get_first_last_epoch_of_osipi(table: str) -> tuple:
    """
    Read first and last epoch time from OSIPI db
    Returns: tuple with two float values in epoch format, (<first>, <last>)
    """
    logger.info(f"Read first/last epoch from OSIPI table ({table})...")
    try:
        # Prevent full table scan, by getting the partition data first
        partion_values = (
            athena_utils.get_table_data(
                db_config_index="osipi",
                table=misc_utils.config["OSIPI_TABLE"],
                columns=[
                    r"to_unixtime(MIN(partition_date)) AS min_p_d",
                    r"to_unixtime(MAX(partition_date)) AS max_p_d",
                ],
            )
            .iloc[0, :]
            .to_list()
        )
        logger.info(
            f"first/last epoch of {table} table partitions: {partion_values[0]}/{partion_values[1]}"
        )
        # epoch is float -> SQL "IN" using cast to DATE to avoid rounding errors
        epoch_values = athena_utils.get_table_query(
            db_config_index="osipi",
            table=table,
            columns=[
                r"max(to_unixtime(timestamp_utc)) AS max_date",
                r"min(to_unixtime(timestamp_utc)) AS min_date",
            ],
            where=(
                f"partition_date IN (CAST(from_unixtime({partion_values[0]+1.0}) AS date), "
                + f"CAST(from_unixtime({partion_values[1]+1.0}) AS date))"
            ),
        )
        if epoch_values["max_date"].isna().all():
            last_epoch = 0
        else:
            last_epoch = epoch_values["max_date"].iloc[0]
        if epoch_values["min_date"].isna().all():
            first_epoch = 0
        else:
            first_epoch = epoch_values["min_date"].iloc[0]
    except Exception:
        logger.error(f"ERROR: Table {table} could not be queried")
        raise ValueError("ERROR: get_first_last_epoch_of_osipi - table.")
        last_epoch = 0

    logger.info(f"first/last epoch of {table} table: {first_epoch}/{last_epoch}")

    return (first_epoch, last_epoch)


# %%
def get_epoch_list_of_new_time_range(table: str, part_period: int = 86400) -> list:
    """
    Read last epoch from preproc database and
    read last epoch from osipi database
    convert epoch to epoch at the start of a part_period
    prepare list of every day at 0:00 in epoch format between last epoch preproc db and last epoch osipi db
        -> osipi data can be processed to preproc data per 24 hours time frame
    """
    last_preproc_epoch_date = preprocess_pcs_utils.get_last_epoch_of_preproc()
    osi_from_epoch_date, to_epoch_date = get_first_last_epoch_of_osipi(table)
    from_epoch_date = (
        last_preproc_epoch_date
        if last_preproc_epoch_date > osi_from_epoch_date
        else osi_from_epoch_date
    )

    # convert epoch to epoch at the start of a part_period
    from_epoch_midnight = np.trunc(from_epoch_date / part_period) * part_period
    to_epoch_midnight = np.trunc(to_epoch_date / part_period) * part_period

    # prepare list of epochs at the start of all part_periods within the range
    timestamp_lst = list(
        np.arange(from_epoch_midnight, to_epoch_midnight + 0.1, part_period)
    )

    return timestamp_lst


# %%
def load_osipi_data_to_df(
    table: str, timestamp_epoch: float, period: float
) -> pd.DataFrame:
    """
    load athena data from last updated osipi data with subset of timestamp_epoch
        subset timestamp_epoch = date 0:00:00 to date 24:00:00
    converting column "timestamp_utc" to epoch format as column epoch
    and column "value_type" to lowercase

    Returns: columns: 'tag_name', 'epoch', 'value_string', 'value_type'
    """
    logger.info(f"Loading from {table}...")
    df = athena_utils.get_table_free_query(
        table=table,
        select=r"tagname AS tag_name, to_unixtime(timestamp_utc) AS epoch, value, value_type",
        query=f"""
        WHERE to_unixtime(partition_date) >= {timestamp_epoch-86400}
          AND to_unixtime(timestamp_utc) BETWEEN {timestamp_epoch} AND {timestamp_epoch+period}

        """,
        db_config_index="osipi",
    )
    logger.debug(f"DEBUG: Read from db: df.shape: {df.shape} (period: {period})")
    df["value_type"] = df["value_type"].str.lower()
    df = df.rename(columns={"value": "value_string"})

    return df


# %%
def process_osi_pi_specific(df: pd.DataFrame) -> pd.DataFrame:
    """
    Specific processing of the data:
    - remove lines where tag_name == null
    - dropping invalid timestamps in epoch format
    - add 'timestamp', converted from epoch to string

    Returns: columns: 'tag_name', 'epoch', 'timestamp' 'value_string', 'value_type'
    """

    # Remove nan tags
    df = df.loc[df["tag_name"].notnull()].copy()

    # drop invalid timestamps (in epoch)
    logger.info("Check for invalid timestamps...")
    invalid_ts = df["epoch"].isna()
    if invalid_ts.sum():
        logger.warning(
            f"{invalid_ts.sum()} invalid timestamps encountered. Dropping them.\n{df[invalid_ts].head(n=100)}"
        )
        df = df[~invalid_ts].copy()

    # Convert timestamp epoch to str; needed for generating row_ids
    logger.info("Convert timestamp from epoch to str...")
    # unix time (epoch) to UTC datetime object
    df["timestamp"] = pd.to_datetime(df["epoch"], unit="s")
    # UTC datetime object in format "%d-%b-%y %H:%M:%S.%f"
    df["timestamp"] = df["timestamp"].dt.strftime("%d-%b-%y %H:%M:%S.%f")

    return df.reset_index(drop=True).copy()
