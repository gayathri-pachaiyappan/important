# %%
"""
This file defines all Redshift DB functions

def get_tables() -> list:
def get_table_list() -> list:  # Legacy, use get_tables()
def get_column_info(table: str) -> pd.DataFrame:
def get_column_names(table: str) -> pd.DataFrame:  # Legacy, use get_column_info()
def get_all_table_data(table: str) -> pd.DataFrame:
def get_table_data(table: str, columns: list) -> pd.DataFrame:
def get_table_query(table: str, columns: list, where: str) -> pd.DataFrame:
def append_table(df: pd.DataFrame, table: str, upsert: bool = True) -> None:
def append_to_table(df: pd.DataFrame, table: str, upsert: bool = True) -> None:  Legacy, use append_table()
def overwrite_table(df: pd.DataFrame, table: str, method: str = "drop") -> None:
def copy_table(
def DROP_tag_data_table(tag_name: str) -> None: #LEGACY
def DROP_data_table(table_name: str) -> None:
"""

# %%
import re

# %%
import awswrangler as wr
import pandas as pd

# %%
# Load modules of
# Load/copy variables and modules of our team library
# Copy some variables
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, the main config
from abt_epd_gpmo_aa import logger, s3_utils

# %% [markdown]
# #### Variables for connections
#
# Defines (and opens)
# - db_connection
# - db_schema
#
# They are intended to be used in this module, but may be used in other modules as well.

# %%
if "REDSHIFT_SECRET_NAME" in misc_utils.config:
    secret_name = misc_utils.config["REDSHIFT_SECRET_NAME"]
    if secret_name == "DEFAULT":
        secret_name = f"""/{misc_utils.config["ENVIRONMENT"]}/{misc_utils.config["PROJECT_NAME"]}/redshift-secret"""
    db_connection = wr.redshift.connect(
        secret_id=secret_name
        # connection=misc_utils.config["REDSHIFT_CONNECTION_NAME"],
        # dbname=misc_utils.config["REDSHIFT_DBNAME"],
    )
else:
    db_connection = wr.redshift.connect(
        connection=misc_utils.config["REDSHIFT_CONNECTION_NAME"],
        dbname=misc_utils.config["REDSHIFT_DBNAME"],
    )

# %%
db_schema = misc_utils.config["REDSHIFT_SCHEMA"]


# %% [markdown]
# ## Generic table functions


# %%
def get_tables() -> list:
    """Get start and end time of a (batch) ID.

    Arguments:
    - tag: name of the tag
    - id : single file name in S3 bucket that has to be stored in Redshift
    Returns:
    - (begin, end) : tuple containing begin and end time in epoch
    Description:
      Get the timestamps of the earliest occurrence and the latest 'next_epoch'
      of string type tags. It returns (0, 0) in case the 'id' (or 'tag') was not found.
    """

    sql_query = f"""
            SELECT
                "table_name"
            FROM "information_schema"."tables"
            WHERE
                "table_schema" = '{db_schema}'
                AND "table_type" = 'BASE TABLE'
            ORDER BY "table_name"
            """

    try:
        logger.debug("DEBUG: SQL_statement:" + sql_query)
        return (
            wr.redshift.read_sql_query(sql_query, con=db_connection).iloc[:, 0].tolist()
        )
    except Exception as err:
        logger.error("ERROR: SQL Query FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_query)
        # id not found
        return list()


def get_table_list() -> list:
    logger.warning(
        "WARNING: legacy function 'get_table_list()' will be removed in the future!"
    )
    return get_tables()


# %%
def get_column_info(table: str) -> pd.DataFrame:

    sql_query = f"""
            SELECT
                "ordinal_position" as "position",
                "column_name",
                "data_type",
                case when "character_maximum_length" is not null
                    then "character_maximum_length"
                    else numeric_precision end as "max_length",
                "is_nullable",
                "column_default" as "default_value"
            FROM "information_schema"."columns"
            WHERE
                "table_name" = '{table}'
                AND "table_schema" = '{db_schema}'
            """
    try:
        logger.debug("DEBUG: SQL_statement:" + sql_query)
        return wr.redshift.read_sql_query(sql_query, con=db_connection)
    except Exception as err:
        logger.error("ERROR: SQL Query FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_query)
        # id not found
        return pd.DataFrame()


def get_column_names(table: str) -> pd.DataFrame:
    logger.warning(
        "WARNING: legacy function 'get_column_names()' will be removed in the future!"
    )
    return get_column_info(table)


# %%
def get_all_table_data(table: str) -> pd.DataFrame:
    """Get all data from Redshift for a table.

    Arguments:
    - table : name of the table of which data is requested
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets a full table from Redshift.
    """

    # Query for the data.
    sql_query = f"""
            SELECT
                *
            FROM "{db_schema}"."{table}"
            """

    try:
        logger.debug("DEBUG: SQL_statement:" + sql_query)
        return wr.redshift.read_sql_query(sql_query, con=db_connection)
    except Exception as err:
        logger.error("ERROR: SQL Query FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_query)
        # table not found or no data in table
        return pd.DataFrame()


# %%
def get_table_data(table: str, columns: list) -> pd.DataFrame:
    """Get selected columns from Redshift for a table.

    Arguments:
    - table : name of the table of which data is requested
    - columns : a list with the names of the columns that have to be returned
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets selected columns for all data rows from a table from Redshift.
      Note: each column may contain a function and 'AS nice_name'.
    """

    # Query for the data.
    sql_query = f"""
            SELECT
                "{'","'.join(columns)}"
            FROM "{db_schema}"."{table}"
            """

    try:
        logger.debug("DEBUG: SQL_statement:" + sql_query)
        return wr.redshift.read_sql_query(sql_query, con=db_connection)
    except Exception as err:
        logger.error("ERROR: SQL Query FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_query)
        # table not found or no data in table
        return pd.DataFrame()


# %%
def get_table_query(table: str, columns: list, where: str) -> pd.DataFrame:
    """Get selected columns for matching rows from Redshift for a table.

    Arguments:
    - table : name of the table of which data is requested
    - columns : a list with the names of the columns that have to be returned
    - where : a valid where clause
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets selected columns for the rows matching the where clause from a table from Redshift.
      Note: each column may contain a function and 'AS nice_name'.
    """

    # Query for the data.
    sql_query = f"""
            SELECT
                "{'","'.join(columns)}"
            FROM "{db_schema}"."{table}"
            WHERE
                {where}
            """

    try:
        logger.debug("DEBUG: SQL_statement:" + sql_query)
        return wr.redshift.read_sql_query(sql_query, con=db_connection)
    except Exception as err:
        logger.error("ERROR: SQL Query FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_query)
        # table not found or no data in table
        return pd.DataFrame()


# %% [markdown]
# ## Write data functions


# %%
def append_table(
    df: pd.DataFrame, table: str, pk_columns: list, upsert: bool = True
) -> None:
    """Append contents of data frame to or create table.

    Note: use for small tables (character limit on SQL statements as used by 'to_sql')
    use a function using 'copy' for larger tables
    """
    try:
        wr.redshift.to_sql(
            df=df,
            con=db_connection,
            schema=db_schema,
            table=table,
            mode="upsert" if upsert else "append",
            primary_keys=pk_columns,
            index=False,
            use_column_names=True,
            commit_transaction=True,
        )
    except Exception as err:
        logger.error("ERROR: to_sql(append) FAILED: " + str(err))
        raise


def append_to_table(df: pd.DataFrame, table: str, upsert: bool = True) -> None:
    logger.warning(
        "WARNING: legacy function 'append_to_table()' will be removed in the future!"
    )
    append_table(df, table, upsert)
    return


# %%
def overwrite_table(df: pd.DataFrame, table: str, method: str = "drop") -> None:
    """
    method: drop, cascade, truncate, or delete

    Note: use for small tables (character limit on SQL statements as used by 'to_sql')
    use a function using 'copy' for larger tables
    """
    try:
        wr.redshift.to_sql(
            df=df,
            con=db_connection,
            schema=db_schema,
            table=table,
            mode="overwrite",
            overwrite_method=method,
            index=False,
            use_column_names=True,
            commit_transaction=True,
        )
    except Exception as err:
        logger.error("ERROR: to_sql(overwrite) FAILED: " + str(err))
        raise


# %%
def copy_table(
    df: pd.DataFrame,
    table: str,
    mode: str = "overwrite",
    pk_columns: list = None,
    method: str = "drop",
    commit_transaction: bool = True,
) -> None:
    """
    mode: append, overwrite or upsert
    method: drop, cascade, truncate, or delete. Method for overwritting. Only applicable in overwrite mode.
    """
    try:
        wr.redshift.copy(
            df=df,
            path=f"s3://{misc_utils.config['BUCKET_NAME']}/tmp/redshift_copy",
            con=db_connection,
            schema=db_schema,
            table=table,
            mode=mode,
            primary_keys=pk_columns,
            overwrite_method=method,
            index=False,
            commit_transaction=commit_transaction,
        )
    except Exception as err:
        logger.error("ERROR: copy_table FAILED: " + str(err))
        logger.info(f"ERROR: COPY_TABLE FAILED: dataframe contains {df.shape[0]} rows")
        raise


# %%
def copy_table_from_files(
    s3_url: str,
    table: str,
    mode: str = "overwrite",
    pk_columns: list = None,
    method: str = "truncate",
    delete_files: bool = False,
) -> None:
    """Replace/create table from data on S3, erase S3-files on success

    s3_url: s3://<bucket>/<path> - <path> to folder or file (Unix CLI wildcards can be used)
    mode: append, overwrite or upsert
    method: drop, cascade, truncate, or delete. Method for overwritting. Only applicable in overwrite mode.
    """
    try:
        wr.redshift.copy_from_files(
            path=s3_url,
            con=db_connection,
            schema=db_schema,
            table=table,
            mode=mode,
            overwrite_method=method,
            primary_keys=pk_columns,
            varchar_lengths_default=1024,
        )
        # Clean up files on S3
        if delete_files:
            logger.info(
                f"""Removing files after successful copy_table_from_files: {s3_url}"""
            )
            s3_utils.delete_url(s3_url)
    except Exception as err:
        logger.error("ERROR: copy_from_files FAILED: " + str(err))
        logger.info(f"ERROR: WRITE TABLE FAILED: s3_url {s3_url}")
        raise


# %% [markdown]
# ## Erase data functions


# %%
def DROP_tag_data_table(tag_name: str) -> None:

    logger.warning("WARNING: LEGACY: 'tag_*' tables are no longer used on RedShift.")

    table = "tag_" + re.sub("[^a-z0-9]", "_", tag_name.lower())
    DROP_data_table(table)

    return


# %%
def DROP_data_table(table_name: str) -> None:
    sql_statement = f"""
        DROP TABLE IF EXISTS "{db_schema}"."{table_name}"
    """
    try:
        logger.debug("DEBUG: SQL_statement:" + sql_statement)
        db_connection.cursor().execute(sql_statement)
        logger.info(f"Dropped table {table_name}")
    except Exception as err:
        logger.error("ERROR: DROP TABLE FAILED: " + str(err))
        logger.error("DEBUG: SQL_statement:" + sql_statement)

    db_connection.cursor().execute("COMMIT")
    return
