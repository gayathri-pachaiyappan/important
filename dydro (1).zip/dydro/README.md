# dydro: OSI-PI to preprocessed

Runs one Glue job, `osipi_to_preprocessed`: OSI-PI (Athena, nonprod staging DB) -> preprocessed
PCS tables (`string` / `int` / `float`) in our own Glue database + S3.

## Layout
- `abt_epd_gpmo_aa/` – the team library **as source** (was a separate wheel). Edit it here directly.
- `glue_jobs/osipi_to_preprocessed.py` – the job
- `mycode/dydro/line_constants.toml` – AWS account, bucket, **databases (nonprod)**, wheel list
- `mycode/dydro/dydro/project_config.toml` – project settings + Glue workflow (one scheduled job)
- `mycode/dydro/dydro/pcs_tag_types.toml` – tag types (must live next to `project_config.toml`
  so it is uploaded to Glue)
- `glue_setup/` – builds the wheel, uploads it + config, creates the Glue workflow/job
- `init_jobs/check_aws_setup.py` – preflight: bucket, own DB, OSI-PI table, no prod
- `init_jobs/create_tag_types_toml.py` – one-off: regenerates `pcs_tag_types.toml` from OSI-PI
- `shell/` – wheel build, list/remove workflow

## How the library gets to Glue
`poetry build` packages `abt_epd_gpmo_aa/` into `dist/dydro-<version>-py3-none-any.whl`.
`create_glue_jobs.py` builds it, uploads it to `s3://<bucket>/gpmo/dydro/glue_jobs/lib/`,
and the job loads it via `EXTRA_WHEEL_FILES`. You never touch the wheel by hand.
If you bump `version` in `pyproject.toml`, update `EXTRA_WHEEL_FILES` too (the script checks).

## Setup (once, in SageMaker terminal, from the repo root)
```shell
conda activate <env>            # python 3.9
pip install poetry               # if not available
poetry install                   # installs abt_epd_gpmo_aa from this repo (editable) + deps
python init_jobs/check_aws_setup.py -p dydro
```
If the own-database check fails, it prints the databases you can see: put the right one in
`line_constants.toml` `[DATABASES.default] DATABASE`.

## Deploy
```shell
python glue_setup/create_glue_jobs.py -p dydro
```
After changing only config (`*.toml`): `python glue_setup/update_glue_job_configs.py -p dydro`.
After changing library code: run `create_glue_jobs.py` again (rebuilds + uploads the wheel).

## Databases
| key | used for | value |
|---|---|---|
| `DATABASES.default` | our preprocessed tables (read + write) | `abt_aa_weesp_dydro_20261001` |
| `DATABASES.osipi` | OSI-PI source (read only, no CTAS) | `AwsDataCatalog.abt_ea_stagingdb_nonprod` |
