#!/bin/bash

# NOTE: Do not execute this script manually; it is intended to be run from
# create_glue_jobs.py only
# Argument $1: the full s3 location of the glue 'lib' folder for the '.whl' file

set -e

CUR_DIR=$(pwd)

# Repo root = parent of this script's folder (no need to export ABT_USER / GIT_REPO)
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"

echo
echo "Preparing for glue job creation"
echo "repo: $REPO_DIR"
echo "S3  : $1"
echo

# Erase all cache and precompiled files in the repository
source "$REPO_DIR/shell/clean_repo.sh"

# Create wheel file for current repository (includes abt_epd_gpmo_aa)
rm -Rf "${REPO_DIR}/dist/"*
source "$REPO_DIR/shell/create_wheel.sh"

# Copy the dydro wheel to S3
aws s3 cp "${REPO_DIR}/dist/" "$1" --recursive --exclude "*" --include "*.whl"

cd "$CUR_DIR"
