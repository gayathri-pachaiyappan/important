# %%
"""
This module defines the DataSource instances used by the specific plant.

This script expects a [GLUE_GLOBALS] section in line_constants.toml with the following keys:
S3_GLUE_FOLDER_NAME
S3_LIBRARY_FOLDER_NAME
EXTRA_WHEEL_FILES
GLUE_CONNECTIONS

"""

# %%
import os
import subprocess
from pathlib import Path

import toml

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, but still empty
from abt_epd_gpmo_aa import logger

# %% [markdown]
# Get and set misc_utils.config, so other modules can use it in their initialisation

# %%
if not misc_utils.config["CONFIGURED"]:
    # Get and set config, so other modules can use it in their initialisation

    # In Glue jobs 'args' get set in main script by "glue_boilerplate_configs.py"
    # If that is not the case, get the data from the command line or set the default
    if not ("args" in vars() or "args" in globals()):
        args = misc_utils.get_options(default_project="dydro")

    logger.info(f"args:\n{args}")
    misc_utils.set_global_config(
        project=args["project_name"],
        line=args["line_name"] if "line_name" in args else "dydro",
    )

# %%
# Now misc_utils.config is set, load other modules of our team library
import abt_epd_gpmo_aa

logger.info(f"Version of abt_epd_gpmo_aa: {abt_epd_gpmo_aa.__version__}")
from abt_epd_gpmo_aa import glue_utils, s3_utils


# %%
def main():

    if "GLUE" not in misc_utils.config:
        logger.warning(
            """WARNING: no "GLUE" section in config for project """
            + f"""{misc_utils.config["LOCAL_PROJECT"]} ({misc_utils.config["LOCAL_PROJECT_NAME"]})"""
        )
        return None

    if misc_utils.config["GLUE"]["status"] != "on":
        logger.warning(
            """WARNING: config "GLUE.status" not "on" for project: """
            + f"""{misc_utils.config["LOCAL_PROJECT"]} ({misc_utils.config["LOCAL_PROJECT_NAME"]})"""
        )
        return None

    # Use the location of the constants file as startpoint for all our searches
    path_to_constants = misc_utils.config["USED_CONSTANTS_FILE"]

    glue_globals = misc_utils.config["GLUE_GLOBALS"]
    base_s3_prefix = (
        misc_utils.config["S3_BASE_PREFIX"] + glue_globals["S3_GLUE_FOLDER_NAME"] + "/"
    )
    base_s3_url = s3_utils.path_to_url([base_s3_prefix])[0]

    # The Glue job only gets the wheels listed in EXTRA_WHEEL_FILES, so the dydro wheel
    # (which contains abt_epd_gpmo_aa) must be listed with the version from pyproject.toml
    repo_dir = Path(__file__).resolve().parent.parent
    pyproject = toml.load(repo_dir / "pyproject.toml")["tool"]["poetry"]
    wheel_name = f"{pyproject['name']}-{pyproject['version']}-py3-none-any.whl"
    if wheel_name not in glue_globals["EXTRA_WHEEL_FILES"]:
        raise ValueError(
            f"{wheel_name} (from pyproject.toml) is not in GLUE_GLOBALS.EXTRA_WHEEL_FILES "
            + f"in line_constants.toml: {glue_globals['EXTRA_WHEEL_FILES']}"
        )

    prepare_script_name = "prepare_glue_job_creation.sh"
    ret = subprocess.call(
        [
            "bash",
            misc_utils.find_path_name_to_files(
                misc_utils.find_root_of_subtree(
                    [prepare_script_name], path_to_constants
                ),
                prepare_script_name,
            )[0],
            base_s3_url + glue_globals["S3_LIBRARY_FOLDER_NAME"],
        ]
    )
    if ret != 0 or not (repo_dir / "dist" / wheel_name).exists():
        raise RuntimeError(
            f"Building/uploading {wheel_name} failed (see output above); not creating Glue jobs."
        )

    project_config = misc_utils.config

    logger.info(
        f"Initialising Glue Workflow for project: {project_config['LOCAL_PROJECT_SHORT']}"
        + f" ({project_config['LOCAL_PROJECT_NAME']})"
    )
    is_combined_job = ("type" in project_config["GLUE"]) and (
        project_config["GLUE"]["type"] == "combined-job"
    )
    if is_combined_job:
        logger.info("Starting preparations for a combined glue job workflow launch...")
        path_to_combined_glue_job_py = glue_utils.create_combined_glue_job_py(
            project_config
        )
        glue_utils.update_glue_config_for_combined_jobs(project_config)
        logger.info("Preparations for a combined glue job workflow launch DONE.")
    s3_utils.upload_directory(
        str(
            misc_utils.get_full_dir_name_of_constants_file()
            + f"/{project_config['LOCAL_PROJECT_NAME']}"
        ),
        prefix=f"{base_s3_prefix}{project_config['LOCAL_PROJECT_NAME']}/",
    )
    s3_utils.upload_file(
        str(path_to_constants),
        prefix=f"{base_s3_prefix}{project_config['LOCAL_PROJECT_NAME']}/",
    )

    # Create Workflow object
    glue_workflow = glue_utils.GlueWorkflow(project_config)
    for glue_job_index in project_config["GLUE"]["job"]:
        # Add Glue job definition to workflow
        glue_workflow.add_job(
            glue_job_index, project_config["GLUE"]["job"][glue_job_index]
        )
    for glue_trigger_index in project_config["GLUE"]["trigger"]:
        # Add Glue trigger definition to workflow
        glue_workflow.add_trigger(
            glue_trigger_index,
            project_config["GLUE"]["trigger"][glue_trigger_index],
        )
    # Create AWS Glue Workflow, jobs and triggers
    glue_workflow.create()
    logger.info(f"Glue workflow {glue_workflow.workflow_name} creation done")
    if is_combined_job:
        logger.info(f"Deleting {path_to_combined_glue_job_py}.")
        os.remove(path_to_combined_glue_job_py)
    logger.info("=== All glue workflow creations done ===")


# %%
if __name__ == "__main__":
    main()  # Use a separate main function so it can be tested.
