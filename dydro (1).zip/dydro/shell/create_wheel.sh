#!/bin/bash

CUR_DIR=$(pwd)

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="${REPO_DIR}/dist"

cd "$REPO_DIR"

echo
echo "Creating wheel file for ${REPO_DIR} (includes abt_epd_gpmo_aa)"
echo
echo "Creating the wheel file may take up to 2 min"
date

# freeze-wheel pins the dependency versions from poetry.lock into the wheel,
# so Glue installs exactly what you tested with locally
poetry self show plugins 2>/dev/null | grep -q poetry-plugin-freeze || poetry self add poetry-plugin-freeze
poetry build --format wheel
poetry freeze-wheel

date

echo
echo "Files created in $DIST_DIR"
echo
ls -l "${DIST_DIR}"

cd "$CUR_DIR"
