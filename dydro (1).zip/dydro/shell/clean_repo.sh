#!/bin/bash

CUR_DIR=$(pwd)

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cd "$REPO_DIR"

find . -type d -name ".ipynb_checkpoints" -prune -exec rm -Rf {} \;

find . -type d -name "__pycache__" -prune -exec rm -Rf {} \;

find . -type d -name ".mypy_cache" -prune -exec rm -Rf {} \;

find . -type d -name ".pytest_cache" -prune -exec rm -Rf {} \;

cd "$CUR_DIR"
