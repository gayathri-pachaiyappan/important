"""
Preflight check for the dydro config (run from SageMaker before create_glue_jobs.py):

    python init_jobs/check_aws_setup.py -p dydro

Checks that the S3 bucket, our own Glue database (DATABASES.default) and the
OSI-PI table in DATABASES.osipi are reachable, and that nothing points to prod.
"""

import awswrangler as wr
import boto3

from abt_epd_gpmo_aa import logger, misc_utils

args = misc_utils.get_options(default_project="dydro")
misc_utils.set_global_config(
    project=args["project_name"],
    line=args["line_name"] if "line_name" in args else None,
)
cfg = misc_utils.config

from abt_epd_gpmo_aa import athena_utils  # noqa: E402  (needs config set first)

ok = True


def check(name, func):
    global ok
    try:
        result = func()
        logger.info(f"OK    {name}{': ' + str(result) if result is not None else ''}")
    except Exception as err:
        ok = False
        logger.error(f"FAIL  {name}: {err}")


logger.info(f"ENVIRONMENT = {cfg['ENVIRONMENT']}")
logger.info(f"DATABASES   = {cfg['DATABASES']}")

for key, value in cfg["DATABASES"].items():
    if "prod" in value["DATABASE"].lower().replace("nonprod", ""):
        ok = False
        logger.error(f"FAIL  DATABASES.{key} points to PROD: {value['DATABASE']}")

check(
    f"S3 bucket {cfg['BUCKET_NAME']}",
    lambda: boto3.client("s3").head_bucket(Bucket=cfg["BUCKET_NAME"]) and None,
)

own_db = cfg["DATABASES"]["default"]["DATABASE"]


def _check_own_db():
    dbs = wr.catalog.databases(limit=1000)["Database"].tolist()
    if own_db not in dbs:
        raise ValueError(
            f"'{own_db}' not found. Databases you can see: {dbs}. "
            + "Put the right one in line_constants.toml [DATABASES.default] DATABASE."
        )


check(f"Glue database (default) {own_db}", _check_own_db)

check(
    f"OSI-PI table {cfg['DATABASES']['osipi']['DATABASE']}.{cfg['OSIPI_TABLE']}",
    lambda: athena_utils.get_table_free_query(
        table=cfg["OSIPI_TABLE"],
        select="MAX(partition_date) AS last_partition",
        query="",
        db_config_index="osipi",
    ).iloc[0, 0],
)

logger.info("All checks passed." if ok else "Some checks FAILED, fix line_constants.toml.")
