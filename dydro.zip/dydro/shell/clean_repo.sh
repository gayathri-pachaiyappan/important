#!/bin/bash

CUR_DIR=$(pwd)

REPO_DIR="${HOME}/SageMaker/${ABT_USER}/${GIT_REPO}"

cd $REPO_DIR

find . -type d -name ".ipynb_checkpoints" -exec rm -Rf {} \;

find . -type d -name "__pycache__" -exec rm -Rf {} \;

find . -type d -name ".mypy_cache" -exec rm -Rf {} \;

find . -type d -name ".pytest_cache" -exec rm -Rf {} \;

cd $CUR_DIR
