#!/bin/bash

CUR_DIR=$(pwd)

REPO_DIR="${HOME}/SageMaker/${ABT_USER}/${GIT_REPO}"
DIST_DIR="${REPO_DIR}/dist"

cd $REPO_DIR

echo
echo "Creating wheel file for ${GIT_REPO}"
echo
echo "Creating the wheel file may take up to 2 min"
date


poetry self add poetry-plugin-freeze
poetry build
poetry freeze-wheel

date

echo
echo "Files created in $DIST_DIR"
echo
ls -l ${DIST_DIR}

cd $CUR_DIR
