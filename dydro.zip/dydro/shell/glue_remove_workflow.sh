#!/bin/bash

CUR_DIR=$(pwd)

PROJECTNAME_TAG=$(sed -n '/ResourceName": *"/{s/^.*ResourceName": *"\(.*[0-9]\{9\}\)-.*$/\1/g;p}' /opt/ml/metadata/resource-metadata.json)
WF_PREFIX="${PROJECTNAME_TAG}-WORKFLOW"

get_aws_list () {
  local LIST=$1
  echo -n "Getting ${LIST}..."
  local AWS_BASE_COMMAND="aws glue list-${LIST}"
  if [[ "$LIST" == "jobs" || "$LIST" == "triggers" ]]
  then
    AWS_BASE_COMMAND+=" --tags ProjectName=${PROJECTNAME_TAG}"
  fi
  local RAW_RESULT=($($AWS_BASE_COMMAND))
  AWS_RESULT=($(for RR in ${RAW_RESULT[@]}; do echo $RR; done | grep "${WF_PREFIX}-" | sed "s/.*\(${WF_PREFIX}.*-nonprod\).*/\1/" | sort))
  local NEXT_TOKEN=$(for ((I=0;I<${#RAW_RESULT[@]};I++)); do if [[ "${RAW_RESULT[$I]}" == "\"NextToken\":" ]]; then (echo ${RAW_RESULT[((I+1))]} | sed s'/^.*"\(.*\)".*$/\1/'); fi ; done)
  while (( ${#NEXT_TOKEN} > 0 ))
  do
    echo -n "+..."
    RAW_RESULT=($($AWS_BASE_COMMAND --next-token "${NEXT_TOKEN}"))
    AWS_RESULT+=($(for RR in ${RAW_RESULT[@]}; do echo $RR; done | grep "${WF_PREFIX}-" | sed "s/.*\(${WF_PREFIX}.*-nonprod\).*/\1/" | sort))
    NEXT_TOKEN=$(for ((I=0;I<${#RAW_RESULT[@]};I++)); do if [[ "${RAW_RESULT[$I]}" == "\"NextToken\":" ]]; then echo ${RAW_RESULT[((I+1))]} | sed 's/.*"\(.*\)".*/\1/'; fi ; done)
  done
}

get_project_folder () {
  if [ $# -eq 0 ] 
  then
    echo "Warning: No S3 project folder found because no Glue Jobs were found for this Glue Workflow."
  else 
    local FIRST_JOB="$1"
    S3_PROJECT_LOCATION=$(aws glue get-job --job-name "${FIRST_JOB}" --query 'Job.Command."ScriptLocation"' --output text | sed 's/"//g' | rev | cut -d'/' -f2- | rev)
    echo "Found S3 project folder ${S3_SCRIPT_LOCATION}"
  fi  
}

echo
echo "ProjectName: ${PROJECTNAME_TAG}"
echo


SCRIPT_ERROR=0
if [ -z "$1" ]
then
  SCRIPT_ERROR=1
  echo
  echo "ERROR: no workflow name provided"
  echo
  echo "$0 <valid workflow name>"
  echo
  echo "Use glue_list.sh to show valid names."
  echo
else
  WORKFLOW_TO_REMOVE="$1"
  echo "Removal requested for workflow (incl. jobs and triggers): ${WORKFLOW_TO_REMOVE}"
  echo
fi

if [ $SCRIPT_ERROR -eq 0 ]
then
  PROJECTNAME_TAG=$(sed -n '/ResourceName": *"/{s/^.*ResourceName": *"\(.*[0-9]\{9\}\)-.*$/\1/g;p}' /opt/ml/metadata/resource-metadata.json)
  WF_PREFIX="${PROJECTNAME_TAG}-WORKFLOW"

  echo
  echo "ProjectName: ${PROJECTNAME_TAG}"
  echo
  get_aws_list "workflows"
  WORKFLOWS=(${AWS_RESULT[@]})
  echo " done."
  echo
  FOUND=""
  for WF in ${WORKFLOWS[@]}
  do
    if [ "${WF}" == "$WORKFLOW_TO_REMOVE" ]
    then
      FOUND=$WF
    else
      BASE_WF=${WF%-nonprod}
      if [ "${BASE_WF#${WF_PREFIX}-}" == "$WORKFLOW_TO_REMOVE" ]
      then
        FOUND=$WF
      fi
    fi
  done
  if [ -z $FOUND ]
  then
    SCRIPT_ERROR=1
    echo
    echo "ERROR: workflow NOT found: $WORKFLOW_TO_REMOVE"
    echo
    echo "Valid workflows are:"
    for WF in ${WORKFLOWS[@]}
    do
      echo "${WF}"
    done
    echo
  else
    WORKFLOW_TO_REMOVE=${FOUND}
    BASE_WF=${WORKFLOW_TO_REMOVE%-nonprod}
  fi
fi

if [ $SCRIPT_ERROR -eq 0 ]
then
  echo
  echo "Going to REMOVE workflow ${WORKFLOW_TO_REMOVE}"
  echo "  and ALL related jobs & triggers."
  echo
  get_aws_list "jobs"
  JOBS=($(for R in ${AWS_RESULT[@]}; do echo $R; done | grep "${BASE_WF}-JOB-"))
  get_aws_list "triggers"
  TRIGGERS=($(for R in ${AWS_RESULT[@]}; do echo $R; done | grep "${BASE_WF}-TRIGGER-"))
  get_project_folder $JOBS
  echo " done."


  echo "  Jobs:"
  for J in ${JOBS[@]}
  do
    echo "${J}"
  done
  echo "  Triggers:"
  for T in ${TRIGGERS[@]}
  do
    echo "${T}"
  done
  echo

  for T in ${TRIGGERS[@]}
  do
    echo "Deleting ${T}..."
    # echo "aws glue delete-trigger --name ${T}"
    aws glue delete-trigger --name "${T}"
  done
  echo

  for J in ${JOBS[@]}
  do
    echo "Deleting ${J}..."
    # echo "aws glue delete-job --job-name ${J}"
    aws glue delete-job --job-name "${J}"
  done
  echo

  # Check if everything has been deleted
  get_aws_list "jobs"
  JOBS=($(for R in ${AWS_RESULT[@]}; do echo $R; done | grep "${BASE_WF}-JOB-"))
  echo " done."
  echo
  echo "Jobs remaining:"
  for R in ${JOBS[@]}
  do
    echo $R
  done

  echo

  echo "Triggers remaining: (first: waiting 15 sec for deletion to complete)"
  sleep 15
  get_aws_list "triggers"
  TRIGGERS_REM=($(for R in ${AWS_RESULT[@]}; do echo $R; done | grep "${BASE_WF}-TRIGGER-"))
  echo " done."
  echo
  # while [ ${#TRIGGERS_REM[@]} -eq 0 ]
  while [ ${#TRIGGERS_REM[@]} -gt 0 ]
  do
    for T in ${TRIGGERS_REM[@]}
    do
      echo "${T}"
    done
    echo
    for T in ${TRIGGERS_REM[@]}
    do
      echo "Deleting again ${T}..."
      # echo "aws glue delete-trigger --name ${T}"
      aws glue delete-trigger --name "${T}"
    done
    echo

    echo
    echo -n "Triggers remaining: (first: waiting 15 sec for deletion to complete)"
    sleep 15
    get_aws_list "triggers"
    TRIGGERS_REM=($(for R in ${AWS_RESULT[@]}; do echo $R; done | grep "${BASE_WF}-TRIGGER-"))
    echo " done."
    echo
  done
  echo

  echo "Now deleting workflow: ${WORKFLOW_TO_REMOVE}..."
  # echo "aws glue delete-workflow --name ${WORKFLOW_TO_REMOVE}"
  aws glue delete-workflow --name "${WORKFLOW_TO_REMOVE}"
  echo
  if [ -n ${S3_PROJECT_LOCATION+x} ]
  then 
      echo "Now deleting S3 project folder: ${S3_PROJECT_LOCATION}..."
      aws s3 rm $S3_PROJECT_LOCATION --recursive 
  fi

fi

echo

cd $CUR_DIR
