#!/bin/bash

CUR_DIR=$(pwd)

PROJECTNAME_TAG=$(sed -n '/ResourceName": *"/{s/^.*ResourceName": *"\(.*[0-9]\{9\}\)-.*$/\1/g;p}' /opt/ml/metadata/resource-metadata.json)
WF_PREFIX="${PROJECTNAME_TAG}-WORKFLOW"

get_aws_list () {
  local LIST=$1
  echo -n "Getting ${LIST}..."
  local AWS_BASE_COMMAND="aws glue list-${LIST}"
  if [[ "$LIST" == "jobs" || "$LIST" == "triggers" ]]
  then
    AWS_BASE_COMMAND+=" --tags ProjectName=${PROJECTNAME_TAG}"
  fi
  local RAW_RESULT=($($AWS_BASE_COMMAND))
  AWS_RESULT=($(for RR in ${RAW_RESULT[@]}; do echo $RR; done | grep "${WF_PREFIX}-" | sed "s/.*\(${WF_PREFIX}.*-nonprod\).*/\1/" | sort))
  local NEXT_TOKEN=$(for ((I=0;I<${#RAW_RESULT[@]};I++)); do if [[ "${RAW_RESULT[$I]}" == "\"NextToken\":" ]]; then (echo ${RAW_RESULT[((I+1))]} | sed s'/^.*"\(.*\)".*$/\1/'); fi ; done)
  while (( ${#NEXT_TOKEN} > 0 ))
  do
    echo -n "+..."
    RAW_RESULT=($($AWS_BASE_COMMAND --next-token "${NEXT_TOKEN}"))
    AWS_RESULT+=($(for RR in ${RAW_RESULT[@]}; do echo $RR; done | grep "${WF_PREFIX}-" | sed "s/.*\(${WF_PREFIX}.*-nonprod\).*/\1/" | sort))
    NEXT_TOKEN=$(for ((I=0;I<${#RAW_RESULT[@]};I++)); do if [[ "${RAW_RESULT[$I]}" == "\"NextToken\":" ]]; then echo ${RAW_RESULT[((I+1))]} | sed 's/.*"\(.*\)".*/\1/'; fi ; done)
  done
}

echo
echo "ProjectName: ${PROJECTNAME_TAG}"
echo
get_aws_list "workflows"
WORKFLOWS=(${AWS_RESULT[@]})
get_aws_list "jobs"
JOBS=(${AWS_RESULT[@]})
get_aws_list "triggers"
TRIGGERS=(${AWS_RESULT[@]})
echo " done."
echo

echo "  Workflows (${#WORKFLOWS[@]}):"
for WF in ${WORKFLOWS[@]}
do
  BASE_WF=${WF%-nonprod}
  echo "${BASE_WF#${WF_PREFIX}-} 	- ${WF}"
done
for I in ${!WORKFLOWS[@]}
do
  BASE_WF=${WORKFLOWS[$I]%-nonprod}
  echo
  echo "$I - ${BASE_WF#${WF_PREFIX}-}"
  echo "  Jobs:"
  for J in ${JOBS[@]}
  do
    if [[ "$J" == "${BASE_WF}-JOB-"* ]]
    then
      echo "${J}"
    fi
  done
  echo "  Triggers:"
  for T in ${TRIGGERS[@]}
  do
    if [[ "$T" == "${BASE_WF}-TRIGGER-"* ]]
    then
      echo "${T}"
    fi
  done
done

echo

cd $CUR_DIR
