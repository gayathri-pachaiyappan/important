#!/bin/bash

CUR_DIR=$(pwd)

REPO_DIR="${HOME}/SageMaker/${ABT_USER}/${GIT_REPO}"

# dir does not exist in environments like CodeBuild project
if [ -d $REPO_DIR ]
then
  echo "Found and changing to ${REPO_DIR}"
  cd $REPO_DIR
fi
mkdir -p lib

aws s3 cp "s3://$(cat s3_bucket)/libraries/" ./lib/ --recursive --exclude "*" --include "abt_epd_gpmo_aa-*.whl"

# Just do the preparations, so user has control over when to install
# (For example, user might want to switch to new conda environment first)
# rm poetry.lock
# poetry install

cd $CUR_DIR
