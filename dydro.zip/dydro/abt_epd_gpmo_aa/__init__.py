# %%
import importlib.metadata
import logging
import sys

# %%
# The library source lives inside the dydro repo and ships in the dydro wheel,
# so there is no separate "abt_epd_gpmo_aa" distribution to read the version from.
__version__ = "1.3.5-dydro"
try:
    __version__ = (
        f"1.3.5-dydro (dist {importlib.metadata.version('dydro')})"
    )
except importlib.metadata.PackageNotFoundError:
    pass

# %%
logger = logging.getLogger()

# %%
# Remove existing handlers
if logger.handlers:
    for handler in logger.handlers:
        logger.removeHandler(handler)

# %%
logger = logging.getLogger()
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter(
    "%(asctime)s %(levelname)-8s [%(filename)30s:%(lineno)d] %(message)s"
)
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)
