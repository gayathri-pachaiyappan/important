# dydro – OSI-PI to preprocessed (nl_epd_wbexaa, cada layout)

Runs only the OSI-PI -> preprocessed job. Same layout as the cada sample.

- `nl_epd_wbexaa/` – library (misc_utils, athena_utils, s3_utils, datasource)
- `nl_epd_wbexaa/config_init.toml` – plant/project names + Glue schedule
- `nl_epd_wbexaa/dydro/constants.toml` – AWS names, table prefix/S3 path, OSI-PI table + database
- `nl_epd_wbexaa/dydro/pcs_tag_types.py` – your 2139 tags (S/F/I), converted from `pcs_tag_types.toml`
- `glue_jobs/osipi_to_preprocessed_job.py` – the job
- `init_jobs/create_pcs_tag_types.py` – optional: regenerate the tag types from the OSI-PI table

Changes vs. cada: `osipi` database comes from `OSIPI_DATABASE` in `constants.toml` (no hardcoded prod catalog),
and preprocessed data is written under `PREPROCESSED_S3_PATH`.

## Run locally (from the repo root)
```shell
poetry install
export AWS_PROFILE=abbott-nonprod-dydro AWS_DEFAULT_REGION=eu-west-1
poetry run python glue_jobs/osipi_to_preprocessed_job.py
```
With no `dydro_prep_pcs_float` table yet, the job starts at 22-12-2021; stop it with Ctrl+C after a day or two for a first test.
