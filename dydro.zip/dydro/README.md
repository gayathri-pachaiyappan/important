# dydro: OSI-PI to preprocessed (local run)

Reads OSI-PI data (Athena, nonprod staging DB) and writes preprocessed PCS tables
(`string` / `int` / `float`) to our own Glue database + S3. Runs locally, no Glue job.

## Layout
- `osipi_to_preprocessed.py` – the job
- `abt_epd_gpmo_aa/` – team library source, trimmed to what this job needs. Edit directly.
- `mycode/dydro/line_constants.toml` – account, bucket, databases (nonprod)
- `mycode/dydro/dydro/project_config.toml` – OSI-PI table name, table prefix, S3 path
- `mycode/dydro/dydro/pcs_tag_types.toml` – tag types
- `init_jobs/diagnose_permissions.py` – shows which databases/workgroups your credentials can use
- `init_jobs/create_tag_types_toml.py` – one-off: regenerates `pcs_tag_types.toml` from OSI-PI

## Run (from the repo root)
```shell
poetry install                        # once; installs abt_epd_gpmo_aa from this repo + deps
python osipi_to_preprocessed.py       # project defaults to dydro
```

## If you get "Insufficient permissions to execute the query"
```shell
python init_jobs/diagnose_permissions.py
```
Use the database form that shows `[ OK ]` in `line_constants.toml`:
`[DATABASES.osipi] DATABASE` for the OSI-PI source, `[DATABASES.default] DATABASE` for our own tables.
