# dydro – OSI-PI to preprocessed

Trimmed AIDA2 project (line `dydro`, project `dydro`) that only runs the
`osipi_to_preprocessed` Glue job: OSI-PI (Athena table) -> preprocessed PCS tables
(`string` / `int` / `float`) on S3.

## Layout
- `glue_jobs/osipi_to_preprocessed.py` – the job (unchanged from AIDA2)
- `mycode/dydro/line_constants.toml` – line-level settings (AWS account, partitioning, wheels)
- `mycode/dydro/dydro/project_config.toml` – project settings + Glue workflow (one scheduled job)
- `glue_setup/` – creates the Glue workflow/job from `[GLUE]` in the project config
- `init_jobs/create_tag_types_toml.py` – one-off: builds `pcs_tag_types.toml` from the OSI-PI table
- `shell/` – wheel build, library copy, list/remove workflow

## Before first run
1. Edit the `TODO` values in `mycode/dydro/dydro/project_config.toml`
   (`OSIPI_TABLE`, `PREPROCESSED_TABLE_PREFIX`, `PREPROCESSED_S3_PATH`).
2. Check AWS values in `line_constants.toml` (copied from AIDA2).
3. Provide tag types: run `init_jobs/create_tag_types_toml.py` and save the output as
   `mycode/dydro/dydro/pcs_tag_types.toml` (the job uses it when no tag lookup table exists).
4. The job needs the team library `abt_epd_gpmo_aa` (1.3.0). It was not in the upload;
   `shell/copy_abt_gpmo_library_from_s3.sh` fetches it into `lib/`.

## Deploy / run
```shell
export ABT_USER=<you> GIT_REPO=<repo-dir-name>
bash shell/copy_abt_gpmo_library_from_s3.sh
python glue_setup/create_glue_jobs.py --project dydro --line dydro   # option names per abt_epd_gpmo_aa misc_utils.get_options
```
