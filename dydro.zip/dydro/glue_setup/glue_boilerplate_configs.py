# %%
import os
import sys

# %%
import boto3
from awsglue.utils import getResolvedOptions

# %%
args = getResolvedOptions(
    sys.argv,
    ["JOB_NAME", "extra-py-files", "bucket_name", "s3_glue_prefix", "project_name"],
)

# %%
s3 = boto3.resource("s3")


# %%
def s3_upload_file(file_name, prefix):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param prefix
    """

    object_name = os.path.basename(file_name)
    s3.meta.client.upload_file(file_name, args["bucket_name"], prefix + object_name)


# %%
def s3_download_file(s3_object, prefix=None):
    """Download a file from an S3 bucket

    :param s3_object: File to download (given together with the prefix)
    """
    file_name = os.path.basename(s3_object)
    if prefix:
        s3.meta.client.download_file(args["bucket_name"], s3_object, prefix + file_name)
    else:
        s3.meta.client.download_file(args["bucket_name"], s3_object, file_name)


# %%
def s3_get_sorted_file_objects(bucket_name: str, prefix: str):
    print(f"Finding files in s3://{bucket_name}/{prefix}...")
    bucket = s3.Bucket(bucket_name)
    objects = bucket.objects.filter(Prefix=prefix)

    # Remove the directory itself, we just want the files.
    objects = [obj for obj in objects if not obj.key.endswith("/")]
    objects = sorted(objects, key=lambda obj: obj.last_modified)
    print(f"Found {len(objects)} files in s3://{bucket_name}/{prefix}.")
    return objects


# %%
def s3_download_directory(prefix: str, to_prefix: str, condition=None):
    """Download a directory from an S3 bucket

    :param prefix:
    :param condition: condition to check if string is in the file name to be downloaded
    """
    s3_object_list = s3_get_sorted_file_objects(args["bucket_name"], prefix=prefix)
    for s3_object in s3_object_list:
        if condition:
            if condition in s3_object.key:
                print(f"Downloading file {s3_object.key}")
                s3_download_file(s3_object.key, to_prefix)
        else:
            print(f"Downloading file {s3_object.key}")
            s3_download_file(s3_object.key, to_prefix)


# %%
os.mkdir(args["project_name"])
s3_download_directory(
    prefix=f"{args['s3_glue_prefix']}{args['project_name']}/",
    to_prefix=f"{args['project_name']}/",
)
