# %%
"""
This module defines the DataSource instances used by the specific plant.

This script expects a [GLUE_GLOBALS] section in line_constants.toml with the following keys:
S3_GLUE_FOLDER_NAME
S3_LIBRARY_FOLDER_NAME
EXTRA_WHEEL_FILES

"""

# %%
# Import and copy some variables of our team library
from abt_epd_gpmo_aa import misc_utils  # provides misc_utils.config, but still empty
from abt_epd_gpmo_aa import logger

# %% [markdown]
# Get and set misc_utils.config, so other modules can use it in their initialisation

# %%
if not misc_utils.config["CONFIGURED"]:
    # Get and set config, so other modules can use it in their initialisation

    # In Glue jobs 'args' get set in main script by "glue_boilerplate_configs.py"
    # If that is not the case, get the data from the command line or set the default
    if not ("args" in vars() or "args" in globals()):
        args = misc_utils.get_options(default_project=None)

    logger.info(f"args:\n{args}")
    misc_utils.set_global_config(
        project=args["project_name"],
        line=args["line_name"] if "line_name" in args else None,
    )

# %%
# Now misc_utils.config is set, load other modules of our team library
import abt_epd_gpmo_aa

logger.info(f"Version of abt_epd_gpmo_aa: {abt_epd_gpmo_aa.__version__}")
from abt_epd_gpmo_aa import s3_utils


# %%
def main():
    logger.info("=== Starting to update the config of All glue workflows ===")
    # Use the location of the constants file as startpoint for all our searches
    path_to_constants = misc_utils.config["USED_CONSTANTS_FILE"]

    glue_globals = misc_utils.config["GLUE_GLOBALS"]
    base_s3_prefix = (
        misc_utils.config["S3_BASE_PREFIX"] + glue_globals["S3_GLUE_FOLDER_NAME"] + "/"
    )

    project_config = misc_utils.config
    if "GLUE" in project_config:
        if project_config["GLUE"]["status"] == "on":
            logger.info(
                f"Updating Glue Workflow config for project: {project_config['LOCAL_PROJECT_SHORT']}"
                + f" ({project_config['LOCAL_PROJECT_NAME']})"
            )
            s3_utils.upload_directory(
                str(
                    misc_utils.get_full_dir_name_of_constants_file()
                    + f"/{project_config['LOCAL_PROJECT_NAME']}"
                ),
                prefix=f"{base_s3_prefix}{project_config['LOCAL_PROJECT_NAME']}/",
            )
            logger.info(
                f"NowUpdating Glue Workflow config for project: {project_config['LOCAL_PROJECT_SHORT']}"
                + f" ({project_config['LOCAL_PROJECT_NAME']})"
            )
            s3_utils.upload_file(
                str(path_to_constants),
                prefix=f"{base_s3_prefix}{project_config['LOCAL_PROJECT_NAME']}/",
            )

        else:
            logger.warning(
                """WARNING: config "GLUE.status" not "on" for project: """
                + f"""{misc_utils.config["LOCAL_PROJECT"]} ({misc_utils.config["LOCAL_PROJECT_NAME"]})"""
            )
    else:
        logger.warning(
            """WARNING: no "GLUE" section in config for project """
            + f"""{misc_utils.config["LOCAL_PROJECT"]} ({misc_utils.config["LOCAL_PROJECT_NAME"]})"""
        )
    logger.info("=== All glue workflow config updating done ===")


# %%
if __name__ == "__main__":
    main()  # Use a separate main function so it can be tested.
