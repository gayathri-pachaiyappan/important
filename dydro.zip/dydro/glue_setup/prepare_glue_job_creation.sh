#!/bin/bash

# NOTE: Do not execute this script manually; it is intended to be run from
# create_glue_jobs.py only
# This python script provides
# 1) the full s3 location for the '.whl' file

CUR_DIR=$(pwd)

REPO_DIR="${HOME}/SageMaker/${ABT_USER}/${GIT_REPO}"
cd $REPO_DIR

echo
echo "Preparing for glue job creation"
echo "user: $ABT_USER"
echo "repo: $GIT_REPO"
echo "S3  : $1"
echo
echo "Check - you might need to execute 'export GIT_REPO=abt-aa-...' first"
echo


# Erase all cache and precompiled files in the repository
source $REPO_DIR/shell/clean_repo.sh

# Create wheel file for current repository
rm -Rf ${REPO_DIR}/dist/*
source $REPO_DIR/shell/create_wheel.sh

# Now copy created wheel file to S3
aws s3 cp "${REPO_DIR}/dist/" "$1" --recursive --exclude "*" --include "*.whl"

# Now also copy GPMO Library wheel file to S3
aws s3 cp "${REPO_DIR}/lib/" "$1" --recursive --exclude "*" --include "abt_epd_gpmo_aa-*-py3-none-any.whl"

cd $CUR_DIR
