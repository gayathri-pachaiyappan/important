"""
Find out which Athena database / catalog / workgroup combinations this role may use.

    python init_jobs/diagnose_permissions.py

Paste the full output back. Nothing is written or changed; it only runs tiny SELECTs.
"""

import awswrangler as wr
import boto3

from abt_epd_gpmo_aa import misc_utils

args = misc_utils.get_options(default_project="dydro")
misc_utils.set_global_config(project=args["project_name"])
cfg = misc_utils.config
table = cfg["OSIPI_TABLE"]
wg = cfg["DATABASES"]["default"]["WORKGROUP"]


def short(err):
    return " ".join(str(err).split())[:220]


def run(label, func):
    try:
        res = func()
        print(f"[ OK ] {label}\n       -> {res}")
    except Exception as err:
        print(f"[FAIL] {label}\n       -> {type(err).__name__}: {short(err)}")


def athena(sql, database, workgroup=wg):
    df = wr.athena.read_sql_query(
        sql=sql, database=database, workgroup=workgroup, ctas_approach=False
    )
    return df.head(3).to_dict("records")


print("\n=== WHO AM I")
run("sts caller identity", lambda: boto3.client("sts").get_caller_identity()["Arn"])

print("\n=== WORKGROUPS I CAN SEE")
run(
    "athena list-work-groups",
    lambda: [w["Name"] for w in boto3.client("athena").list_work_groups()["WorkGroups"]],
)
run(f"workgroup '{wg}' output location", lambda: boto3.client("athena").get_work_group(
    WorkGroup=wg)["WorkGroup"]["Configuration"].get("ResultConfiguration"))

print("\n=== DATA CATALOGS I CAN SEE")
run(
    "athena list-data-catalogs",
    lambda: [c["CatalogName"] for c in boto3.client("athena").list_data_catalogs()["DataCatalogsSummary"]],
)

print("\n=== GLUE DATABASES I CAN SEE (own account catalog)")
run("glue get-databases", lambda: wr.catalog.databases(limit=1000)["Database"].tolist())

print(f"\n=== OSI-PI TABLE '{table}': which database form works?")
for catalog_db in [
    "AwsDataCatalog.abt_ea_stagingdb_nonprod",
    "abt_ea_stagingdb_nonprod",
    "AwsDataCatalogNonProd.abt_ea_stagingdb_nonprod",
    "AwsDataCatalogProd.abt_ea_stagingdb_prod",
]:
    run(
        f"SELECT ... FROM {catalog_db}.\"{table}\"",
        lambda c=catalog_db: athena(
            f'SELECT MAX(partition_date) AS last_partition FROM {c}."{table}"',
            database=c.split(".")[-1],
        ),
    )

own_db = cfg["DATABASES"]["default"]["DATABASE"]
print(f"\n=== OWN DATABASE '{own_db}'")
run(f"SHOW TABLES IN {own_db}", lambda: athena(f"SHOW TABLES IN `{own_db}`", database=own_db))
run(f"glue get-database {own_db}", lambda: boto3.client("glue").get_database(Name=own_db)["Database"]["Name"])

print(f"\n=== BUCKET '{cfg['BUCKET_NAME']}'")
run("s3 list (1 key)", lambda: boto3.client("s3").list_objects_v2(
    Bucket=cfg["BUCKET_NAME"], MaxKeys=1).get("KeyCount"))
