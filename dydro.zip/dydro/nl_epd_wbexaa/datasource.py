"""
The Class DataSource extends the module 'config' by defining names of paths of
files and prefixes for names of tables in the Glue Catalog. As these names
contain name of the data source in a structured way, they can all be derived
from the name provided in the constructor.
"""

import importlib

# Load main modules of our team library
WBEXAA_PKG = "nl_epd_wbexaa"
nl_epd_wbexaa = importlib.import_module(name=WBEXAA_PKG)
utils = importlib.import_module(name=".misc_utils", package=WBEXAA_PKG)
config = utils.get_config()


class DataSource:
    # Constructor gets and stores the name of the data source
    def __init__(self, name: str) -> None:
        self.name = name

    # property to identify the storage area in AWS S3
    @property
    def bucket_name(self):
        return config["BUCKET_NAME"]

    # Path in S3 where new files will be uploaded
    @property
    def new_prefix(self):
        return f"{config['ORIGINAL_DATA_S3_PATH']}{self.name}/new/"

    # Path in S3 where processed files will be moved to
    @property
    def processed_prefix(self):
        return f"{config['ORIGINAL_DATA_S3_PATH']}{self.name}/processed/"

    # Path in S3 where preprocessed data of a Glue Catalog table will be stored
    # This is only needed when writing data to the table
    @property
    def preprocessed_prefix(self):
        return f"{config['PREPROCESSED_S3_PATH']}{self.name}/"

    # Path in S3 where feature data of a Glue Catalog table will be stored
    # This is only needed when writing data to the table
    @property
    def features_prefix(self):
        return (
            f"{config['S3_DATA_PREFIX']}features/{config['WEESP_PROJECT_SHORT']}_{self.name}/"
            # f"{config['FEATURES_S3_PATH']}{self.name}/"
        )

    # Path in S3 where join table data of a Glue Catalog table will be stored
    # This is only needed when writing data to the table
    # Note: join table data is stored in S3 feature folder -> features_prefix apply
    @property
    def join_table_prefix(self):
        return f"{config['S3_DATA_PREFIX']}features/{config['WEESP_PROJECT_SHORT']}_join_table_{self.name}/"
        # return f"{config['JOIN_S3_PATH']}{self.name}/"

    # (Prefix of) Glue Catalog table where preprocessed data is stored
    @property
    def preprocessed_table(self):
        return f"{config['PREPROCESSED_TABLE_PREFIX']}{self.name}"

    # (Prefix of) Glue Catalog table where feature data is stored
    @property
    def features_table(self):
        return f"{config['FEATURES_TABLE_PREFIX']}{self.name}"

    # (Prefix of) Glue Catalog table name where join table data is stored
    @property
    def join_table(self):
        return f"{config['JOIN_TABLE_PREFIX']}{self.name}"
