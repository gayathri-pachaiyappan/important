"""
This notebook provides generic functions to
- store data in S3 using the Glue catalog database infrastructure
- retrieve data from AWS Glue catalog tables (via Athena)

The following functions are provided
- Generic Glue catalog table functions - query
   - def get_table_list() -> list:
   - def get_column_names(table: str) -> pd.DataFrame:
   - def get_all_table_data(table: str) -> pd.DataFrame:
   - def get_table_data(table: str, columns: list) -> pd.DataFrame:
   - def get_table_query(table: str, columns: list, where: str) -> pd.DataFrame:
   - def get_table_free_query(table: str, select: str, where: str) -> pd.DataFrame:
- Generic Glue catalog table functions - write
   - def append_table(df: pd.DataFrame, table: str, s3_folder: str, partition_cols: Optional[List[str]] = None) -> dict:
   - def overwrite_table(df: pd.DataFrame, table: str, s3_folder: str, partition_cols: list = None) -> dict:
   - def delete_table(table: str, s3_prefix: str) -> bool:
- Specific query functions
   - def get_last_datapoints(table, by_field, time_field: str, extra_fields: list) -> pd.DataFrame:
"""

import importlib

# Athena and helpers
import awswrangler as wr

# Data processing
import pandas as pd

# Load main modules of our team library
WBEXAA_PKG = "nl_epd_wbexaa"
nl_epd_wbexaa = importlib.import_module(name=WBEXAA_PKG)
utils = importlib.import_module(name=".misc_utils", package=WBEXAA_PKG)
config = utils.get_config()
s3_utils = importlib.import_module(name=".s3_utils", package=WBEXAA_PKG)

# Equivalent of "from module import identifier" --> "identifier = module.identifier"
logger = nl_epd_wbexaa.logger


def get_tables(db_config_index: str = "default") -> list:
    """Get all available tables in our project database.

    Arguments:
    - None
    Returns:
    - List : List of strings with the names of the tables
    """

    try:
        # Use wrangler function instead of Athena method to filter on database name
        return [
            t["Name"]
            for t in wr.catalog.get_tables(
                database=config["DATABASES"][db_config_index]["DATABASE"]
            )
        ]
    except Exception as err:
        logger.error(f"ERROR: get_tables FAILED: {err}")
        raise


def get_table_s3_location(table_name: str, db_config_index: str = "default") -> str:
    """Return the S3 location for a Glue table"""

    try:
        return wr.catalog.get_table_location(
            database=config["DATABASES"][db_config_index]["DATABASE"], table=table_name
        )
    except Exception as err:
        logger.error(f"ERROR: get_table_s3_location FAILED: {err}")
        raise


def get_column_info(table: str, db_config_index: str = "default") -> pd.DataFrame:
    """Get names and other info on columns of table.

    Arguments:
    - table: name of the (existing) table in the project database
    Returns:
    - dataframe: with folowing info for each column: Column Name, Type, Partition, Comment
    """

    try:
        return wr.catalog.table(
            database=config["DATABASES"][db_config_index]["DATABASE"],
            table=table,
        )
    except Exception as err:
        logger.error(f"ERROR: get_table_details FAILED: {err}")
        raise


def get_all_table_data(table: str, db_config_index: str = "default") -> pd.DataFrame:
    """Get all data for a table.

    Arguments:
    - table : name of the table of which data is requested
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets a full table from Athena.
    """

    return get_table_free_query(
        table, select="*", query="", db_config_index=db_config_index
    )


def get_table_data(
    table: str, columns: list, db_config_index: str = "default"
) -> pd.DataFrame:
    """Get selected columns from Athena for a table.

    Arguments:
    - table : name of the table of which data is requested
    - columns : a list with the names of the columns that have to be returned (may also be ['*'])
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets selected columns for all data rows from a table from Athena.
      Note: each "column" in the list may contain a SQL function and 'AS nice_name'.
    """

    return get_table_free_query(
        table, select=",".join(columns), query="", db_config_index=db_config_index
    )


def get_table_query(
    table: str, columns: list, where: str, db_config_index: str = "default"
) -> pd.DataFrame:
    """Get selected columns for matching rows from Athena for a table.

    Arguments:
    - table : name of the table of which data is requested
    - columns : a list with the names of the columns that have to be returned (may also be ['*'])
    - where : a valid where clause
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    Description:
      This function just gets selected columns for the rows matching the where clause from a table from Athena.
      Note: each "column" in the list may contain a SQL function and 'AS nice_name'.
    """

    return get_table_free_query(
        table,
        select=",".join(columns),
        query=f"WHERE {where}",
        db_config_index=db_config_index,
    )


def get_table_free_query(
    table: str, select: str, query: str, db_config_index: str = "default"
) -> pd.DataFrame:
    """Get selected columns for matching rows from Athena for a table.

    Arguments:
    - table : name of the table of which data is requested
    - select : the part between SELECT and FROM
    - query : the part of the query after the FROM <table> (you have to include for example WHERE etc.)
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data
    """
    db_info = config["DATABASES"][db_config_index]
    # Query for the data.
    sql = f"""
            SELECT
                {select}
            FROM {db_info['DATABASE']}."{table}"
            {query}
            """

    return get_from_query(sql, db_config_index=db_config_index)


def get_from_query(sql_query: str, db_config_index: str = "default") -> pd.DataFrame:
    """Get selected columns for matching rows from Athena for a table.

    Arguments:
    - sql_query : Full SQL statement. Remember to use config["DATABASE"] with each table.

    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data.

    Description:
    Function intended use is for complex SQL queries; use other athena_utils functions for simple queries

    Complex SQL statements are needed to obtain specific tables e.g. tables with regular expressions
    in SELECT or WHERE sections or tables with joins from more than one table.
    Another complex SQL function is a table with a WITH clause as an optional prefix for SELECT e.g.
        WITH query_name (column_name1, ...) AS
             (SELECT ...)

        SELECT ...

    Complex SQL queries consists of SELECT, FROM, WHERE and other sections:
    - FROM section should contain table and database references e.g.
        f"FROM "{config['DATABASE']}"."{table}" AS tbl"
    - Table references {table} can be from nl_epd_wbexaa.{factory}.datasources.{source}.{sourcename} e.g.
        from nl_epd_wbexaa.aida.datasources import sap
        f"FROM "{config['DATABASE']}"."{sap.preprocessed_table}" AS tbl"

    ctas_approach = False  because True requires create/delete table permissions on Glue Catalog Database
                           permissions not available on osipi catalog database
    """

    # Query for the data.
    db_info = config["DATABASES"][db_config_index]
    logger.debug(f"Used database: {db_info['DATABASE']}")

    try:
        logger.debug("\nDEBUG: SQL_statement:" + sql_query)
        return wr.athena.read_sql_query(
            sql=sql_query,
            database=db_info["DATABASE"],
            workgroup=db_info["WORKGROUP"],
            ctas_approach=db_info["CTAS_APPROACH"],
            categories=None,
            chunksize=None,
            use_threads=True,
        )
    except Exception as err:
        logger.error(f"SQL_statement: {sql_query}")
        logger.error(f"ERROR: SQL Query FAILED: {err}")
        raise


def append_table(
    df: pd.DataFrame,
    table: str,
    s3_folder: str,
    partition_cols: list = None,
) -> dict:
    """Append data to an Athena database table (and might modify df).

    Arguments:
    - df : pandas dataframe containing the data; note: may be modified in place!
    - table : name of the table to which data is written
    - s3_folder : path to dataset (without bucket; no leading '/')
    - partition_cols : list of columns by which the data should be partitioned
    Returns:
    - dict : return value of awswrangler.s3.to_parquet (S3 file paths, etc.)
    Description:
      Write the contents of the DataFrame to an Athena table in 'append' mode.
      Note: df may be modified in place. Use df.copy() if you need df after this function call.

    Note: mention the catalog in the database name results in a GetTable error
           e.g. database=f"{db_info['CATALOG_NAME']}.{db_info['DATABASE']}",
           therefore use DATABASE= CATALOG_NAME.DATABASE only when needed (set in config_full.toml)
    """
    try:
        return wr.s3.to_parquet(
            df=df,
            path=f"s3://{config['BUCKET_NAME']}/{s3_folder}",
            partition_cols=partition_cols,
            database=config["DATABASES"]["default"]["DATABASE"],
            table=table,
            dataset=True,
            concurrent_partitioning=True,
            use_threads=True,
            mode="append",
        )
    except Exception as err:
        logger.error(f"ERROR: write_table (append) FAILED: {err}")
        raise


def overwrite_table(
    df: pd.DataFrame,
    table: str,
    s3_folder: str,
    partition_cols: list = None,
) -> dict:
    """(Erase and) write data to an Athena database table (and might modify df).

    Arguments:
    - df : pandas dataframe containing the data; note: may be modified in place!
    - table : name of the table to which data is written
    - s3_folder : path to dataset (without bucket; no leading '/')
    - partition_cols : list of columns by which the data should be partitioned
    Returns:
    - dict : return value of awswrangler.s3.to_parquet (S3 file paths, etc.)
    Description:
      Write the contents of the DataFrame to an Athena table in 'overwrite' mode.
      Note: df may be modified in place. Use df.copy() if you need df after this function call.

    Note: mention the catalog in the database name results in a GetTable error
           e.g. database=f"{db_info['CATALOG_NAME']}.{db_info['DATABASE']}",
           therefore use DATABASE= CATALOG_NAME.DATABASE only when needed (set in config_full.toml)
    """
    try:
        return wr.s3.to_parquet(
            df=df,
            path=f"s3://{config['BUCKET_NAME']}/{s3_folder}",
            partition_cols=partition_cols,
            database=config["DATABASES"]["default"]["DATABASE"],
            table=table,
            dataset=True,
            concurrent_partitioning=True,
            use_threads=True,
            mode="overwrite",
        )
    except Exception as err:
        logger.error(f"ERROR: (over)write_table FAILED: {err}")
        raise


def delete_table_partition(table: str, partitions_to_delete: list) -> bool:
    """Remove table from Glue catalog and erase data from S3"""

    partition_list = ",".join([str(e) for e in partitions_to_delete])
    # Get partitions and S3 prefix of partition folders
    select = (
        r"""DISTINCT partition_id, regexp_replace("$path", '/[^/]*$') AS "s3_path" """
    )
    where = f"""
    partition_id in (
      {partition_list}
    )
    """
    df_partitions = get_table_query(table, columns=[select], where=where)
    partitions = [[str(p)] for p in df_partitions.partition_id.to_list()]
    for path in df_partitions.s3_path.to_list():
        # Strip the bucket, as s3_utils don't expect it in the prefix
        s3_prefix = path.split(f"s3://{config['BUCKET_NAME']}/")[-1]
        # Remove s3 files
        for file_obj in s3_utils.get_sorted_file_objects(
            config["BUCKET_NAME"], s3_prefix
        ):
            file_obj.delete()

    # Remove table definition from glue catalog
    return wr.catalog.delete_partitions(
        database=config["DATABASE"], table=table, partitions_values=partitions
    )


def delete_last_table_partition(table: str, nr_partitions: int) -> bool:
    """Remove table from Glue catalog and erase data from S3"""

    # Get partitions and S3 prefix of partition folders
    select = (
        r"""DISTINCT partition_id, regexp_replace("$path", '/[^/]*$') AS "s3_path" """
    )
    where = f"""
    partition_id in (
        SELECT DISTINCT partition_id
        FROM "{config['DATABASE']}"."{table}"
        ORDER BY partition_id DESC
        LIMIT {nr_partitions}
    )
    """
    df_partitions = get_table_query(table, columns=[select], where=where)
    partitions = [[str(p)] for p in df_partitions.partition_id.to_list()]
    for path in df_partitions.s3_path.to_list():
        # Strip the bucket, as s3_utils don't expect it in the prefix
        s3_prefix = path.split(f"s3://{config['BUCKET_NAME']}/")[-1]
        # Remove s3 files
        for file_obj in s3_utils.get_sorted_file_objects(
            config["BUCKET_NAME"], s3_prefix
        ):
            file_obj.delete()

    # Remove table definition from glue catalog
    return wr.catalog.delete_partitions(
        database=config["DATABASE"], table=table, partitions_values=partitions
    )


def delete_table(table: str, location: str = None) -> bool:
    """Remove table from Glue catalog and erase data from S3"""

    # Retrieve location, although old code will provide it
    if not location:
        location = get_table_s3_location(table)
    # Strip the bucket, as s3_utils don't expect it in the prefix
    s3_prefix = location.split(f"s3://{config['BUCKET_NAME']}/")[-1]
    # Remove s3 files
    for file_obj in s3_utils.get_sorted_file_objects(config["BUCKET_NAME"], s3_prefix):
        file_obj.delete()

    # Remove table definition from glue catalog
    return wr.catalog.delete_table_if_exists(database=config["DATABASE"], table=table)


#
# Special database functions
#


def get_last_datapoints(
    table: str,
    by_field: str,
    time_field: str,
    extra_fields: list,
    condition: str = None,
) -> pd.DataFrame:
    """Special for incremental processing: get latest (max time_field) datapoint for each by_field

    Arguments:
    - table : name of the table of which data is requested
    - by_field: the fieldname by which data is grouped for latest record
    - time_field: the fieldname of the max(time)
    - extra_fields: fields that should also be returned in addition to by_field and time_field
    - condition: valid condition for a WHERE clause
    Returns:
    - pd.DataFrame : dataframe with for each 'by_field' the 'time_field' and the extra fields of the datapoint with max time
    """
    db_info = config["DATABASES"]["default"]
    select_fields = " ".join([f"t1.{f} AS {f}," for f in extra_fields])
    # Query for the data.

    sql = f"""
            SELECT DISTINCT {select_fields}
                t1.{by_field} AS {by_field},
                t1.{time_field} AS {time_field}
            FROM "{db_info['DATABASE']}"."{table}" AS t1
            JOIN
                (SELECT {by_field},
                     max({time_field}) AS m_epoch
                FROM "{db_info['DATABASE']}"."{table}"
                GROUP BY  {by_field}) AS t2
                ON t2.{by_field} = t1.{by_field}
                    AND t1.{time_field}=t2.m_epoch
            """
    if condition:
        sql += f" WHERE {condition}"

    if table in get_tables():
        try:
            logger.debug("\nDEBUG: SQL_statement:" + sql)
            return wr.athena.read_sql_query(
                sql=sql,
                database=db_info["DATABASE"],
                workgroup=db_info["WORKGROUP"],
                ctas_approach=db_info["CTAS_APPROACH"],
                categories=None,
                chunksize=None,
                use_threads=True,
            )
        except Exception as err:
            logger.error(f"SQL_statement: {sql}")
            logger.error(f"ERROR: SQL Query FAILED: {err}")
            raise
    else:
        fields = extra_fields
        fields.append(by_field)
        fields.append(time_field)
        return pd.DataFrame(columns=fields)


def get_last_pcs_preprocessed_datapoints(
    table: str, since: float = 0.0
) -> pd.DataFrame:
    """Special for preprocessing PCS data: get latest (max epoch) datapoint for each tag

    Arguments:
    - table : name of the table of which data is requested
    Returns:
    - pd.DataFrame : dataframe with for each 'tag' the 'epoch' and row_id of the
    datapoint with max epoch
    """

    return get_last_datapoints(
        table,
        by_field="tag",
        time_field="epoch",
        extra_fields=["row_id"],
        condition=f"t1.partition_id >= {int(since // config['PCS_PARTITION_PERIOD'])}",
    )


def get_pcs_table_free_query(
    table: str,
    select: str,
    query: str,
) -> pd.DataFrame:
    """Get selected columns for matching rows from Athena for a PCS table with inner join.

    Arguments:
    - table : name of the table of which data is requested
    - select : the part between SELECT and FROM
    - query : the part of the query after the FROM <table> (you have to include for example WHERE etc.)
    Returns:
    - pd.DataFrame : dataframe with the 'raw' table data

    Description:
    This function performs the INNER JOIN needed to get begin time and value plus next time
    and value. This is especially important for floating point values.
    Note: 'select' and 'query' have to use 'B.' and 'N.' for the values corresponding to
    the begin point and next point respectively.
    """

    # Query for the data.
    # (Inner) Join the table with itself to get begin/end time/value pairs
    db_info = config["DATABASES"]["default"]
    sql = f"""
            SELECT
                {select}
            FROM "{db_info['DATABASE']}"."{table}" AS B INNER
            JOIN "{db_info['DATABASE']}"."{table}" AS N
                ON N.prev_row_id = B.row_id
            {query}
           """

    try:
        logger.debug("\nDEBUG: SQL_statement:" + sql)
        return wr.athena.read_sql_query(
            sql=sql,
            database=db_info["DATABASE"],
            workgroup=db_info["WORKGROUP"],
            ctas_approach=db_info["CTAS_APPROACH"],
            categories=None,
            chunksize=None,
            use_threads=True,
        )
    except Exception as err:
        logger.error(f"SQL_statement: {sql}")
        logger.error(f"ERROR: SQL Query FAILED: {err}")
        raise


def write_to_redshift(df: pd.DataFrame, table: str) -> None:
    con = wr.redshift.connect(
        f"{config['PROJECT_NAME']}-{config['ENVIRONMENT']}",
        dbname=config["REDSHIFT_DBNAME"],
    )
    logger.info(f"Writing dataframe to {config['REDSHIFT_SCHEMA']}.{table}")
    wr.redshift.to_sql(
        df,
        con=con,
        table=table,
        schema=config["REDSHIFT_SCHEMA"],
    )
