"""
This notebook provides generic functions
- regarding memory
- for display in Jupyter notebooks

The following functions are provided
- regarding memory
   - def get_available_memory() -> int:
- read configurations:
   - def read_json_definition(def_name: str) -> dict:
- for display in Jupyter notebooks
   - def show_df(df: pd.DataFrame) -> None:
"""

import importlib
import json
import os
import re
from pathlib import Path

import IPython
import pandas as pd
import psutil
import toml

# Load main modules of our team library
WBEXAA_PKG = "nl_epd_wbexaa"
nl_epd_wbexaa = importlib.import_module(name=WBEXAA_PKG)

# Equivalent of "from module import identifier" --> "identifier = module.identifier"
logger = nl_epd_wbexaa.logger


# + active=""
#
# -


def get_available_memory() -> int:
    """Get available system memory (~ /proc/meminfo - MemAvailable)"""

    return psutil.virtual_memory().available / 2**30  # in GiB


# + active=""
#
# -


def get_full_path_to_package() -> Path:
    """Returns full path to package"""
    return Path(re.sub(f"^(.*/{WBEXAA_PKG}/).*$", r"\1", str(Path(".").resolve())))


def find_path_to_file(directory: str, file_name: str) -> list:
    """
    Returns a list of full Paths to all file_name files in the directory and child directories
    """
    toml_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(file_name):
                toml_files.append(Path(os.path.join(root, file)))
    return toml_files


def find_directory(dir_name: str) -> str:
    """find specific dir in parents or childs of current dir on local file system

    If not found, returns full path to current directory; ends with '/'
    """

    base_path = str(get_full_path_to_package()) + "/"
    if base_path.endswith(f"/{dir_name}/"):
        return base_path

    p = Path(base_path)
    dirs = [str(f) + "/" for f in p.glob(f"**/{dir_name}") if f.is_dir()]
    dirs.append(base_path)

    logger.info(f"Found directories matching {dir_name}: {dirs}; returning first.")
    return dirs[0] if len(dirs) else base_path


def find_project_files(file_name: str) -> list:
    """Find files in project directory on local file system"""

    config = get_config()
    # find full path spec to project directory
    proj_dir = find_directory(config["WEESP_SUB_PKG_PROJECT"])
    p = Path(proj_dir)
    proj_files = [str(f) for f in p.glob(f"**/{file_name}") if not f.is_dir()]

    if not len(proj_files):
        Exception(
            f'{file_name} not found in project directory ({config["WEESP_SUB_PKG_PROJECT"]} -> {proj_dir})'
        )
    else:
        logger.info(f"Found project files  matching {file_name}: {proj_files}")
        return proj_files


def read_json_definition(def_name: str) -> dict:
    """Read JSON from current / project directory on local file system"""

    json_def_files = find_project_files(def_name + ".json")
    if len(json_def_files):
        json_def_file = Path(json_def_files[0])
        logger.info(f"JSON definition file found: {json_def_file.name}")
        return json.loads(json_def_file.read_text())
    else:
        logger.error(
            f"JSON definition file {def_name}.json NOT found in current or project directory."
        )
        raise Exception(f"JSON file {def_name}.json not found.")


def read_multi_json_definitions(def_name: str, append_keys: list) -> dict:
    """Read multiple JSON from current / project directory on local file system

    Note: def name might be something like:
    "these_*_files"
    """

    json_def_files = find_project_files(def_name + ".json")

    # Prepare return value to empty lists for each 'append_key' key
    res = {}
    for k in append_keys:
        res[k] = []

    if json_def_files:
        for def_file in json_def_files:
            logger.info(f"Reading JSON definitions from:\n{def_file}")
            json_def = json.loads(Path(def_file).read_text())
            for k in append_keys:
                if k in json_def:
                    res[k] += json_def[k]
        return res
    else:
        logger.error(
            f"JSON definition files {def_name}.json NOT found in current or project directory."
        )
        raise Exception(f"JSON files {def_name}.json not found.")


# + active=""
#
# -


def read_toml_definition(
    def_name="config_init", project_folder=None, path=None
) -> dict:
    """

    Reads TOML from local file system.

    Parameters:
        def_name: file name of the file you want to be read, up to .toml, e.g. if you want to read in "config_full.toml" provide "config_full".
        Accepts regular expressions too.
        project_folder: specific folder to look for the toml file in, usually will be the project folder (config['WEESP_SUB_PKG_PROJECT']).
        If not provided looks for toml in all of the locations in the repository.

    Returns:
        TOML definitions in a dictionary

    """

    if path:
        return toml.load(path)

    # find full path spec to '/.../WBEXAA_PKG/'

    if project_folder is None:
        p = Path(re.sub(f"^(.*/{WBEXAA_PKG}/).*$", r"\1", str(Path(".").resolve())))
    else:
        p = Path(
            re.sub(f"^(.*/{WBEXAA_PKG}/).*$", r"\1", str(Path(".").resolve()))
            + f"/{project_folder}"
        )
    toml_def_file = [f for f in p.glob(f"**/{def_name}.toml") if not f.is_dir()]
    if len(toml_def_file):
        toml_def_file = toml_def_file[0]
        logger.info(f"TOML definition file found: {toml_def_file.name}")
        return toml.load(toml_def_file)
    else:
        logger.error(
            f"TOML definition file {def_name}.toml NOT found in (sub)directory (of) {str(p.resolve())}."
        )
        raise Exception(f"TOML file {def_name}.toml not found.")


def read_multi_toml_definition(
    def_name: str, append_keys: list, project_folder=None
) -> dict:
    """Read multiple JSON from local file system

    Note: def name might be something like:
    "{config.WEESP_SUB_PKG_PLANT}_{config.WEESP_PROJECT_SHORT}/these_*_files"
    """

    # find full path spec to '/.../WBEXAA_PKG/'
    if project_folder is None:
        p = Path(re.sub(f"^(.*/{WBEXAA_PKG}/).*$", r"\1", str(Path(".").resolve())))
    else:
        p = Path(
            re.sub(f"^(.*/{WBEXAA_PKG}/).*$", r"\1", str(Path(".").resolve()))
            + f"/{project_folder}"
        )

    feature_def_files = [f for f in p.glob(f"**/{def_name}.toml") if not f.is_dir()]

    if len(feature_def_files):
        # Prepare return value to empty lists for each 'append_key' key
        res = {}
        for k in append_keys:
            res[k] = []

        for feature_def_file in feature_def_files:
            logger.info(f"Reading TOML definitions from:\n{str(feature_def_file)}")
            toml_def = toml.load(feature_def_file.read_text())
            for k in append_keys:
                if k in toml_def:
                    res[k] += toml_def[k]

        return res
    else:
        logger.error(
            f"TOML definition file {def_name}.toml NOT found in (sub)directory (of) {str(p.resolve())}."
        )
        raise Exception(f"TOML file {def_name}.toml not found.")


# + active=""
#
# -


def toml_dict_to_pandas_df(toml_dict: dict, index_name) -> pd.DataFrame:
    """
    Function that takes a dict obtained from a TOML file (e.g. with function read_toml_definition) and converts it into a pandas DataFrame.
    This function is intended mostly for converting the following .toml files into pandas Dataframe:

            - derived_feature_definitions.toml
            - pcs_feature_groups.toml
            - pcs_feature_batch_time_refinements.toml

    Parameters:
        toml_dict: dictionary obtained by reading in a toml file (usaully from 'read_toml_definition' function)
        index_name: name given to the new column after the dictionary is read in as a dataframe and transposed. This new column comprises of the
        section names in the .toml file. e.g. derived_feature_definitions.toml

    Returns:
       Pandas dataframe.

    """
    df = pd.DataFrame(toml_dict).T.reset_index()
    df.rename(columns={"index": index_name}, inplace=True)
    return df


def get_config(
    config_name: str = "config_init",
    constants_name: str = "constants",
    config_path: str = None,
) -> dict:

    """
    Get configurations as a dictionary.

    Parameters:
        config_name: toml file name that holds configuration without the ".toml" extension
        constants_name: toml file name that holds configuration without the ".toml" extension

    Returns:
        config variables in a dictionarary.
    """

    config = read_toml_definition(config_name, path=config_path)
    constants = read_toml_definition(constants_name)

    # S3

    BUCKET_NAME = f"{constants['PROJECT_NAME']}-{constants['ENVIRONMENT']}"

    # +
    # Athena database info
    # If needed catalog name is part of DATABASE name e.g. "AwsDataCatalogProd.abt_ea_stagingdb_prod"
    # In DATABASES dict the index "default" is mandatory

    DATABASES = {
        "default": {  # default names are derived from PROJECT_NAME and ENVIRONMENT
            "WORKGROUP": constants["PROJECT_NAME"],
            "DATABASE": constants["PROJECT_NAME"].replace("-", "_")
            + f"_{constants['ENVIRONMENT']}",  # DB=database
            "CTAS_APPROACH": True,
        },
        "osipi": {
            "WORKGROUP": constants.get("OSIPI_WORKGROUP", constants["PROJECT_NAME"]),
            "DATABASE": constants["OSIPI_DATABASE"],  # DB=catalog.database, set in constants.toml
            "CTAS_APPROACH": False,
        },
    }

    # Intermediate solution for Athena database connector
    WORKGROUP = DATABASES["default"]["WORKGROUP"]
    DATABASE = DATABASES["default"]["DATABASE"]
    # -

    # Redshift
    REDSHIFT_CONNECTION_NAME = f"{constants['PROJECT_NAME']}-{constants['ENVIRONMENT']}"
    REDSHIFT_DBNAME = constants["ENVIRONMENT"]
    REDSHIFT_SCHEMA = constants["PROJECT_NAME"].replace("-", "_")

    # Project conventions

    # +
    # Table name prefix for Glue_catalog/Athena tables and Redshift tables
    ORIGINAL_DATA_S3_PATH = f"{constants['S3_DATA_PREFIX']}{constants['ORIGINAL']}/"
    ORIGINAL_NEW_DATA_S3_PATH_DATASOURCE = (
        f"{ORIGINAL_DATA_S3_PATH}{config['WEESP_PROJECT_SHORT']}/"
    )

    PREPROCESSED_TABLE_PREFIX = f"{constants['PREPROCESSED']}_"
    PREPROCESSED_S3_PATH = f"{constants['S3_DATA_PREFIX']}{constants['PREPROCESSED']}/"

    FEATURES_TABLE_PREFIX = f"{constants['FEATURES']}_{config['WEESP_PROJECT_SHORT']}_"
    FEATURES_S3_PATH = f"{constants['S3_DATA_PREFIX']}{constants['FEATURES']}/{config['WEESP_PROJECT_SHORT']}_"

    # JOIN_TABLE_PREFIX = f"{JOIN}_{WEESP_PROJECT_SHORT}_"
    JOIN_TABLE_PREFIX = (
        "join_table_{WEESP_PROJECT_SHORT}_"  # Legacy name; to be replaced by above one
    )
    JOIN_S3_PATH = f"{constants['S3_DATA_PREFIX']}{constants['JOIN']}/{config['WEESP_PROJECT_SHORT']}_"

    MASTER_TABLE_PREFIX = (
        f"{constants['MASTER_TABLE']}_{config['WEESP_PROJECT_SHORT']}_"
    )
    MASTER_S3_PATH = f"{constants['S3_DATA_PREFIX']}{constants['MASTER_TABLE']}/{config['WEESP_PROJECT_SHORT']}_"

    MODEL_TABLE_PREFIX = f"{constants['MODEL_OUTPUT']}_{config['WEESP_PROJECT_SHORT']}_"

    # Constants for specific use
    ############################

    # Special names
    REDSHIFT_PREDICTIONS_TABLE = f"{MODEL_TABLE_PREFIX}predictions"
    REDSHIFT_FEATURE_IMPORTANCE_TABLE = f"{MODEL_TABLE_PREFIX}feature_importances"

    config_dict = {
        "BUCKET_NAME": BUCKET_NAME,
        "DATABASES": DATABASES,
        "WORKGROUP": WORKGROUP,
        "DATABASE": DATABASE,
        "REDSHIFT_CONNECTION_NAME": REDSHIFT_CONNECTION_NAME,
        "REDSHIFT_DBNAME": REDSHIFT_DBNAME,
        "REDSHIFT_SCHEMA": REDSHIFT_SCHEMA,
        "ORIGINAL_DATA_S3_PATH": ORIGINAL_DATA_S3_PATH,
        "PREPROCESSED_TABLE_PREFIX": PREPROCESSED_TABLE_PREFIX,
        "PREPROCESSED_S3_PATH": PREPROCESSED_S3_PATH,
        "FEATURES_TABLE_PREFIX": FEATURES_TABLE_PREFIX,
        "FEATURES_S3_PATH": FEATURES_S3_PATH,
        "JOIN_TABLE_PREFIX": JOIN_TABLE_PREFIX,
        "JOIN_S3_PATH": JOIN_S3_PATH,
        "MASTER_TABLE_PREFIX": MASTER_TABLE_PREFIX,
        "MASTER_S3_PATH": MASTER_S3_PATH,
        "ORIGINAL_NEW_DATA_S3_PATH_DATASOURCE": ORIGINAL_NEW_DATA_S3_PATH_DATASOURCE,
        "MODEL_TABLE_PREFIX": MODEL_TABLE_PREFIX,
        "REDSHIFT_PREDICTIONS_TABLE": REDSHIFT_PREDICTIONS_TABLE,
        "REDSHIFT_FEATURE_IMPORTANCE_TABLE": REDSHIFT_FEATURE_IMPORTANCE_TABLE,
        **constants,
        **config,
    }

    return config_dict


# + active=""
#
# -


def get_single_statistics(df: pd.DataFrame, group_col, stat_col: str) -> pd.DataFrame:
    """For each unique value in group_col, add all statistics over stat_col

    The parameter df must be a wide (feature)table
    """

    df_res = pd.DataFrame(df[group_col].unique()).apply(
        lambda x: pd.Series({group_col: x[0]}).append(
            df[df[group_col] == x[0]][stat_col].describe()
        ),
        axis=1,
    )
    df_res["statistics_for"] = stat_col
    return df_res


def get_multi_statistics(
    df: pd.DataFrame, group_col: str, stat_cols: list
) -> pd.DataFrame:
    """For each unique value in group_col, add all statistics over each element in stat_cols

    The parameter df must be a wide (feature)table
    """
    groups = df[group_col].unique()
    df_statistics = pd.concat(
        (
            df[df[group_col] == c][stat_cols].describe().transpose().assign(group_col=c)
            for c in groups
        )
    )
    df_statistics = df_statistics.reset_index(drop=False).rename(
        columns={"index": "statistics_for", "group_col": group_col}
    )
    df_statistics["stat_group"] = (
        df_statistics[group_col] + "_" + df_statistics["statistics_for"]
    )
    return df_statistics


def detect_outliers_one_column(
    df_data, df_stats: pd.DataFrame, group_col, data_col: str, scale: float = 1.5
) -> pd.Series:
    """Determine outliers based on statistics found in get_..._statistics

    The parameter df must be a wide (feature)table
    An outlier has a value: < Q25-scale*(Q75-Q25) | > Q75+scale(Q75-Q25)
    """
    df_range = (
        df_stats[[group_col]]
        .assign(
            upper=df_stats["75%"] + scale * (df_stats["75%"] - df_stats["25%"]),
            lower=df_stats["25%"] - scale * (df_stats["75%"] - df_stats["25%"]),
        )[df_stats.statistics_for == data_col]
        .copy()
        .reset_index(drop=True)
    )

    df_tmp = df_data[[group_col, data_col]].copy()
    df_tmp.index.name = None
    df_tmp = df_tmp.reset_index(drop=False)  # Keep index!!!
    df_tmp = df_tmp.merge(df_range, on=group_col)
    df_tmp = df_tmp.set_index(keys="index")  # Set index back!!!
    df_tmp.index.name = None

    df_tmp["outliers"] = df_tmp[data_col] < df_tmp.lower
    df_tmp["outliers"] |= df_tmp[data_col] > df_tmp.upper

    return df_tmp.outliers


def detect_outliers(
    df_data, df_stats: pd.DataFrame, group_col: str, cols: list, scale: float = 1.5
) -> pd.Series:
    """Detect outliers based on multiple different columns in a wide (feature)table"""

    df_tmp = df_data[[group_col]].copy()
    df_tmp["outliers"] = detect_outliers_one_column(
        df_data, df_stats, group_col, cols[0]
    )
    for c in cols[1:]:
        df_tmp["outliers"] |= detect_outliers_one_column(
            df_data, df_stats, group_col, c, scale
        )

    return df_tmp.outliers


# + active=""
#
# -


def show_df(df: pd.DataFrame) -> None:
    with pd.option_context(
        "display.max_rows", None, "display.max_columns", None
    ):  # more options can be specified also
        IPython.display.display(df)
