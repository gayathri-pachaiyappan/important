"""
This module defines the DataSource instances used by the dydro project.
"""

import importlib

# Load main modules of our team library
WBEXAA_PKG = "nl_epd_wbexaa"
nl_epd_wbexaa = importlib.import_module(name=WBEXAA_PKG)
datasource = importlib.import_module(name=".datasource", package=WBEXAA_PKG)

pcs = datasource.DataSource(name="pcs")
