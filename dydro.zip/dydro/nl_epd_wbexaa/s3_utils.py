import importlib
import os
import re
from pathlib import Path
from typing import List

import boto3
import botocore.exceptions
import pandas as pd

# Load main modules of our team library
WBEXAA_PKG = "nl_epd_wbexaa"
nl_epd_wbexaa = importlib.import_module(name=WBEXAA_PKG)
misc_utils = importlib.import_module(name=".misc_utils", package=WBEXAA_PKG)
config = misc_utils.get_config()

# Equivalent of "from module import identifier" --> "identifier = module.identifier"
logger = nl_epd_wbexaa.logger

s3 = boto3.resource("s3")


def get_file_stem(obj):
    filename = get_filename(obj)
    stem = filename.split(".")[0]
    return stem


def get_filename(obj) -> str:
    return obj.key.split("/")[-1]


def get_sorted_file_objects(bucket_name: str, prefix: str) -> List:
    logger.info(f"Finding files in s3://{bucket_name}/{prefix}...")
    bucket = s3.Bucket(bucket_name)
    objects = bucket.objects.filter(Prefix=prefix)

    # Remove the directory itself, we just want the files.
    objects = [obj for obj in objects if not obj.key.endswith("/")]
    objects = sorted(objects, key=lambda obj: obj.last_modified)
    logger.info(f"Found {len(objects)} files in s3://{bucket_name}/{prefix}.")
    return objects


def get_file_data(path: str) -> bytes:

    s3_object = s3.Object(bucket_name=config["BUCKET_NAME"], key=path)
    body = s3_object.get()["Body"]
    return body.read()


def df_to_s3_as_parquet(
    df: pd.DataFrame, bucket: str, prefix: str, filename: str
) -> None:
    path = f"s3://{bucket}/{prefix}{filename}"  # The slash is already in the prefix.
    logger.info(f"Writing to {path}...")
    df.to_parquet(path, index=False)


def move_original_object_to_processed(
    original_obj, target_bucket: str, target_prefix: str
) -> None:

    filename = get_filename(original_obj)
    target_key = target_prefix
    if not target_key.endswith(filename):
        target_key = f"{target_prefix}{filename}"  # The slash is already in the prefix.
    logger.info(
        f"Copying file from "
        f"s3://{original_obj.bucket_name}/{original_obj.key} "
        f"to s3://{target_bucket}/{target_key}..."
    )
    s3.meta.client.copy(
        CopySource={"Bucket": original_obj.bucket_name, "Key": original_obj.key},
        Bucket=target_bucket,
        Key=target_key,
    )
    logger.info(
        f"Removing original object s3://{original_obj.bucket_name}/{original_obj.key}..."
    )
    original_obj.delete()


def move_original_file_to_processed(original_file: str) -> None:

    original_objects = get_sorted_file_objects(
        bucket_name=config["BUCKET_NAME"], prefix=original_file
    )
    if len(original_objects) != 1:
        raise Exception(
            f"No or multiple original files found for {original_file} ({original_objects.size()})."
        )
    original_obj = original_objects[0]

    target_key = re.sub(
        f'({config["ORIGINAL_DATA_S3_PATH"]}.*/)new(/.*)$',
        r"\1processed\2",
        original_obj.key,
    )

    move_original_object_to_processed(original_obj, config["BUCKET_NAME"], target_key)


def s3_object_exists(obj):
    try:
        obj.load()  # Fails if object doesn't exist on S3
        return True
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "404":  # 404 means file not found
            return False
    return True  # This is a failsafe to enforce expecting 404.


def upload_file(file_name: str, prefix: str):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param prefix:  must end with /
    """

    object_name = os.path.basename(file_name)
    logger.info(
        f"Copying file " f"{file_name}" f" to s3://{config['BUCKET_NAME']}/{prefix}..."
    )
    s3.meta.client.upload_file(file_name, config["BUCKET_NAME"], prefix + object_name)


def upload_directory(directory_path: str, prefix: str, condition: str = None):
    """Upload a directory to an S3 bucket

    :param directory_path: directory to upload to s3 bucket
    :param prefix: must end with /
    :param condition: condition to check if string is in the file name to be uploaded
    """
    for file in os.listdir(directory_path):
        if condition:
            if condition in file:
                upload_file(str(Path(directory_path) / file), prefix=prefix)
        else:
            upload_file(str(Path(directory_path) / file), prefix=prefix)


def download_file(s3_object_key):
    """Download a file from an S3 bucket into the current directory

    :param s3_object_key: s3 object key (e.g. 'glue_jobs/glue_job_demo.py')
    """
    file_name = s3_object_key.split("/")[-1]
    s3.meta.client.download_file(config["BUCKET_NAME"], s3_object_key, file_name)


def download_directory(prefix: str, condition: str = None):
    """Download a directory from an S3 bucket into the current directory

    :param prefix: must end with /
    :param condition: condition to check if string is in the file name to be downloaded
    """
    s3_object_list = get_sorted_file_objects(config["BUCKET_NAME"], prefix=prefix)
    for s3_object in s3_object_list:
        if condition:
            if condition in s3_object.key:
                logger.info(f"Downloading file {s3_object.key}")
                download_file(s3_object.key)
        else:
            logger.info(f"Downloading file {s3_object.key}")
            download_file(s3_object.key)
