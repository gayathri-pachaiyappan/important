#!/bin/bash

# AWS ECR Deployment Script for LogiX Report Extraction Tool
# Builds the local Docker image and pushes it to AWS ECR.

set -e  # Exit immediately on any error

# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

AWS_REGION="eu-west-1"
AWS_ACCOUNT_ID="369195064699"

# Existing shared ECR repository used by your AWS environment.
# If you want a dedicated repository later, change this to e.g.:
# REPOSITORY_NAME="logix-report-extractor"
REPOSITORY_NAME="abt-aa-neustadt-creon-202001007/default"

# Image tag for this specific application.
IMAGE_TAG="logix-report-extractor"

# Local image name used during docker build.
LOCAL_IMAGE_NAME="logix-report-extractor"

ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
FULL_IMAGE_NAME="${ECR_REGISTRY}/${REPOSITORY_NAME}:${IMAGE_TAG}"

echo "🚀 Starting AWS ECR deployment for LogiX Report Extraction Tool"
echo "=================================================="
echo "Region:      ${AWS_REGION}"
echo "Account ID:  ${AWS_ACCOUNT_ID}"
echo "Repository:  ${REPOSITORY_NAME}"
echo "Image tag:   ${IMAGE_TAG}"
echo "Image URI:   ${FULL_IMAGE_NAME}"
echo "=================================================="

# ---------------------------------------------------------------------
# Step 1: Authenticate Docker client to ECR
# ---------------------------------------------------------------------

echo "🔐 Authenticating Docker client to ECR registry..."

aws ecr get-login-password --region "${AWS_REGION}" \
  | docker login \
      --username AWS \
      --password-stdin "${ECR_REGISTRY}"

echo "✅ Successfully authenticated to ECR registry"

# ---------------------------------------------------------------------
# Step 2: Build Docker image
# ---------------------------------------------------------------------

echo "🔨 Building Docker image..."

docker build -t "${LOCAL_IMAGE_NAME}:${IMAGE_TAG}" .

echo "✅ Successfully built Docker image: ${LOCAL_IMAGE_NAME}:${IMAGE_TAG}"

# ---------------------------------------------------------------------
# Step 3: Tag image for ECR
# ---------------------------------------------------------------------

echo "🏷️  Tagging image for ECR..."

docker tag "${LOCAL_IMAGE_NAME}:${IMAGE_TAG}" "${FULL_IMAGE_NAME}"

echo "✅ Successfully tagged image: ${FULL_IMAGE_NAME}"

# ---------------------------------------------------------------------
# Step 4: Push image to ECR
# ---------------------------------------------------------------------

echo "📤 Pushing image to ECR repository..."

docker push "${FULL_IMAGE_NAME}"

echo "✅ Successfully pushed image to ECR repository"
echo "🎉 Deployment completed successfully!"
echo "=================================================="
echo "Image URI:"
echo "${FULL_IMAGE_NAME}"
echo "=================================================="

# ---------------------------------------------------------------------
# Optional cleanup
# ---------------------------------------------------------------------

read -p "🗑️  Do you want to clean up local Docker images? (y/N) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🧹 Cleaning up local images..."
    docker rmi "${LOCAL_IMAGE_NAME}:${IMAGE_TAG}" 2>/dev/null || true
    docker rmi "${FULL_IMAGE_NAME}" 2>/dev/null || true
    echo "✅ Local images cleaned up"
fi

echo "🏁 ECR deployment script completed!"