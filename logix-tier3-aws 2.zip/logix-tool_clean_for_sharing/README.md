# LogiX Report Extraction Tool

Automates the two manual daily **Tier 3** exports for **Site Neustadt** from
LogiX / PackOS, as described in *"Instruction for Export of LogiX Reports for
Site Neustadt Tier 3 Dashboard"*:

| # | Report | Format | Scope |
|---|--------|--------|-------|
| I  | Site OEE Report (Standort OEE Bericht) | CSV  | All MUs / Lines except offline Line 66 |
| II | Production – Bereich MU-Packaging      | XLSX | Current year |

The tool drives a real Chromium browser via [Playwright](https://playwright.dev/python/),
signs in once through **Azure AD** (incl. MFA), then persists the session so
later runs are fully unattended.

---

## Prerequisites

- [uv](https://docs.astral.sh/uv/) (`curl -LsSf https://astral.sh/uv/install.sh | sh`)
- A corporate account with access to `https://packos.logix.abbott.com`
- Network access to the LogiX portal (corporate network / VPN)

## Setup

```bash
cd logix-tool

# Create the virtual environment and install dependencies (incl. Playwright)
uv sync

# Download the Chromium browser Playwright needs (one-time)
uv run playwright install chromium
```

> On Linux you may also need system libraries:
> `uv run playwright install-deps chromium`

## First run (interactive login)

The first run opens a visible browser so you can complete the Azure AD
sign-in (and MFA) once. The session is then stored in
`~/.logix_playwright_profile` and reused automatically.

```bash
uv run logix --headed
```

## Routine runs (unattended)

After the session is stored, run both exports headless:

```bash
uv run logix
```

Files are written to `~/logix_exports/` with a timestamp prefix, e.g.
`20260609_102038_Production.xlsx` and `site-oee-report_2026-01-01-2026-06-09.csv`.

## Service-account login (fully unattended, no human MFA)

By default the **first** login is interactive (a human completes Azure AD +
MFA once, and the session is reused afterwards). For a fully unattended setup
— e.g. a scheduled job or AWS — use a **dedicated service account** whose
credentials are injected via the `LOGIX_USERNAME` / `LOGIX_PASSWORD`
environment variables. The tool fills the Azure AD form itself.

**In production these credentials are never stored on disk** — they live in
AWS Secrets Manager and are exported into the environment at runtime:

```bash
eval "$(uv run deliver creds)"   # pulls the secret -> exports LOGIX_USERNAME/PASSWORD
uv run logix                     # auto-fills the Azure AD form
```

> **Local development fallback (optional):** before a service account exists,
> you can put `"username"` / `"password"` directly in your local `config.json`
> instead of using env vars. This is a convenience for local testing only —
> `config.json` is **git-ignored** and must never be committed, and the
> production path is Secrets Manager, not the file.
>
> ```bash
> export LOGIX_USERNAME="svc-neustadt-reports@abbott.com"
> export LOGIX_PASSWORD="..."   # or, locally only, add them to config.json
> uv run logix
> ```

You can point at a specific config file with `uv run logix --config /path/to/config.json`.

> **MFA caveat:** auto-fill handles username + password. If the service
> account still has MFA enforced, that step needs a human, so ask the identity
> team to exempt the account from MFA for a trusted IP (e.g. your AWS NAT
> egress address) or to allow certificate-based sign-in. With MFA disabled for
> that account/IP, the whole flow is unattended.

### Ephemeral session (clean login every run)

For unattended/service-account runs it's cleanest to **not persist** a browser
session at all — that avoids any stale, locked, or expired profile state.
`--ephemeral-session` uses a fresh temporary profile and **deletes it on exit**,
forcing a clean credential login each run:

```bash
uv run logix --ephemeral-session            # fresh login, no leftover session
```

It also **purges any previously stored sessions at startup** — the persistent
profile (default or `--user-data-dir`) and leftover temp profiles from earlier
runs — so no old session can linger. It otherwise ignores `--user-data-dir`.
Use it only when the account is **MFA-exempt** (otherwise every run would prompt
for MFA, and the wiped persistent profile means an interactive run must redo MFA).
For local/interactive use where MFA is enforced, omit it and keep the default
persistent profile so MFA is done once and reused.

## Common options

```bash
# Run only one of the two exports
uv run logix --task oee
uv run logix --task production

# Pick a different reporting year (OEE date range)
uv run logix --task oee --year 2025

# Change the output directory
uv run logix --download-dir /path/to/output

# Reuse an already-open Edge/Chrome via CDP (no re-login / no MFA)
# (requires Edge/Chrome installed; mainly useful on Windows)
#   1) msedge --remote-debugging-port=9222 --user-data-dir=/tmp/edge-debug
#   2) attach:
uv run logix --cdp-endpoint http://localhost:9222

# Launch an installed branded browser instead of bundled Chromium
# (the browser must be installed; otherwise use the bundled Chromium above)
uv run logix --headed --channel msedge

# Keep the browser open after finishing (headed only)
uv run logix --headed --keep-open
```

> The `--channel` and `--cdp-endpoint` options need an actual Edge/Chrome
> installation. If none is present, omit them and the tool uses the Chromium
> downloaded by `playwright install chromium`.

Full option list:

```bash
uv run logix --help
```

## How it works

1. **Authenticate** – opens the portal; if a stored session is valid it
   continues, otherwise it clicks *Azure AD* and waits for you to sign in.
2. **Ensure English** – verifies the UI language is `EN` (switches it if not),
   because the automation matches English labels.
3. **Export I (OEE)** – Reports → *Reports Download* → *Site OEE Report*,
   selects all MUs/Lines except offline Line 66, sets a custom date range
   (Jan 1 → today of the selected year) and exports the CSV.
4. **Export II (Production)** – Reports → *Production* tab, scope
   *Neustadt → Bereich MU-Packaging*, Period *Year*, opens the table and
   downloads the Excel file.

On failure an `error_screenshot.png` is written to the download directory to
aid debugging.

## Notes

- The persisted login (`~/.logix_playwright_profile`) and exported reports are
  **excluded from version control** via `.gitignore` – they contain
  credentials / business data.
- `config.json` is **git-ignored** and must never be committed. It holds the
  `aws` settings block; in production, credentials come from Secrets Manager,
  not this file. Any local `username`/`password` keys are a dev-only
  convenience. Never commit real secrets.
- Pinned to `playwright==1.60.0`; the matching Chromium build is installed via
  `playwright install chromium`.

## Cloud delivery (S3 + Secrets Manager)

For unattended runs (e.g. on Fargate/EC2) the reports are archived to **S3**
and the LogiX service-account credentials are read from **AWS Secrets Manager**.
This lives in a separate module, [`deliver.py`](deliver.py), so the extraction
logic in `logix.py` stays free of any cloud dependency.

Install the optional AWS extra (adds `boto3`):

```bash
uv sync --extra aws
```

Authentication follows the cloud-engineering convention: boto3 **clients are
used directly** (no explicit session). In AWS the task/instance role supplies
credentials; locally you select a profile with `AWS_PROFILE`.

```bash
# Local testing — pick the profile that can reach the account/bucket
export AWS_PROFILE=<your_profile>
```

### Upload the reports

The simplest path is the built-in `--s3` flag on the extractor: it uploads the
files it just downloaded, right after a successful run.

```bash
export AWS_PROFILE=<your_profile>        # or rely on the task role in AWS
uv run logix --ephemeral-session --s3    # extract, then upload to S3
```

Override the destination with `--s3-bucket` / `--s3-prefix` / `--s3-region`.

You can also upload existing files independently with the `deliver` command:

```bash
# Upload the newest CSV + XLSX from the export directory.
# Bucket / region / prefix default to the Neustadt non-prod values.
uv run deliver upload ~/logix_exports

# Or pass explicit files / globs:
uv run deliver upload ~/logix_exports/*.csv ~/logix_exports/*.xlsx
```

Each file is written to a date-partitioned key plus a stable `latest/` copy:

```
s3://<bucket>/logix-report/YYYY/MM/DD/<original-filename>
s3://<bucket>/logix-report/latest/site-oee-report.csv
s3://<bucket>/logix-report/latest/Production.xlsx
```

Defaults (override with `--bucket` / `--prefix` / `--region` / `--no-latest`):

| Setting | Default |
|---------|---------|
| bucket  | `abt-aa-neustadt-creon-202001007-gpmo-cada-nonprod` |
| region  | `eu-west-1` |
| prefix  | `logix-report` |

### Read credentials from Secrets Manager

The service-account credentials live in a secret holding
`{"username": "...", "password": "..."}`. The `creds` subcommand prints shell
`export` lines (to stdout) that the extractor consumes via
`LOGIX_USERNAME` / `LOGIX_PASSWORD`:

```bash
eval "$(uv run deliver creds)"     # exports LOGIX_USERNAME / LOGIX_PASSWORD
uv run logix --ephemeral-session   # runs fully unattended
```

The secret id defaults to
`/nonprod/abt-aa-neustadt-creon-202001007/logix_creds` (override with
`--secret-id`). The command fails loudly if the secret still holds placeholder
values.

### Where the AWS settings come from

Region, bucket, prefix and secret id come from the **required** `"aws"` block
in `config.json` — there are no hardcoded fallbacks, so all environment
settings live in one place:

```json
{
  "aws": {
    "region": "eu-west-1",
    "bucket": "abt-aa-neustadt-creon-202001007-gpmo-cada-nonprod",
    "prefix": "logix-report",
    "secret_id": "/nonprod/abt-aa-neustadt-creon-202001007/logix_creds"
  }
}
```

If the file or any of those four keys is missing, the tool fails loudly. CLI
flags (`--region` / `--bucket` / `--prefix` / `--secret-id`, or the
`logix --s3-*` equivalents) override individual values at call time.

Point at a specific file with `--config /path/to/config.json` (both `deliver`
and `logix` accept it).

### Full unattended pipeline (container)

```bash
export AWS_PROFILE=<profile>        # AWS supplies the role automatically
eval "$(uv run deliver creds)"      # 1. fetch LogiX creds
uv run logix --ephemeral-session --s3   # 2. extract + 3. archive to S3
```

## SharePoint delivery (Microsoft Graph)

The reports can also be delivered to the team SharePoint site, using the **same
approach as the cada-pipelines project**: an MSAL **certificate** (stored in
Secrets Manager as `o365-msal-gpmo`) is used to obtain a Microsoft Graph token,
and files are uploaded via Graph. Install the extra (adds `msal` + `requests`):

```bash
uv sync --extra sharepoint
```

Settings live in the `"sharepoint"` block of `config.json` (required keys
`secret_id` / `site` / `folder`; `hostname` defaults to the Abbott tenant,
`library` is optional):

```json
{
  "sharepoint": {
    "secret_id": "/nonprod/abt-aa-neustadt-creon-202001007/o365-msal-gpmo",
    "site": "/sites/DE-EPD-BExNeustadt",
    "hostname": "abbott.sharepoint.com",
    "library": "iCube",
    "folder": "bex_cloud/generic/creon/logix-report"
  }
}
```

A site can have **several document libraries** (drives). `library` selects the
named one (here `iCube`, matching `.../sites/DE-EPD-BExNeustadt/iCube`) and
`folder` is then relative to that library's root. If `library` is omitted, the
site's default "Documents" library is used and a leading `Shared Documents/`
(or `Documents/`) in `folder` is stripped automatically.

The MSAL secret holds `{TENANT_ID, CLIENT_ID, THUMBPRINT, PRIVATE_KEY_FILE}` —
the same shape the cada-pipelines `Sharepoint` helper expects.

```bash
# Upload the newest CSV + XLSX to SharePoint:
uv run deliver sharepoint ~/logix_exports

# Or extract and deliver in one go:
uv run logix --ephemeral-session --sharepoint
```

Files land inside the site's document library under a dated folder plus a
stable `latest/` copy (the same naming/structure as the S3 archive):

```
<folder>/YYYY/MM/DD/<original-filename>
<folder>/latest/site-oee-report.csv
<folder>/latest/Production.xlsx
```

Override per run with `--folder` / `--library` / `--site` / `--secret-id`. Files
are uploaded with Graph's simple upload (report files are well under the 4 MB
limit).

## Full delivery pipeline (container)

```bash
export AWS_PROFILE=<profile>             # AWS supplies the role automatically
eval "$(uv run deliver creds)"           # 1. fetch LogiX creds
uv run logix --ephemeral-session \
    --s3 --sharepoint                    # 2. extract, 3. S3 archive, 4. SharePoint
```

### IAM (least privilege)

The task/instance role needs only:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PutNeustadtReports",
      "Effect": "Allow",
      "Action": ["s3:PutObject"],
      "Resource": "arn:aws:s3:::abt-aa-neustadt-creon-202001007-gpmo-cada-nonprod/logix-report/*"
    },
    {
      "Sid": "ReadLogixSecret",
      "Effect": "Allow",
      "Action": ["secretsmanager:GetSecretValue"],
      "Resource": "arn:aws:secretsmanager:eu-west-1:369195064699:secret:/nonprod/abt-aa-neustadt-creon-202001007/logix_creds-*"
    }
  ]
}
```

> For SharePoint delivery, the role also needs `secretsmanager:GetSecretValue`
> on the MSAL secret
> `arn:aws:secretsmanager:eu-west-1:369195064699:secret:/nonprod/abt-aa-neustadt-creon-202001007/o365-msal-gpmo-*`.
> No S3 permissions are required for the SharePoint path.

> The service account must be **MFA-exempt for the instance's fixed egress IP**
> (Elastic IP / NAT Gateway) for the headless sign-in to complete without a
> human. Request this from the identity team once the egress IP is known.

## Scheduling (optional)

To run the unattended export daily, add a cron entry (after the first
interactive login has been completed once):

Replace `/path/to/logix-tool` with the absolute path to this project, and
`/path/to/uv` with the output of `command -v uv` (cron has a minimal
environment, so absolute paths and an absolute log location are required):

```cron
# Every weekday at 06:00
0 6 * * 1-5 cd /path/to/logix-tool && /path/to/uv run logix >> /path/to/logix-tool/cron.log 2>&1
```

Validate the entry before installing it:

```bash
PROJECT="$(pwd)"            # run this from the logix-tool directory
UV="$(command -v uv)"
crontab -l > /tmp/current.cron 2>/dev/null
echo "0 6 * * 1-5 cd $PROJECT && $UV run logix >> $PROJECT/cron.log 2>&1" >> /tmp/current.cron
crontab -n /tmp/current.cron   # dry-run syntax check
crontab /tmp/current.cron      # install
```
