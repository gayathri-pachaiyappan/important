"""Deliver the exported LogiX reports to S3 (archive / source of truth) and/or
SharePoint (colleague delivery), and optionally fetch the LogiX service-account
credentials from AWS Secrets Manager so the extraction can run unattended.

Design notes (agreed with cloud engineering):
  * Use boto3 *clients* directly - no explicit session needed. In AWS the
    Fargate/EC2 task role supplies credentials; locally, export AWS_PROFILE.
  * The Secrets Manager secret stores ``{"username": "...", "password": "..."}``;
    we read it by its path (secret id) and expose it as the env vars the
    extractor already understands (LOGIX_USERNAME / LOGIX_PASSWORD).
  * SharePoint uses the SAME pattern as the cada-pipelines project: an MSAL
    certificate (TENANT_ID/CLIENT_ID/THUMBPRINT/PRIVATE_KEY_FILE) stored in
    Secrets Manager, used to get a Microsoft Graph token and upload files.

Typical Fargate flow:
    eval "$(python deliver.py creds --secret-id <path>)"   # export creds
    uv run logix --ephemeral-session                       # produce files
    python deliver.py upload ~/logix_exports               # archive to S3
    python deliver.py sharepoint ~/logix_exports           # deliver to SharePoint

This module deliberately stays separate from logix.py so the extraction logic
remains independent of any cloud/delivery concern.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import glob
import json
import os
import sys
import urllib.parse
from pathlib import Path

import boto3

# All AWS settings (region / bucket / prefix / secret_id) live in the "aws"
# block of config.json - there are no hardcoded fallbacks. CLI flags may still
# override individual values at call time.
REQUIRED_AWS_KEYS = ("region", "bucket", "prefix", "secret_id")
DEFAULT_CONFIG_NAME = "config.json"

# SharePoint settings live in the "sharepoint" block of config.json. secret_id /
# site / folder are required; hostname defaults to the Abbott tenant.
REQUIRED_SP_KEYS = ("secret_id", "site", "folder")
DEFAULT_SP_HOSTNAME = "abbott.sharepoint.com"
GRAPH_ENDPOINT = "https://graph.microsoft.com/v1.0"
GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_AUTHORITY_BASE = "https://login.microsoftonline.com/"
# Microsoft Graph simple-upload limit; larger files need a chunked upload session.
GRAPH_SIMPLE_UPLOAD_MAX = 4 * 1024 * 1024  # 4 MB


def log(msg: str) -> None:
    # Diagnostics go to stderr so stdout stays clean (the `creds` subcommand
    # writes shell `export` lines to stdout for `eval "$(...)"`).
    print(f"[deliver] {msg}", file=sys.stderr, flush=True)


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
def _resolve_config_path(config_path: str | None) -> Path | None:
    """Find config.json: --config PATH, then ./config.json, then next to this file."""
    candidates: list[Path] = []
    if config_path:
        candidates.append(Path(config_path).expanduser())
    candidates.append(Path.cwd() / DEFAULT_CONFIG_NAME)
    candidates.append(Path(__file__).resolve().parent / DEFAULT_CONFIG_NAME)
    for p in candidates:
        if p.is_file():
            return p
    return None


def load_aws_config(config_path: str | None = None) -> dict:
    """Return the AWS settings from the ``"aws"`` block of config.json.

    The config file holds a top-level ``"aws"`` object, e.g.::

        {
          "aws": {
            "region": "eu-west-1",
            "bucket": "abt-aa-...-nonprod",
            "prefix": "logix-report",
            "secret_id": "/nonprod/.../logix_creds"
          }
        }

    There are no hardcoded fallbacks: if the file or any required key is
    missing this raises so the caller fails loudly. CLI flags (resolved by the
    caller) may override individual values.
    """
    path = _resolve_config_path(config_path)
    if path is None:
        raise FileNotFoundError(
            "No config.json found (looked for --config, ./config.json, and the "
            "file next to deliver.py). It must contain an 'aws' block."
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise ValueError(f"Could not read config {path}: {exc}") from exc

    aws = data.get("aws") or {}
    missing = [k for k in REQUIRED_AWS_KEYS if not aws.get(k)]
    if missing:
        raise ValueError(
            f"config {path} is missing required 'aws' setting(s): "
            f"{', '.join(missing)}."
        )
    return {k: aws[k] for k in REQUIRED_AWS_KEYS}


def load_sharepoint_config(config_path: str | None = None) -> dict:
    """Return the SharePoint settings from the ``"sharepoint"`` block of config.json.

    Required keys: ``secret_id`` (MSAL cert secret), ``site`` (server-relative
    path, e.g. ``/sites/DE-EPD-BExNeustadt``) and ``folder`` (destination inside
    the site's default document library). ``hostname`` is optional and defaults
    to the Abbott tenant. Raises if the file or a required key is missing.
    """
    path = _resolve_config_path(config_path)
    if path is None:
        raise FileNotFoundError(
            "No config.json found (looked for --config, ./config.json, and the "
            "file next to deliver.py). It must contain a 'sharepoint' block."
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise ValueError(f"Could not read config {path}: {exc}") from exc

    sp = data.get("sharepoint") or {}
    missing = [k for k in REQUIRED_SP_KEYS if not sp.get(k)]
    if missing:
        raise ValueError(
            f"config {path} is missing required 'sharepoint' setting(s): "
            f"{', '.join(missing)}."
        )
    return {
        "secret_id": sp["secret_id"],
        "site": sp["site"],
        "folder": sp["folder"],
        "hostname": sp.get("hostname") or DEFAULT_SP_HOSTNAME,
        "library": sp.get("library"),  # optional named document library (drive)
        "region": sp.get("region"),  # optional; caller falls back to the aws region
    }


# --------------------------------------------------------------------------- #
# Secrets Manager
# --------------------------------------------------------------------------- #
def _get_secret_json(secret_id: str, region: str) -> dict:
    """Fetch a JSON secret from Secrets Manager and return it as a dict."""
    client = boto3.client("secretsmanager", region_name=region)
    resp = client.get_secret_value(SecretId=secret_id)
    return json.loads(resp["SecretString"])


def fetch_credentials(secret_id: str, region: str) -> dict:
    """Read ``{"username","password"}`` from Secrets Manager.

    Returns the parsed dict. Raises if the secret is missing or malformed so
    the caller fails loudly rather than running with no credentials.
    """
    data = _get_secret_json(secret_id, region)
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not username or not password or username == "-" or password == "-":
        raise ValueError(
            f"Secret '{secret_id}' has no real username/password yet "
            "(still placeholder?). Populate it before running."
        )
    return {"username": username, "password": password}


def emit_credential_exports(secret_id: str, region: str) -> None:
    """Print shell ``export`` lines for the credentials.

    Intended for ``eval "$(python deliver.py creds --secret-id ...)"`` so the
    extractor picks them up via LOGIX_USERNAME / LOGIX_PASSWORD. We print the
    exports to stdout and all logging to stderr so eval only consumes exports.
    """
    creds = fetch_credentials(secret_id, region)
    # Single-quote and escape any embedded single quotes safely for the shell.
    def sh(v: str) -> str:
        return "'" + v.replace("'", "'\"'\"'") + "'"

    print(f"export LOGIX_USERNAME={sh(creds['username'])}")
    print(f"export LOGIX_PASSWORD={sh(creds['password'])}")
    log(f"Loaded credentials from secret '{secret_id}'.")


# --------------------------------------------------------------------------- #
# S3 upload
# --------------------------------------------------------------------------- #
def _content_type(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".csv": "text/csv",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".png": "image/png",
    }.get(ext, "application/octet-stream")


def upload_files(
    files: list[Path],
    bucket: str,
    prefix: str,
    region: str,
    also_latest: bool = True,
) -> list[str]:
    """Upload each file to S3 under a date-partitioned key.

    Key layout:  <prefix>/<YYYY>/<MM>/<DD>/<filename>
    Plus, when ``also_latest``:  <prefix>/latest/<stable-name>  so a downstream
    SharePoint sync or pre-signed link can always point at today's report.

    Returns the list of s3:// URIs written.
    """
    s3 = boto3.client("s3", region_name=region)
    today = _dt.date.today()
    datepath = f"{today.year:04d}/{today.month:02d}/{today.day:02d}"
    written: list[str] = []

    for f in files:
        f = Path(f)
        if not f.is_file():
            log(f"  ! skipping missing file {f}")
            continue
        ctype = _content_type(f)
        dated_key = f"{prefix}/{datepath}/{f.name}"
        s3.upload_file(str(f), bucket, dated_key, ExtraArgs={"ContentType": ctype})
        log(f"uploaded s3://{bucket}/{dated_key}")
        written.append(f"s3://{bucket}/{dated_key}")

        if also_latest:
            # Stable, timestamp-free name so "latest" is predictable.
            stable = _stable_latest_name(f.name)
            latest_key = f"{prefix}/latest/{stable}"
            s3.upload_file(str(f), bucket, latest_key, ExtraArgs={"ContentType": ctype})
            log(f"updated  s3://{bucket}/{latest_key}")

    if not written:
        raise FileNotFoundError("No files were uploaded (none of the inputs existed).")
    return written


def upload_error_screenshot(
    path: Path,
    bucket: str,
    prefix: str,
    region: str,
) -> str:
    """Upload a single failure screenshot to S3 for post-mortem viewing.

    Written under the same prefix the reports use (so it's covered by the
    existing least-privilege s3:PutObject grant), at two keys:

        <prefix>/errors/<YYYY>/<MM>/<DD>/<filename>   (dated, kept per run)
        <prefix>/errors/latest.png                     (always the newest one)

    Returns the s3:// URI of the dated copy.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Screenshot not found: {path}")

    s3 = boto3.client("s3", region_name=region)
    today = _dt.date.today()
    datepath = f"{today.year:04d}/{today.month:02d}/{today.day:02d}"
    dated_key = f"{prefix}/errors/{datepath}/{path.name}"

    s3.upload_file(str(path), bucket, dated_key, ExtraArgs={"ContentType": "image/png"})
    log(f"uploaded s3://{bucket}/{dated_key}")

    latest_key = f"{prefix}/errors/latest.png"
    s3.upload_file(str(path), bucket, latest_key, ExtraArgs={"ContentType": "image/png"})
    log(f"updated  s3://{bucket}/{latest_key}")

    return f"s3://{bucket}/{dated_key}"


def _stable_latest_name(filename: str) -> str:
    """Map a timestamped export name to a stable 'latest' name.

    e.g. '20260609_110339_site-oee-report_2026-01-01-2026-06-09.csv'
         -> 'site-oee-report.csv'
         '20260609_110351_Production.xlsx' -> 'Production.xlsx'
    """
    lower = filename.lower()
    if lower.endswith(".csv") and "oee" in lower:
        return "site-oee-report.csv"
    if lower.endswith(".xlsx") and "production" in lower:
        return "Production.xlsx"
    # Fallback: strip a leading 'YYYYMMDD_HHMMSS_' timestamp prefix if present.
    parts = filename.split("_", 2)
    if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
        return parts[2]
    return filename


def _expand(paths: list[str]) -> list[Path]:
    """Expand globs/paths; if a directory is given (or matched), take the
    newest csv and newest xlsx inside it."""
    out: list[Path] = []
    for p in paths:
        matches = [Path(m) for m in glob.glob(os.path.expanduser(p))]
        if not matches:
            # No glob hit; treat a bare directory path as a directory.
            cand = Path(p).expanduser()
            matches = [cand] if cand.is_dir() else []
        for m in matches:
            if m.is_dir():
                for pat in ("*.csv", "*.xlsx"):
                    hits = sorted(m.glob(pat), key=lambda x: x.stat().st_mtime)
                    if hits:
                        out.append(hits[-1])  # newest of each type
            elif m.is_file():
                out.append(m)
    return out


# --------------------------------------------------------------------------- #
# SharePoint upload (Microsoft Graph, MSAL certificate auth)
# --------------------------------------------------------------------------- #
def _format_private_key(key: str) -> str:
    """Restore a PEM private key stored in Secrets Manager as a single line.

    The key is stored with spaces instead of newlines in the body; this reverts
    it to a usable PEM. Mirrors the cada-pipelines helper of the same name.
    """
    split = key.split("-----")
    body = split[2].replace(" ", "\n")
    return f"-----BEGIN RSA PRIVATE KEY-----{body}-----END RSA PRIVATE KEY-----"


def _graph_token(secret_id: str, region: str) -> str:
    """Acquire a Microsoft Graph access token using the MSAL cert in the secret.

    The secret holds ``{TENANT_ID, CLIENT_ID, THUMBPRINT, PRIVATE_KEY_FILE}``
    (same shape as the cada-pipelines ``o365-msal-*`` secrets).
    """
    import msal  # lazy: only needed for SharePoint delivery

    s = _get_secret_json(secret_id, region)
    try:
        tenant_id = s["TENANT_ID"]
        client_id = s["CLIENT_ID"]
        thumbprint = s["THUMBPRINT"]
        private_key = _format_private_key(s["PRIVATE_KEY_FILE"])
    except KeyError as exc:
        raise ValueError(
            f"MSAL secret '{secret_id}' is missing key {exc}; expected "
            "TENANT_ID/CLIENT_ID/THUMBPRINT/PRIVATE_KEY_FILE."
        ) from exc

    app = msal.ConfidentialClientApplication(
        client_id,
        authority=f"{GRAPH_AUTHORITY_BASE}{tenant_id}",
        client_credential={"thumbprint": thumbprint, "private_key": private_key},
    )
    result = app.acquire_token_for_client(scopes=[GRAPH_SCOPE])
    if "access_token" not in result:
        raise RuntimeError(
            "Failed to acquire Graph token: "
            f"{result.get('error')} - {result.get('error_description')}"
        )
    return result["access_token"]


def _graph_resolve_drive(
    token: str, hostname: str, site: str, library: str | None = None
) -> str:
    """Resolve a document-library drive id for a SharePoint site.

    When ``library`` is given, the named document library (e.g. ``iCube``) is
    used; otherwise the site's default library ("Documents") is returned.
    """
    import requests  # lazy

    headers = {"Authorization": f"Bearer {token}"}
    site = site if site.startswith("/") else f"/{site}"
    site_url = f"{GRAPH_ENDPOINT}/sites/{hostname}:{site}"
    r = requests.get(site_url, headers=headers, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Could not resolve site '{site}': {r.status_code} {r.text}")
    site_id = r.json()["id"]

    if library:
        r = requests.get(
            f"{GRAPH_ENDPOINT}/sites/{site_id}/drives", headers=headers, timeout=30
        )
        if r.status_code != 200:
            raise RuntimeError(
                f"Could not list drives for site: {r.status_code} {r.text}"
            )
        for d in r.json().get("value", []):
            if d.get("name") == library:
                return d["id"]
        names = [d.get("name") for d in r.json().get("value", [])]
        raise RuntimeError(
            f"Document library '{library}' not found on site. Available: {names}"
        )

    r = requests.get(f"{GRAPH_ENDPOINT}/sites/{site_id}/drive", headers=headers, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Could not resolve drive for site: {r.status_code} {r.text}")
    return r.json()["id"]


def _graph_ensure_folder(token: str, drive_id: str, folder: str) -> None:
    """Idempotently create each segment of a nested folder path in the drive."""
    import requests  # lazy

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    parent = ""
    for seg in [p for p in folder.split("/") if p]:
        if parent:
            url = f"{GRAPH_ENDPOINT}/drives/{drive_id}/root:/{urllib.parse.quote(parent)}:/children"
        else:
            url = f"{GRAPH_ENDPOINT}/drives/{drive_id}/root/children"
        body = {"name": seg, "folder": {}, "@microsoft.graph.conflictBehavior": "fail"}
        r = requests.post(url, headers=headers, json=body, timeout=30)
        # 201 created, 409 already exists - both fine.
        if r.status_code not in (200, 201, 409):
            raise RuntimeError(f"Could not create folder '{seg}': {r.status_code} {r.text}")
        parent = f"{parent}/{seg}" if parent else seg


def _graph_put_file(token: str, drive_id: str, dest_path: str, local_file: Path) -> str:
    """Upload a single (<=4MB) file to ``dest_path`` in the drive; return its webUrl."""
    import requests  # lazy

    size = local_file.stat().st_size
    if size > GRAPH_SIMPLE_UPLOAD_MAX:
        raise ValueError(
            f"{local_file.name} is {size} bytes (> 4MB); chunked upload not "
            "implemented (report files are expected to be small)."
        )
    url = f"{GRAPH_ENDPOINT}/drives/{drive_id}/root:/{urllib.parse.quote(dest_path)}:/content"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": _content_type(local_file)}
    with open(local_file, "rb") as fh:
        r = requests.put(url, headers=headers, data=fh, timeout=120)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Upload of {local_file.name} failed: {r.status_code} {r.text}")
    return r.json().get("webUrl", dest_path)


def _strip_shared_docs(folder: str) -> str:
    """The default drive root IS the 'Shared Documents' library, so drop that prefix."""
    for prefix in ("Shared Documents/", "Shared%20Documents/", "Documents/"):
        if folder.startswith(prefix):
            return folder[len(prefix):]
    return folder


def upload_to_sharepoint(
    files: list[Path],
    sp_cfg: dict,
    region: str,
    also_latest: bool = True,
) -> list[str]:
    """Upload report files to SharePoint latest/ only.

    Layout inside the site's document library:
        <folder>/latest/<stable-name>

    Historical archiving is intentionally handled by S3, not SharePoint.
    The ``also_latest`` argument is kept for backward compatibility with
    existing callers, but SharePoint now always receives only the latest
    stable files.
    """
    token = _graph_token(sp_cfg["secret_id"], region)
    library = sp_cfg.get("library")
    drive_id = _graph_resolve_drive(
        token, sp_cfg["hostname"], sp_cfg["site"], library=library
    )

    # The default library root is "Shared Documents"; strip that prefix only
    # when targeting it. A named library root is the library itself, so the
    # folder is taken verbatim.
    folder = sp_cfg["folder"]
    base = (folder if library else _strip_shared_docs(folder)).strip("/")

    written: list[str] = []
    latest_folder = f"{base}/latest"

    _graph_ensure_folder(token, drive_id, latest_folder)

    for f in files:
        f = Path(f)
        if not f.is_file():
            log(f"  ! skipping missing file {f}")
            continue

        stable = _stable_latest_name(f.name)
        url = _graph_put_file(token, drive_id, f"{latest_folder}/{stable}", f)

        log(f"updated SharePoint:/{latest_folder}/{stable}")
        written.append(url)

    if not written:
        raise FileNotFoundError("No files were uploaded (none of the inputs existed).")
    return written


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Deliver LogiX reports to S3 / read creds.")
    parser.add_argument(
        "--config",
        default=None,
        help="Path to config.json (its optional 'aws' block supplies region/bucket/prefix/secret_id).",
    )
    parser.add_argument(
        "--region",
        default=None,
        help="AWS region (overrides config / default eu-west-1).",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    up = sub.add_parser("upload", help="Upload report files to S3.")
    up.add_argument("files", nargs="+", help="Files, globs, or a directory (newest csv+xlsx).")
    up.add_argument("--bucket", default=None, help="S3 bucket (overrides config / default).")
    up.add_argument("--prefix", default=None, help="Key prefix (overrides config / default).")
    up.add_argument("--no-latest", action="store_true", help="Do not also write the latest/ copy.")

    cr = sub.add_parser("creds", help="Print shell exports for the LogiX credentials from Secrets Manager.")
    cr.add_argument("--secret-id", default=None, help="Secret id/path (overrides config / default).")
    cr.add_argument("--check", action="store_true", help="Only verify that the secret can be read; do not print exports.")

    sp = sub.add_parser("sharepoint", help="Upload report files to SharePoint via Microsoft Graph.")
    sp.add_argument("files", nargs="+", help="Files, globs, or a directory (newest csv+xlsx).")
    sp.add_argument("--folder", default=None, help="Destination folder in the site (overrides config).")
    sp.add_argument("--library", default=None, help="Named document library/drive, e.g. 'iCube' (overrides config).")
    sp.add_argument("--site", default=None, help="SharePoint site path (overrides config).")
    sp.add_argument("--secret-id", default=None, help="MSAL cert secret id (overrides config).")
    sp.add_argument("--no-latest", action="store_true", help="Do not also write the latest/ copy.")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "upload":
            aws_cfg = load_aws_config(args.config)
            region = args.region or aws_cfg["region"]
            files = _expand(args.files)
            if not files:
                log("No input files matched.")
                return 1
            upload_files(
                files,
                bucket=args.bucket or aws_cfg["bucket"],
                prefix=args.prefix or aws_cfg["prefix"],
                region=region,
                also_latest=not args.no_latest,
            )
        elif args.command == "creds":
            aws_cfg = load_aws_config(args.config)
            region = args.region or aws_cfg["region"]
            secret_id = args.secret_id or aws_cfg["secret_id"]
            if args.check:
                creds = fetch_credentials(secret_id, region)
                log(f"Credentials secret is readable. Username present: {bool(creds.get('username'))}; password present: {bool(creds.get('password'))}.")
            else:
                emit_credential_exports(secret_id, region)
        elif args.command == "sharepoint":
            sp_cfg = load_sharepoint_config(args.config)
            if args.folder:
                sp_cfg["folder"] = args.folder
            if args.library:
                sp_cfg["library"] = args.library
            if args.site:
                sp_cfg["site"] = args.site
            if args.secret_id:
                sp_cfg["secret_id"] = args.secret_id
            # Region for fetching the MSAL secret: --region, then the sharepoint
            # block's region, then the aws block's region.
            region = args.region or sp_cfg["region"] or load_aws_config(args.config)["region"]
            files = _expand(args.files)
            if not files:
                log("No input files matched.")
                return 1
            upload_to_sharepoint(
                files, sp_cfg=sp_cfg, region=region, also_latest=not args.no_latest
            )
    except Exception as exc:  # noqa: BLE001
        log(f"ERROR: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
